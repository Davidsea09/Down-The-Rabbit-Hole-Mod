package org.sinytra.fabric.loot_api_v2.generated;

@net.neoforged.fml.common.Mod(GeneratedEntryPoint.MOD_ID)
public class GeneratedEntryPoint {
    public static final String MOD_ID = "fabric_loot_api_v2";  
    public static final String RAW_MOD_ID = "fabric-loot-api-v2";  

    public GeneratedEntryPoint(net.neoforged.bus.api.IEventBus bus) {
        // Initialize main entrypoints
        new net.fabricmc.fabric.impl.loot.v2.LootInitializer().onInitialize();
        
        
    }
}