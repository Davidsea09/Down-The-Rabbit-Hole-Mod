package org.sinytra.fabric.block_view_api.generated;

@net.neoforged.fml.common.Mod(GeneratedEntryPoint.MOD_ID)
public class GeneratedEntryPoint {
    public static final String MOD_ID = "fabric_block_view_api_v2";  
    public static final String RAW_MOD_ID = "fabric-block-view-api-v2";  

    public GeneratedEntryPoint(net.neoforged.bus.api.IEventBus bus) {
        
        
        
    }
}