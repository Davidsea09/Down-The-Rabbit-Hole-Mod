package org.sinytra.fabric.rendering.generated;

@net.neoforged.fml.common.Mod(GeneratedEntryPoint.MOD_ID)
public class GeneratedEntryPoint {
    public static final String MOD_ID = "fabric_rendering_v1";  
    public static final String RAW_MOD_ID = "fabric-rendering-v1";  

    public GeneratedEntryPoint(net.neoforged.bus.api.IEventBus bus) {
        
        // Initialize client entrypoints
        if (net.neoforged.fml.loading.FMLEnvironment.dist.isClient()) {
            new org.sinytra.fabric.rendering.generated.FabricRenderingV1().onInitializeClient();
        }
        
        
    }
}