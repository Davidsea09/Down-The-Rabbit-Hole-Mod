package io.wispforest.owo.network;

import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.jetbrains.annotations.ApiStatus;

import java.util.Set;

@ApiStatus.Internal
@OnlyIn(Dist.CLIENT)
public class QueuedChannelSet {
    public static Set<ResourceLocation> channels;
}
