package io.wispforest.owo.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import io.wispforest.owo.ui.util.MatrixStackTransformer;
import net.minecraft.client.gui.GuiGraphics;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(GuiGraphics.class)
public abstract class DrawContextMixin implements MatrixStackTransformer {

    @Shadow public abstract PoseStack getMatrices();

    @Override
    public PoseStack getMatrixStack() {
        return getMatrices();
    }
}
