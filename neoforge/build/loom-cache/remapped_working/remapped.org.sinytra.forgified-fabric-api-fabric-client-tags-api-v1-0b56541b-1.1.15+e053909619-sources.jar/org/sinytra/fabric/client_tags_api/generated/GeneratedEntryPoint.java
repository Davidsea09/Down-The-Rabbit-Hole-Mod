package org.sinytra.fabric.client_tags_api.generated;

@net.neoforged.fml.common.Mod(GeneratedEntryPoint.MOD_ID)
public class GeneratedEntryPoint {
    public static final String MOD_ID = "fabric_client_tags_api_v1";  
    public static final String RAW_MOD_ID = "fabric-client-tags-api-v1";  

    public GeneratedEntryPoint(net.neoforged.bus.api.IEventBus bus) {
        
        
        
    }
}