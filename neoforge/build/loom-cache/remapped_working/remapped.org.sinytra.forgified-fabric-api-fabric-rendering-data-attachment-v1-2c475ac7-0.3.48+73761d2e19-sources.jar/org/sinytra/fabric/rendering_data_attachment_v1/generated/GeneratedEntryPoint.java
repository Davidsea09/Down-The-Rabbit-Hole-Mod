package org.sinytra.fabric.rendering_data_attachment_v1.generated;

@net.neoforged.fml.common.Mod(GeneratedEntryPoint.MOD_ID)
public class GeneratedEntryPoint {
    public static final String MOD_ID = "fabric_rendering_data_attachment_v1";  
    public static final String RAW_MOD_ID = "fabric-rendering-data-attachment-v1";  

    public GeneratedEntryPoint(net.neoforged.bus.api.IEventBus bus) {
        
        
        
    }
}