package software.bernie.geckolib.renderer.layer.vanilla;

import software.bernie.geckolib.animatable.GeoAnimatable;
import software.bernie.geckolib.renderer.GeoObjectRenderer;

import java.util.function.Function;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.entity.Entity;
import net.minecraft.world.World;

/**
 * Built-in implementation of {@link AttachedAnimatableRenderLayer} specifically for {@link GeoObjectRenderer} rendering
 * <p>
 * This handles the vast majority of the boilerplate code for rendering a GeoObjectRenderer on a vanilla entity
 */
public abstract class GeoObjectVanillaRenderLayer<A extends GeoAnimatable, T extends Entity, M extends EntityModel<T>, R extends GeoObjectRenderer<A>> extends AttachedAnimatableRenderLayer<A, T, M, R> {
	/**
	 * Create a new {@link FeatureRenderer} instance
	 *
	 * @param renderer The vanilla renderer instance that the layer is being added to
	 * @param instanceFactory A factory that creates a new GeoObjectRenderer instance for rendering
	 */
	public GeoObjectVanillaRenderLayer(FeatureRendererContext<T, M> renderer, Function<World, A> instanceFactory) {
		super(renderer, instanceFactory);
	}
}
