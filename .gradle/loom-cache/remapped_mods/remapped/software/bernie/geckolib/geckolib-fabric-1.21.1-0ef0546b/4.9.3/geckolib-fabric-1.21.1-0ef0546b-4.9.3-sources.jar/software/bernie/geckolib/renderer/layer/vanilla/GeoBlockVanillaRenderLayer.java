package software.bernie.geckolib.renderer.layer.vanilla;

import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoAnimatable;
import software.bernie.geckolib.animatable.GeoBlockEntity;
import software.bernie.geckolib.renderer.GeoBlockRenderer;
import software.bernie.geckolib.renderer.GeoRenderer;

import java.util.function.Function;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.block.entity.BlockEntityRenderDispatcher;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.entity.Entity;
import net.minecraft.world.World;

/**
 * Built-in implementation of {@link AttachedAnimatableRenderLayer} specifically for {@link GeoBlockEntity} rendering
 * <p>
 * This handles the vast majority of the boilerplate code for rendering a GeoBlockEntity on a vanilla entity
 */
public abstract class GeoBlockVanillaRenderLayer<A extends BlockEntity & GeoBlockEntity, T extends Entity, M extends EntityModel<T>, R extends GeoBlockRenderer<A>> extends AttachedAnimatableRenderLayer<A, T, M, R> {
	/**
	 * Create a new {@link FeatureRenderer} instance to render a {@link GeoBlockEntity} on a vanilla entity model
	 *
	 * @param renderer        The vanilla renderer instance that the layer is being added to
	 * @param instanceFactory A factory that creates a new GeoBlockEntity instance for rendering
	 */
	public GeoBlockVanillaRenderLayer(FeatureRendererContext<T, M> renderer, Function<World, A> instanceFactory) {
		super(renderer, instanceFactory);
	}
	/**
	 * Get the {@link GeoRenderer} instance for this {@link GeoAnimatable}
	 */
	/**
	 * Get the {@link GeoRenderer} instance for this {@link GeoBlockEntity}
	 */
	@Override
	protected @Nullable R getRenderer(A animatable) {
		final BlockEntityRenderDispatcher blockRenderers = MinecraftClient.getInstance().getBlockEntityRenderDispatcher();
		
		//noinspection unchecked
		return blockRenderers.get(animatable) instanceof GeoBlockRenderer<? super A> geoRenderer ? (R)geoRenderer : null;
	}
}
