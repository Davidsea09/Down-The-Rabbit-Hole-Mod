package software.bernie.geckolib.renderer.layer.vanilla;

import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoAnimatable;
import software.bernie.geckolib.renderer.GeoRenderer;

import java.lang.ref.WeakReference;
import java.util.function.Function;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.world.World;

/**
 * Generified {@link FeatureRenderer} implementation for rendering {@link GeoAnimatable} instances on a non-GeckoLib model
 * <p>
 * This layer handles the boilerplate for performing the rendering and optional animations but expects the user
 * to handle the specifics of positioning and typing
 */
public abstract class AttachedAnimatableRenderLayer<A extends GeoAnimatable, T extends Entity, M extends EntityModel<T>, R extends GeoRenderer<A>> extends FeatureRenderer<T, M> {
    private final Function<@Nullable World, @Nullable A> instanceCache = new Function<@Nullable World, A>() {
        private @Nullable WeakReference<A> cachedInstance = null;
        
        @Override
        @Contract("null->null;!null->!null")
        public @Nullable A apply(@Nullable World level) {
            if (level == null) {
                this.cachedInstance = null;
                
                return null;
            }
            
            A instance;
            
            if (this.cachedInstance == null || (instance = this.cachedInstance.get()) == null)
                this.cachedInstance = new WeakReference<>(instance = AttachedAnimatableRenderLayer.this.instanceFactory.apply(level));
            
            return instance;
        }
    };
    private final Function<World, A> instanceFactory;
    
    /**
     * Create a new {@link FeatureRenderer} instance
     *
     * @param renderer The vanilla renderer instance that the layer is being added to
     * @param instanceFactory A factory that creates a new GeoAnimatable instance for rendering
     */
    public AttachedAnimatableRenderLayer(FeatureRendererContext<T, M> renderer, Function<World, A> instanceFactory) {
        super(renderer);
        
        this.instanceFactory = instanceFactory;
    }
    
    /**
     * Perform the actual render operation for rendering the {@link GeoAnimatable} on the target entity's model
     * <p>
     * Handle any model attachment translations or rotations here<br/>
     * E.G.
     * <pre>
     *    {@code
     *      final ModelPart head = model.getHead();
     *
     *      poseStack.mulPose(Axis.YP.rotation(head.yRot));
     *      poseStack.mulPose(Axis.XP.rotation(head.xRot));
     *      poseStack.mulPose(Axis.ZP.rotation(head.zRot));
     *
     *      renderer.render(animatable, 0, partialTick, poseStack, bufferSource, packedLight);
     *    }
     * </pre>
     */
    protected abstract void renderAnimatableOnModel(T entity, A animatable, M model, R renderer, MatrixStack poseStack, VertexConsumerProvider bufferSource, float partialTick, int packedLight, float ageInTicks,
                                                    float limbSwing, float limbSwingAmount, float netHeadYaw, float headPitch);
    
    /**
     * Get the {@link GeoRenderer} instance for this {@link GeoAnimatable}
     */
    protected abstract @Nullable R getRenderer(A animatable);
    
    /**
     * Determine whether this {@link FeatureRenderer} should render at the current time
     */
    protected boolean shouldRender(T entity) {
        return true;
    }
    
    /**
     * Get the {@link GeoAnimatable} instance for rendering
     */
    public @Nullable A getAnimatableInstance(T entity) {
        final A animatable = this.instanceCache.apply(entity.getWorld());
        
        if (animatable != null)
            updateAnimatableTick(animatable, entity.age);
        
        return animatable;
    }
    
    /**
     * Set the tick for the {@link GeoAnimatable} instance to be rendered
     * <p>
     * This should be set every render pass immediately before rendering it
     */
    protected void updateAnimatableTick(A instance, int tick) {
        if (instance instanceof Entity geoEntity)
            geoEntity.age = tick;
    }
    
    /**
     * @see AttachedAnimatableRenderLayer#renderAnimatableOnModel
     */
    @Override
    public void render(MatrixStack poseStack, VertexConsumerProvider bufferSource, int packedLight, T entity, float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if (!shouldRender(entity))
            return;
        
        final A animatable = getAnimatableInstance(entity);
        final R renderer;
        
        if (animatable == null || (renderer = getRenderer(animatable)) == null)
            return;
        
        poseStack.push();
        renderAnimatableOnModel(entity, animatable, getContextModel(), renderer, poseStack, bufferSource, partialTick, packedLight, ageInTicks, limbSwing, limbSwingAmount, netHeadYaw, headPitch);
        poseStack.pop();
    }
}