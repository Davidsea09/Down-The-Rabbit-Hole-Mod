package software.bernie.geckolib.loading.math;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.mojang.datafixers.util.Either;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.Util;
import org.apache.logging.log4j.Level;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.GeckoLibConstants;
import software.bernie.geckolib.loading.math.function.MathFunction;
import software.bernie.geckolib.loading.math.function.generic.*;
import software.bernie.geckolib.loading.math.function.limit.ClampFunction;
import software.bernie.geckolib.loading.math.function.limit.MaxFunction;
import software.bernie.geckolib.loading.math.function.limit.MinFunction;
import software.bernie.geckolib.loading.math.function.misc.PiFunction;
import software.bernie.geckolib.loading.math.function.misc.ToDegFunction;
import software.bernie.geckolib.loading.math.function.misc.ToRadFunction;
import software.bernie.geckolib.loading.math.function.random.DieRollFunction;
import software.bernie.geckolib.loading.math.function.random.DieRollIntegerFunction;
import software.bernie.geckolib.loading.math.function.random.RandomFunction;
import software.bernie.geckolib.loading.math.function.random.RandomIntegerFunction;
import software.bernie.geckolib.loading.math.function.round.*;
import software.bernie.geckolib.loading.math.value.*;
import software.bernie.geckolib.util.CompoundException;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.DoubleSupplier;
import java.util.function.Supplier;
import java.util.regex.Pattern;

/**
 * Mathematical expression parser that breaks down String-expressions into tokenised objects that can be used for automated computation.
 * <p>
 * Original design: <a href="https://github.com/fadookie/particleman/tree/be1ce93c3cbd0f894742e3f41c0c6b23880be046/mclib">McLib - McHorse, Eliot Lash, Hiroku</a>
 * under <a href="https://github.com/fadookie/particleman/blob/be1ce93c3cbd0f894742e3f41c0c6b23880be046/LICENSE-mclib.md">MIT License</a>
 * <p>
 * Overhauled by Tslat for GeckoLib and redesigned specifically for <a href="https://learn.microsoft.com/en-us/minecraft/creator/reference/content/molangreference/examples/molangconcepts/molangintroduction?view=minecraft-bedrock-stable">Molang</a> use
 */
public class MathParser {
    private static final Pattern EXPRESSION_FORMAT = Pattern.compile("^[\\w\\s_+-/*%^&|<>=!?:;.,(){}]+$");
    private static final Pattern WHITESPACE = Pattern.compile("\\s");
    private static final Pattern NUMERIC = Pattern.compile("^-?(\\d+(\\.\\d+)?|\\.\\d+)$");
    private static final Pattern VARIABLE_FORMAT = Pattern.compile("^[a-z_]+\\.[\\w+_]+$");
    private static final Pattern VALID_DOUBLE = Pattern.compile("[\\x00-\\x20]*[+-]?(NaN|Infinity|((((\\d+)(\\.)?((\\d+)?)([eE][+-]?(\\d+))?)|(\\.(\\d+)([eE][+-]?(\\d+))?)|(((0[xX](\\p{XDigit}+)(\\.)?)|(0[xX](\\p{XDigit}+)?(\\.)(\\p{XDigit}+)))[pP][+-]?(\\d+)))[fFdD]?))[\\x00-\\x20]*");
    private static final String MOLANG_RETURN = "return";
    private static final String STATEMENT_DELIMITER = ";";
    private static final Map<String, MathFunction.Factory<?>> FUNCTION_FACTORIES = Util.make(new ConcurrentHashMap<>(18), map -> {
        map.put("math.abs", AbsFunction::new);
        map.put("math.acos", ACosFunction::new);
        map.put("math.asin", ASinFunction::new);
        map.put("math.atan", ATanFunction::new);
        map.put("math.atan2", ATan2Function::new);
        map.put("math.ceil", CeilFunction::new);
        map.put("math.clamp", ClampFunction::new);
        map.put("math.cos", CosFunction::new);
        map.put("math.die_roll", DieRollFunction::new);
        map.put("math.die_roll_integer", DieRollIntegerFunction::new);
        map.put("math.exp", ExpFunction::new);
        map.put("math.floor", FloorFunction::new);
        map.put("math.hermite_blend", HermiteBlendFunction::new);
        map.put("math.lerp", LerpFunction::new);
        map.put("math.lerprotate", LerpRotFunction::new);
        map.put("math.ln", LogFunction::new);
        map.put("math.max", MaxFunction::new);
        map.put("math.min", MinFunction::new);
        map.put("math.min_angle", MinAngleFunction::new);
        map.put("math.mod", ModFunction::new);
        map.put("math.pi", PiFunction::new);
        map.put("math.pow", PowFunction::new);
        map.put("math.random", RandomFunction::new);
        map.put("math.random_integer", RandomIntegerFunction::new);
        map.put("math.round", RoundFunction::new);
        map.put("math.sin", SinFunction::new);
        map.put("math.sqrt", SqrtFunction::new);
        map.put("math.to_deg", ToDegFunction::new);
        map.put("math.to_rad", ToRadFunction::new);
        map.put("math.trunc", TruncateFunction::new);
    });

    /**
     * @return Whether a {@link MathFunction} has been registered under the given expression name
     */
    public static boolean isFunctionRegistered(String name) {
        return FUNCTION_FACTORIES.containsKey(name);
    }

    /**
     * Register a new {@link MathFunction} to be handled by GeckoLib for parsing and internal use.
     * <p>
     * Overrides are supported, but should be avoided unless specifically needed
     *
     * @param name The string representation of the function. This will be the parsed value from input math strings.
     * @param factory The constructor-factory for the given function
     */
    public static void registerFunction(String name, MathFunction.Factory<?> factory) {
        if (FUNCTION_FACTORIES.put(name, factory) != null)
            GeckoLibConstants.LOGGER.log(Level.WARN, "Duplicate registration of MathFunction: '" + name + "'. Ignore if intentional override");

        GeckoLibConstants.LOGGER.log(Level.DEBUG, "Registered MathFunction '" + name + "'");
    }

    /**
     * Construct a {@link MathFunction} from the given symbol and values
     *
     * @param name The expression name of the function
     * @param values The input values for the function
     * @return A new instance of the MathFunction
     */
    @Nullable
    public static <T extends MathFunction> T buildFunction(String name, MathValue... values) {
        if (!FUNCTION_FACTORIES.containsKey(name))
            return null;

        try {
            return (T)FUNCTION_FACTORIES.get(name).createAndValidate(values);
        }
        catch (IllegalArgumentException ex) {
            throw new CompoundException("Invalid math function arguments provided in Molang expression '" + name + "'")
                    .withMessage(ex.getMessage());
        }
    }

    /**
     * Register a new {@link Variable} with the math parsing system
     * <p>
     * Technically supports overriding by matching keys, though you should try to update the existing variable instances instead if possible
     */
    public static void registerVariable(Variable variable) {
        MolangQueries.registerVariable(variable);
    }

    /**
     * @return The registered {@link Variable} instance for the given name
     */
    public static Variable getVariableFor(String name) {
        return MolangQueries.getVariableFor(name);
    }

    /**
     * Set the value of a {@link Variable} in the Molang parser, creating a new Variable instance as needed
     *
     * @param name The name of the variable - this should match the name in the expression string
     * @param value The new value to set the Variable to
     */
    public static void setVariable(String name, DoubleSupplier value) {
        getVariableFor(name).set(value);
    }

    /**
     * Parse a JsonElement into a compiled {@link MathValue} instance, ready for use
     */
    public static MathValue parseJson(JsonElement element) {
        if (!(element instanceof JsonPrimitive primitive) || primitive.isBoolean())
            throw new CompoundException("Bad formatting on Molang expression, expected single value, received: " + element.getClass().getSimpleName());

        if (primitive.isNumber())
            return new Constant(primitive.getAsDouble());

        if (primitive.isString()) {
            String value = primitive.getAsString();

            if (VALID_DOUBLE.matcher(value).matches())
                return new Constant(Double.parseDouble(value));

            return compileMolang(value);
        }

        return new Constant(0);
    }

    /**
     * A wrapper around the expression parsing system to optionally support Molang-specific handling for things like compound expressions
     *
     * @param expression The math and/or Molang expression to be parsed
     * @return A compiled {@link MathValue}, ready for use
     */
    public static MathValue compileMolang(String expression) {
        if (expression.isBlank())
            return new Constant(0);

        if (!EXPRESSION_FORMAT.matcher(expression).matches())
            throw new CompoundException("Invalid characters found in expression: '" + expression + "'");

        expression = WHITESPACE
                .matcher(expression)
                .replaceAll("")
                .toLowerCase(Locale.ROOT);

        if (expression.startsWith(MOLANG_RETURN)) {
            expression = expression.substring(MOLANG_RETURN.length());

            if (expression.contains(STATEMENT_DELIMITER))
                expression = expression.substring(0, expression.indexOf(STATEMENT_DELIMITER));
        }
        else if (expression.contains(STATEMENT_DELIMITER)) {
            final String[] subExpressions = expression.split(STATEMENT_DELIMITER);
            final List<MathValue> subValues = new ObjectArrayList<>(subExpressions.length);

            for (String subExpression : subExpressions) {
                if (subExpression.isBlank())
                    continue;

                boolean isReturn = subExpression.startsWith(MOLANG_RETURN);

                if (isReturn)
                    subExpression = subExpression.substring(MOLANG_RETURN.length());

                subValues.add(compileExpression(subExpression));

                if (isReturn)
                    break;
            }

            if (subValues.isEmpty())
                return new Constant(0);

            return new CompoundValue(subValues.toArray(new MathValue[0]));
        }

        return compileExpression(expression);
    }

    /**
     * Parse and compile a full expression into a single {@link MathValue} object
     */
    public static MathValue compileExpression(String expression) {
        try {
            return parseSymbols(compileSymbols(decomposeExpression(expression)));
        }
        catch (CompoundException ex) {
            throw ex.withMessage("Failed to parse expression '" + expression + "'");
        }
    }

    /**
     * Break down an expression into component characters, sanity-checking for unbalanced groups
     */
    public static char[] decomposeExpression(String expression) throws CompoundException {
        final char[] chars = expression.toCharArray();
        int groupState = 0;
        int curlyBraceState = 0;

        for (char character : chars) {
            switch (character) {
                case '(' -> groupState++;
                case ')' -> groupState--;
                case '{' -> curlyBraceState++;
                case '}' -> curlyBraceState--;
                default -> {}
            }


            if (character == '(') {
                groupState++;
            }
            else if (character == ')') {
                groupState--;
            }
            
            if (groupState < 0)
                throw new CompoundException("Closing parenthesis before opening parenthesis in expression '" + expression + "'");

            if (curlyBraceState < 0)
                throw new CompoundException("Closing curly brace before opening curly brace in expression '" + expression + "'");
        }
        
        if (groupState != 0)
            throw new CompoundException("Uneven parenthesis in expression, each opening brace must have a pairing close brace '" + expression + "'");

        if (curlyBraceState != 0)
            throw new CompoundException("Uneven curly braces in expression, each opening brace must have a pairing close brace '" + expression + "'");

        return chars;
    }

    /**
     * Attempt to construct the most relevant operator given the input character array and start index
     * <p>
     * This allows for arbitrary-length operators and best-matching for partially-colliding operators
     */
    @Nullable
    protected static String tryMergeOperativeSymbols(char[] chars, int index) {
        char ch = chars[index];

        if (!Operator.isOperativeSymbol(ch))
            return null;

        int maxLength = Math.min(chars.length - index, Operator.maxOperatorLength());

        for (int length = maxLength; length > 0; length--) {
            String testOperator = String.copyValueOf(chars, index, length);

            if (Operator.isOperator(testOperator))
                return testOperator;
        }

        if (ch == '?' || ch == ':' || ch == ',')
            return String.valueOf(ch);

        return null;
    }

    /**
     * Compile a collection of 'symbols' from the given char array representing the expression split into individual characters
     *
     * @return A list of either string symbols, or a group of pre-compiled arguments of a grouping
     * <p>
     * This list is formatted such that each entry is either:
     * <ul>
     *     <li>A self-contained value or expression</li>
     *     <li>A pre-compiled {@link MathValue} representing an expression group</li>
     *     <li>A {@link MathFunction} name immediately followed by a pre-compiled {@link MathValue} argument group</li>
     * </ul>
     */
    public static List<Either<String, List<MathValue>>> compileSymbols(char[] chars) {
        final List<Either<String, List<MathValue>>> symbols = new ObjectArrayList<>();
        final StringBuilder buffer = new StringBuilder();
        int lastSymbolIndex = -1;

        for (int i = 0; i < chars.length; i++) {
            final char ch = chars[i];

            if (ch == '-' && buffer.isEmpty() && (symbols.isEmpty() || lastSymbolIndex == symbols.size() - 1)) {
                buffer.append(ch);

                continue;
            }

            final String operator = tryMergeOperativeSymbols(chars, i);

            if (operator != null) {
                i += operator.length() - 1;

                if (!buffer.isEmpty())
                    symbols.add(Either.left(buffer.toString()));

                lastSymbolIndex = symbols.size();

                symbols.add(Either.left(operator));
                buffer.setLength(0);
            }
            else if (ch == '(') {
                if (!buffer.isEmpty()) {
                    symbols.add(Either.left(buffer.toString()));
                    buffer.setLength(0);
                }

                List<MathValue> subValues = new ObjectArrayList<>();
                int groupState = 1;

                for (int j = i + 1; j < chars.length; j++) {
                    final char groupChar = chars[j];

                    if (groupChar == '(') {
                        groupState++;
                    }
                    else if (groupChar == ')') {
                        groupState--;
                    }
                    else if (groupChar == ',' && groupState == 1) {
                        subValues.add(parseSymbols(compileSymbols(buffer.toString().toCharArray())));
                        buffer.setLength(0);

                        continue;
                    }

                    if (groupState == 0) {
                        if (!buffer.isEmpty()) {
                            if (!symbols.isEmpty() && symbols.getLast().left().filter("-"::equals).isPresent() &&
                                (symbols.size() == 1 || symbols.get(symbols.size() - 2).left().filter(Operator::isOperator).isPresent())) {
                                symbols.removeLast();
                                subValues.add(new Negative(parseSymbols(compileSymbols(buffer.toString().toCharArray()))));
                            }
                            else {
                                subValues.add(parseSymbols(compileSymbols(buffer.toString().toCharArray())));
                            }
                        }

                        i = j;

                        symbols.add(Either.right(subValues));
                        buffer.setLength(0);

                        break;
                    }
                    else {
                        buffer.append(groupChar);
                    }
                }
            }
            else {
                buffer.append(ch);
            }
        }

        if (!buffer.isEmpty())
            symbols.add(Either.left(buffer.toString()));

        return symbols;
    }

    /**
     * Compiles a given raw list of {@link #compileSymbols(char[]) symbols} into a singular {@link MathValue}, ready for use
     *
     * @throws CompoundException If the given symbols list cannot be compiled down into a MathValue
     */
    public static MathValue parseSymbols(List<Either<String, List<MathValue>>> symbols) throws CompoundException {
        if (symbols.size() == 2) {
            Optional<String> prefix = symbols.getFirst().left().filter(left -> left.startsWith("-") || left.startsWith("!") || isFunctionRegistered(left));
            Optional<List<MathValue>> group = symbols.get(1).right();

            if (prefix.isPresent() && group.isPresent())
                return compileFunction(prefix.get(), group.get());
        }

        MathValue value = compileValue(symbols);

        if (value != null)
            return value;

        throw new CompoundException("Unable to parse compiled symbols from expression: " + symbols);
    }

    /**
     * Compile the given {@link #compileSymbols(char[]) symbols} down into a singular {@link MathValue}, ready for use
     *
     * @return A compiled MathValue instance, or null if not applicable
     * @throws CompoundException If there is a parsing failure for any of the contents of the symbols
     */
    @Nullable
    protected static MathValue compileValue(List<Either<String, List<MathValue>>> symbols) throws CompoundException {
        if (symbols.size() == 1)
            return compileSingleValue(symbols.getFirst());

        final MathValue assignment = compileAssignment(symbols);

        if (assignment != null)
            return assignment;

        Ternary ternary = compileTernary(symbols);

        if (ternary != null)
            return ternary;

        return compileCalculation(symbols);
    }

    /**
     * Compile a singular-argument {@link MathValue} instance from the given symbols list, if applicable
     *
     * @return A compiled MathValue value, or null if not applicable
     * @throws CompoundException If there is a parsing failure for any of the contents of the symbols
     */
    @Nullable
    protected static MathValue compileSingleValue(Either<String, List<MathValue>> symbol) throws CompoundException {
        if (symbol.right().isPresent())
            return new Group(symbol.right().get().getFirst());

        return symbol.left().map(string -> {
            if (string.startsWith("!"))
                return new BooleanNegate(compileSingleValue(Either.left(string.substring(1))));

            if (isNumeric(string))
                return new Constant(Double.parseDouble(string));

            final boolean isNegative = string.startsWith("-");

            if (isNegative)
                string = string.substring(1);

            if (isLikelyVariable(string)) {
                final Variable variable = getVariableFor(string);

                if (isNegative)
                    return new Negative(variable);

                return variable;
            }

            if (isFunctionRegistered(string)) {
                final MathValue function = compileFunction(string, List.of());

                if (isNegative)
                    return new Negative(function);

                return function;
            }

            return null;
        }).orElse(null);
    }

    /**
     * Compile a {@link VariableAssignment} value instance from the given symbols list, if applicable
     *
     * @return A compiled VariableAssignment value, or empty if an assignment does not apply to the provided symbols
     * @throws CompoundException If there is a parsing failure for any of the contents of the symbols
     */
    protected static @Nullable MathValue compileAssignment(List<Either<String, List<MathValue>>> symbols) throws CompoundException {
        if (symbols.size() < 3 || symbols.get(1).left().filter(Operator.ASSIGN_VARIABLE.symbol()::equals).isEmpty())
            return null;

        if (!(parseSymbols(symbols.subList(0, 1)) instanceof Variable variable))
            throw new CompoundException("Attempted to assign a value to a non-variable");

        return new VariableAssignment(variable, parseSymbols(symbols.subList(2, symbols.size())));
    }

    /**
     * Compile a MathValue value instance from the given symbols list, if applicable
     *
     * @return A compiled {@link Calculation} or {@link VariableAssignment} value, or null if not applicable
     * @throws CompoundException If there is a parsing failure for any of the contents of the symbols
     */
    @Nullable
    protected static MathValue compileCalculation(List<Either<String, List<MathValue>>> symbols) throws CompoundException  {
        if (symbols.size() < 3)
            return null;

        final int symbolCount = symbols.size();
        final List<Operator> operators = new ObjectArrayList<>(symbolCount / 2);
        final List<MathValue> components = new ObjectArrayList<>(symbolCount / 2 + 1);
        int lastOperatorIndex = -1;

        for (int i = 0; i < symbolCount; i++) {
            final Operator operator = symbols.get(i).left()
                    .filter(Operator::isOperator)
                    .map(MathParser::getOperatorFor).orElse(null);

            if (operator == null)
                continue;

            if (operator == Operator.ASSIGN_VARIABLE) {
                if (!(parseSymbols(symbols.subList(0, i)) instanceof Variable variable))
                    throw new CompoundException("Attempted to assign a value to a non-variable");

                return new VariableAssignment(variable, parseSymbols(symbols.subList(i + 1, symbolCount)));
            }

            components.add(parseSymbols(symbols.subList(lastOperatorIndex + 1, i)));
            operators.add(operator);
            lastOperatorIndex = i;
        }

        if (components.isEmpty())
            return null;

        components.add(parseSymbols(symbols.subList(lastOperatorIndex + 1, symbolCount)));

        do {
            Operator lastOperator = null;
            int highestOperatorIndex = -1;

            for (int i = 0; i < operators.size(); i++) {
                Operator operator = operators.get(i);

                if (lastOperator == null || operator.takesPrecedenceOver(lastOperator)) {
                    lastOperator = operator;
                    highestOperatorIndex = i;
                }
            }

            if (highestOperatorIndex == -1)
                break;

            components.add(highestOperatorIndex, new Calculation(lastOperator, components.get(highestOperatorIndex), components.get(highestOperatorIndex + 1)));
            operators.remove(highestOperatorIndex);
            components.remove(highestOperatorIndex + 1);
            components.remove(highestOperatorIndex + 1);
        }
        while (true);

        if (components.size() != 1)
            throw new CompoundException("Invalidly formatted expression: " + symbols);

        return components.getFirst();
    }

    /**
     * Compile a {@link Ternary} value instance from the given symbols list, if applicable
     *
     * @return A compiled Ternary value, or null if not applicable
     * @throws CompoundException If there is a parsing failure for any of the contents of the symbols
     */
    @Nullable
    protected static Ternary compileTernary(List<Either<String, List<MathValue>>> symbols) throws CompoundException  {
        final int symbolCount = symbols.size();

        if (symbolCount < 3)
            return null;

        Supplier<MathValue> condition = null;
        Supplier<MathValue> ifTrue = null;
        int ternaryState = 0;
        int matchingColon = -1;
        int queryIndex = -1;

        for (int i = 0; i < symbolCount; i++) {
            final int i2 = i;
            final String string = symbols.get(i).left().orElse(null);

            if ("?".equals(string)) {
                if (condition == null) {
                    condition = () -> parseSymbols(symbols.subList(0, i2));
                    queryIndex = i2 + 1;
                }

                ternaryState++;
            }
            else if (":".equals(string)) {
                if (ternaryState == 1 && ifTrue == null && queryIndex > 0) {
                    final int queryIndex2 = queryIndex;
                    ifTrue = () -> parseSymbols(symbols.subList(queryIndex2, i2));
                    matchingColon = i;
                }

                ternaryState--;
            }
        }

        if (ternaryState == 0 && condition != null && ifTrue != null && matchingColon < symbolCount - 1)
            return new Ternary(condition.get(), ifTrue.get(), parseSymbols(symbols.subList(matchingColon + 1, symbolCount)));

        return null;
    }

    /**
     * Compiles a {@link MathValue} for the given symbols list, if applicable.
     * <p>
     * Note that due to parsing flexibility, this method doesn't necessarily generate a {@link MathFunction}, as some calls may be for value-value pairs instead
     *
     * @param name The name of the function or value
     * @param args The symbols list for the value
     * @return A compiled MathValue, or null if not applicable
     * @throws CompoundException If there is a parsing failure for any of the contents of the symbols
     */
    @Nullable
    protected static MathValue compileFunction(String name, List<MathValue> args) throws CompoundException {
        if (name.startsWith("!")) {
            if (name.length() == 1) {
                if (args.isEmpty())
                    throw new CompoundException("Found empty expression group '!()'");

                return new BooleanNegate(args.getFirst());
            }

            return new BooleanNegate(compileFunction(name.substring(1), args));
        }

        if (name.startsWith("-")) {
            if (name.length() == 1) {
                if (args.isEmpty())
                    throw new CompoundException("Found empty expression group '-()'");

                return new Negative(args.getFirst());
            }

            return new Negative(compileFunction(name.substring(1), args));
        }

        if (!isFunctionRegistered(name))
            return null;

        return buildFunction(name, args.toArray(new MathValue[0]));
    }

    /**
     * @deprecated Has no functional use, see {@link Operator#isOperator(String)}
     * @return Whether the given String should be considered an operator or operator-like symbol
     */
    @Deprecated(forRemoval = true)
    public static boolean isOperativeSymbol(char symbol) {
        return isOperativeSymbol(String.valueOf(symbol));
    }

    /**
     * @deprecated Has no functional use, see {@link Operator#isOperator(String)}
     * @return Whether the given String should be considered an operator or operator-like symbol
     */
    @Deprecated(forRemoval = true)
    public static boolean isOperativeSymbol(@NotNull String symbol) {
        return Operator.isOperator(symbol) || symbol.equals("?") || symbol.equals(":");
    }

    /**
     * Determine if the given string can be considered numeric, supporting both negative values and decimal values, but not strings omitting a preceding digit before a decimal point
     *
     * @return Whether the string is numeric
     */
    public static boolean isNumeric(String string) {
        return NUMERIC.matcher(string).matches();
    }

    /**
     * Get an {@link Operator} for a given operator string, throwing an exception if one does not exist
     */
    protected static Operator getOperatorFor(String op) throws CompoundException {
        return Operator.getOperatorFor(op).orElseThrow(() -> new CompoundException("Unknown operator symbol '" + op + "'"));
    }

    /**
     * Determine if the given string is likely to be a variable/function of some kind.
     * <p>
     * Functionally this is just a confirmation-by-elimination check, since names don't really have a defined form
     * @deprecated This is no longer used and isn't really a reliable check, try {@link #isFunctionRegistered(String)} or {@link #isLikelyVariable(String)}
     */
    @Deprecated(forRemoval = true)
    protected static boolean isQueryOrFunctionName(String string) {
        return !isNumeric(string) && !isOperativeSymbol(string);
    }

    /**
     * Determine if the given string is likely to be an existing or new variable declaration
     * <p>
     * Functionally this is just a confirmation-by-elimination check, since names don't really have a defined form
     */
    protected static boolean isLikelyVariable(String string) {
        if (MolangQueries.isExistingVariable(string))
            return true;

        return VARIABLE_FORMAT.matcher(string).matches() && !isFunctionRegistered(string) && !Operator.isOperator(string);
    }
}
