package org.sinytra.fabric.blockrenderlayer.generated;

@net.neoforged.fml.common.Mod(GeneratedEntryPoint.MOD_ID)
public class GeneratedEntryPoint {
    public static final String MOD_ID = "fabric_blockrenderlayer_v1";  
    public static final String RAW_MOD_ID = "fabric-blockrenderlayer-v1";  

    public GeneratedEntryPoint(net.neoforged.bus.api.IEventBus bus) {
        
        // Initialize client entrypoints
        if (net.neoforged.fml.loading.FMLEnvironment.dist.isClient()) {
            new org.sinytra.fabric.blockrenderlayer.FabricBlockrenderlayerApiV1().onInitializeClient();
        }
        
        
    }
}