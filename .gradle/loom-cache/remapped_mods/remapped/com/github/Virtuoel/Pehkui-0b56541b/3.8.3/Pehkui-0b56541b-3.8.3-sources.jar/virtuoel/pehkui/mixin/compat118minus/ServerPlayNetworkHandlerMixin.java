package virtuoel.pehkui.mixin.compat118minus;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_3244.class)
public class ServerPlayNetworkHandlerMixin
{
	@WrapOperation(method = "onPlayerInteractEntity", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayerEntity;squaredDistanceTo(Lnet/minecraft/entity/Entity;)D"))
	private double pehkui$onPlayerInteractEntity$squaredDistanceTo(class_3222 player, class_1297 entity, Operation<Double> original)
	{
		final class_243 eyePos = ScaleUtils.getEyePos(player);
		final float margin = entity.method_5871();
		
		class_238 box = entity.method_5829().method_1014(margin);
		
		final float interactionWidth = ScaleUtils.getInteractionBoxWidthScale(entity);
		final float interactionHeight = ScaleUtils.getInteractionBoxHeightScale(entity);
		
		if (interactionWidth != 1.0F || interactionHeight != 1.0F)
		{
			final double scaledXLength = box.method_17939() * 0.5D * (interactionWidth - 1.0F);
			final double scaledYLength = box.method_17940() * 0.5D * (interactionHeight - 1.0F);
			final double scaledZLength = box.method_17941() * 0.5D * (interactionWidth - 1.0F);
			final double scaledMarginWidth = margin * (interactionWidth - 1.0F);
			final double scaledMarginHeight = margin * (interactionHeight - 1.0F);
			
			box = box.method_1009(scaledXLength + scaledMarginWidth, scaledYLength + scaledMarginHeight, scaledZLength + scaledMarginWidth);
		}
		
		final double nearestX;
		if (eyePos.field_1352 < box.field_1323)
		{
			nearestX = box.field_1323;
		}
		else if (eyePos.field_1352 > box.field_1320)
		{
			nearestX = box.field_1320;
		}
		else
		{
			nearestX = eyePos.field_1352;
		}
		
		final double nearestY;
		if (eyePos.field_1351 < box.field_1322)
		{
			nearestY = box.field_1322;
		}
		else if (eyePos.field_1351 > box.field_1325)
		{
			nearestY = box.field_1325;
		}
		else
		{
			nearestY = eyePos.field_1351;
		}
		
		final double nearestZ;
		if (eyePos.field_1350 < box.field_1321)
		{
			nearestZ = box.field_1321;
		}
		else if (eyePos.field_1350 > box.field_1324)
		{
			nearestZ = box.field_1324;
		}
		else
		{
			nearestZ = eyePos.field_1350;
		}
		
		return eyePos.method_1028(nearestX, nearestY, nearestZ);
	}
}
