package virtuoel.pehkui.mixin.client.compat1201minus.compat120plus;

import java.util.Map;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_332;
import net.minecraft.class_4048;
import net.minecraft.class_490;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;

import it.unimi.dsi.fastutil.objects.Object2ObjectLinkedOpenHashMap;
import virtuoel.pehkui.api.ScaleData;
import virtuoel.pehkui.api.ScaleRegistries;
import virtuoel.pehkui.api.ScaleType;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ReflectionUtils;

@Mixin(class_490.class)
public abstract class InventoryScreenMixin
{
	@Unique private static final ThreadLocal<Map<ScaleType, ScaleData>> pehkui$SCALES = ThreadLocal.withInitial(Object2ObjectLinkedOpenHashMap::new);
	@Unique private static final ScaleData pehkui$IDENTITY = ScaleData.Builder.create().build();
	
	@Dynamic
	@Inject(method = MixinConstants.DRAW_ENTITY_NO_TRANSLATION, at = @At(value = "HEAD"))
	private static void pehkui$drawEntity$head(class_332 drawContext, int x, int y, int k, Quaternionf quaternionf, @Nullable Quaternionf quaternionf2, class_1309 entity, CallbackInfo info, @Share("bounds") LocalRef<class_238> bounds)
	{
		final Map<ScaleType, ScaleData> scales = pehkui$SCALES.get();
		
		ScaleData data;
		ScaleData cachedData;
		for (final ScaleType type : ScaleRegistries.SCALE_TYPES.values())
		{
			cachedData = scales.computeIfAbsent(type, t -> ScaleData.Builder.create().type(t).build());
			data = type.getScaleData(entity);
			cachedData.fromScale(data, false);
			data.fromScale(pehkui$IDENTITY, false);
		}
		
		bounds.set(entity.method_5829());
		
		final class_4048 dims = entity.method_18377(entity.method_18376());
		final class_243 pos = entity.method_19538();
		final double r = ReflectionUtils.getDimensionsWidth(dims) / 2.0D;
		final double h = ReflectionUtils.getDimensionsHeight(dims);
		final double xPos = pos.field_1352;
		final double yPos = pos.field_1351;
		final double zPos = pos.field_1350;
		final class_238 box = new class_238(xPos - r, yPos, zPos - r, xPos + r, yPos + h, zPos + r);
		
		entity.method_5857(box);
	}
	
	@Dynamic
	@Inject(method = MixinConstants.DRAW_ENTITY_NO_TRANSLATION, at = @At(value = "RETURN"))
	private static void pehkui$drawEntity$return(class_332 drawContext, int i, int j, int k, Quaternionf quaternionf, @Nullable Quaternionf quaternionf2, class_1309 entity, CallbackInfo info, @Share("bounds") LocalRef<class_238> bounds)
	{
		final Map<ScaleType, ScaleData> scales = pehkui$SCALES.get();
		
		for (final ScaleType type : ScaleRegistries.SCALE_TYPES.values())
		{
			type.getScaleData(entity).fromScale(scales.get(type), false);
		}
		
		entity.method_5857(bounds.get());
	}
}
