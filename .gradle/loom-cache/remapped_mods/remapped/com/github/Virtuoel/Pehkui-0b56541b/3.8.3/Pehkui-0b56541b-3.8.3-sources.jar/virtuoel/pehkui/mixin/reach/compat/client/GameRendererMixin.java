package virtuoel.pehkui.mixin.reach.compat.client;

import net.minecraft.class_1297;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import virtuoel.pehkui.util.ReachEntityAttributesCompatibility;
import virtuoel.pehkui.util.ScaleRenderUtils;

@Mixin(value = class_757.class, priority = 990)
public class GameRendererMixin
{
	@Shadow @Final @Mutable
	class_310 client;
	
	@ModifyVariable(method = "updateCrosshairTarget", ordinal = 0, at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;getCameraPosVec(F)Lnet/minecraft/util/math/Vec3d;"))
	private double pehkui$updateCrosshairTarget$setDistance(double value, float tickDelta)
	{
		final class_1297 entity = client.method_1560();
		
		if (entity != null)
		{
			if (!ScaleRenderUtils.hasExtendedReach(client.field_1761))
			{
				final double baseEntityReach = client.field_1761.method_2920().method_8386() ? 5.0F : 4.5F;
				
				return ReachEntityAttributesCompatibility.INSTANCE.getAttackRange(client.field_1724, baseEntityReach);
			}
		}
		
		return value;
	}
	
	@ModifyVariable(method = "updateCrosshairTarget", ordinal = 0, at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;getRotationVec(F)Lnet/minecraft/util/math/Vec3d;"))
	private double pehkui$updateCrosshairTarget$fixDistance(double value, float tickDelta)
	{
		final class_1297 entity = client.method_1560();
		
		if (entity != null)
		{
			if (ScaleRenderUtils.hasExtendedReach(client.field_1761))
			{
				return ReachEntityAttributesCompatibility.INSTANCE.getAttackRange(client.field_1724, 6.0D);
			}
		}
		
		return value;
	}
	
	@ModifyVariable(method = "updateCrosshairTarget", ordinal = 1, at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;getRotationVec(F)Lnet/minecraft/util/math/Vec3d;"))
	private double pehkui$updateCrosshairTarget$fixSquaredDistance(double value, float tickDelta)
	{
		final class_1297 entity = client.method_1560();
		
		if (entity != null)
		{
			if (this.client.field_1765 == null || this.client.field_1765.method_17783() == class_239.class_240.field_1333)
			{
				final double baseEntityReach = ScaleRenderUtils.hasExtendedReach(client.field_1761) ? 6.0D : client.field_1761.method_2920().method_8386() ? 5.0F : 4.5F;
				final double entityReach = ReachEntityAttributesCompatibility.INSTANCE.getAttackRange(client.field_1724, baseEntityReach);
				final double entityReachSquared = entityReach * entityReach;
				
				return entityReachSquared;
			}
		}
		
		return value;
	}
}
