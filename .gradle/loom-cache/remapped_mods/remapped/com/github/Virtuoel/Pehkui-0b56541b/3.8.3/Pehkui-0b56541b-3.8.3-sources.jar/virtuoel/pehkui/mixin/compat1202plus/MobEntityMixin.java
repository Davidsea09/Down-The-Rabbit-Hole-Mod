package virtuoel.pehkui.mixin.compat1202plus;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_238;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1308.class)
public abstract class MobEntityMixin
{
	@WrapOperation(method = "getAttackBox", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/math/Box;expand(DDD)Lnet/minecraft/util/math/Box;"))
	private class_238 pehkui$getAttackBox$expand(class_238 obj, double x, double y, double z, Operation<class_238> original)
	{
		final float scale = ScaleUtils.getEntityReachScale((class_1297) (Object) this);
		
		if (scale != 1.0F)
		{
			x *= scale;
			z *= scale;
		}
		
		return original.call(obj, x, y, z);
	}
}
