package virtuoel.pehkui.mixin.compat1194plus;

import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin
{
	@ModifyArg(method = "updateLimbs(Z)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;updateLimbs(F)V"))
	private float pehkui$updateLimbs(float value)
	{
		return ScaleUtils.modifyLimbDistance(value, (class_1309) (Object) this);
	}
}
