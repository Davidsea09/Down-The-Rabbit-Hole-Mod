package virtuoel.pehkui.mixin;

import net.minecraft.class_1542;
import net.minecraft.class_238;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(value = class_1542.class, priority = 1010)
public class ItemEntityMixin
{
	@ModifyArg(method = "tryMerge", index = 1, at = @At(value = "INVOKE", target = "Lnet/minecraft/world/World;getEntitiesByClass(Ljava/lang/Class;Lnet/minecraft/util/math/Box;Ljava/util/function/Predicate;)Ljava/util/List;"))
	private class_238 pehkui$tryMerge$box(class_238 box)
	{
		final class_1542 self = (class_1542) (Object) this;
		final class_238 bounds = self.method_5829();
		
		final double xExpand = box.method_17939() - bounds.method_17939();
		final double yExpand = box.method_17940() - bounds.method_17940();
		final double zExpand = box.method_17941() - bounds.method_17941();
		final float widthScale = ScaleUtils.getBoundingBoxWidthScale(self);
		final float heightScale = ScaleUtils.getBoundingBoxHeightScale(self);
		
		return bounds.method_1009(
			widthScale != 1.0F ? widthScale * xExpand : xExpand,
			heightScale != 1.0F ? heightScale * yExpand : yExpand,
			widthScale != 1.0F ? widthScale * zExpand : zExpand);
	}
}
