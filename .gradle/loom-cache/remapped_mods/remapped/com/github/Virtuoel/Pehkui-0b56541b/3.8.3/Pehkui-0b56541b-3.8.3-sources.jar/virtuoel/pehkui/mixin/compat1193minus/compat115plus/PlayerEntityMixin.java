package virtuoel.pehkui.mixin.compat1193minus.compat115plus;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1657.class)
public abstract class PlayerEntityMixin
{
	@ModifyArg(method = "adjustMovementForSneaking", index = 1, at = @At(value = "INVOKE", target = "Lnet/minecraft/util/math/Box;offset(DDD)Lnet/minecraft/util/math/Box;"))
	private double pehkui$adjustMovementForSneaking$stepHeight(double stepHeight)
	{
		final float scale = ScaleUtils.getStepHeightScale((class_1297) (Object) this);
		
		return scale != 1.0F ? stepHeight * scale : stepHeight;
	}
}
