package virtuoel.pehkui.mixin.client.compat1206minus.compat115plus;

import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_927;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ReflectionUtils;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_927.class)
public class MobEntityRendererMixin<T extends class_1308>
{
	@Dynamic
	@Inject(method = MixinConstants.RENDER_LEASH, at = @At(value = "HEAD"))
	private <E extends class_1297> void pehkui$renderLeash$head(T entity, float tickDelta, class_4587 matrices, class_4597 provider, E holdingEntity, CallbackInfo info)
	{
		if (ReflectionUtils.getHoldingEntity(entity) != null)
		{
			final float inverseWidthScale = 1.0F / ScaleUtils.getModelWidthScale(entity, tickDelta);
			final float inverseHeightScale = 1.0F / ScaleUtils.getModelHeightScale(entity, tickDelta);
			
			matrices.method_22903();
			matrices.method_22905(inverseWidthScale, inverseHeightScale, inverseWidthScale);
			matrices.method_22903();
		}
	}
	
	@Dynamic
	@Inject(method = MixinConstants.RENDER_LEASH, at = @At(value = "RETURN"))
	private <E extends class_1297> void pehkui$renderLeash$return(T entity, float tickDelta, class_4587 matrices, class_4597 provider, E holdingEntity, CallbackInfo info)
	{
		if (ReflectionUtils.getHoldingEntity(entity) != null)
		{
			matrices.method_22909();
			matrices.method_22909();
		}
	}
}
