package virtuoel.pehkui.mixin.compat116plus;

import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import virtuoel.pehkui.util.PehkuiBlockStateExtensions;

@Mixin(class_4970.class_4971.class)
public abstract class AbstractBlockStateMixin implements PehkuiBlockStateExtensions
{
	@Shadow
	abstract class_265 getOutlineShape(class_1922 world, class_2338 pos);
	
	@Override
	public class_265 pehkui_getOutlineShape(class_1922 world, class_2338 pos)
	{
		return getOutlineShape(world, pos);
	}
	
	@Shadow
	abstract class_2248 getBlock();
	
	@Override
	public class_2248 pehkui_getBlock()
	{
		return getBlock();
	}
}
