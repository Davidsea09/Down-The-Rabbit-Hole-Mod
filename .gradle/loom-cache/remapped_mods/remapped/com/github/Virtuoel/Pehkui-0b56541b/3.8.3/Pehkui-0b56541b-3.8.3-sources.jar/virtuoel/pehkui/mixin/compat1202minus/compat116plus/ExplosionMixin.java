package virtuoel.pehkui.mixin.compat1202minus.compat116plus;

import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_5362;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1927.class)
public abstract class ExplosionMixin
{
	@Shadow @Final @Mutable float power;
	
	@Dynamic
	@Inject(at = @At("RETURN"), method = MixinConstants.EXPLOSION_WITH_DAMAGE_SOURCE_INIT)
	private void pehkui$construct(class_1937 world, @Nullable class_1297 entity, @Nullable class_1282 damageSource, @Nullable class_5362 explosionBehavior, double x, double y, double z, float power, boolean createFire, class_1927.class_4179 blockDestructionType, CallbackInfo info)
	{
		if (entity != null)
		{
			final float scale = ScaleUtils.getExplosionScale(entity);
			
			if (scale != 1.0F)
			{
				this.power *= scale;
			}
		}
	}
}
