package virtuoel.pehkui.mixin.reach.client.compat1204minus;

import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.class_310;
import net.minecraft.class_636;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_636.class)
public class ClientPlayerInteractionManagerMixin
{
	@Shadow @Final class_310 client;
	
	@Dynamic
	@ModifyReturnValue(method = MixinConstants.GET_REACH_DISTANCE, at = @At("RETURN"))
	private float pehkui$getReachDistance(float original)
	{
		if (client.field_1724 != null)
		{
			final float scale = ScaleUtils.getBlockReachScale(client.field_1724);
			
			if (scale != 1.0F)
			{
				return original * scale;
			}
		}
		
		return original;
	}
}
