package virtuoel.pehkui.mixin.compat1204minus.compat119plus;

import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3225;
import net.minecraft.class_3532;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(class_3225.class)
public class ServerPlayerInteractionManagerMixin
{
	@Shadow @Final @Mutable
	class_3222 player;
	
	@ModifyArg(method = "processBlockBreakingAction", index = 0, at = @At(value = "INVOKE", target = "Lnet/minecraft/util/math/Vec3d;squaredDistanceTo(Lnet/minecraft/util/math/Vec3d;)D"))
	private class_243 pehkui$processBlockBreakingAction$center(class_243 center)
	{
		final class_2338 pos = new class_2338(class_3532.method_15357(center.field_1352), class_3532.method_15357(center.field_1351), class_3532.method_15357(center.field_1350));
		final class_243 eye = player.method_33571();
		final class_2338 eyePos = new class_2338(class_3532.method_15357(eye.field_1352), class_3532.method_15357(eye.field_1351), class_3532.method_15357(eye.field_1350));
		
		final double xOffset = eye.method_10216() - center.method_10216();
		final double yOffset = eye.method_10214() - center.method_10214();
		final double zOffset = eye.method_10215() - center.method_10215();
		
		center = center.method_1031(
			eyePos.method_10263() == pos.method_10263() ? xOffset : xOffset < 0.0D ? -0.5D : 0.5D,
			eyePos.method_10264() == pos.method_10264() ? yOffset : yOffset < 0.0D ? -0.5D : 0.5D,
			eyePos.method_10260() == pos.method_10260() ? zOffset : zOffset < 0.0D ? -0.5D : 0.5D
		);
		
		return center;
	}
}
