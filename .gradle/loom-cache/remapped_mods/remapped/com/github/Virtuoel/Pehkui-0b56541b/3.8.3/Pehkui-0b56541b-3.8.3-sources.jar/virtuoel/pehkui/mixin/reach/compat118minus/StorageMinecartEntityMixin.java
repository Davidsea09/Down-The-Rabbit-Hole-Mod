package virtuoel.pehkui.mixin.reach.compat118minus;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1657;
import net.minecraft.class_1693;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1693.class)
public abstract class StorageMinecartEntityMixin
{
	@ModifyExpressionValue(method = "canPlayerUse", at = @At(value = "CONSTANT", args = "doubleValue=64.0D"))
	private double pehkui$canPlayerUse$distance(double value, class_1657 player)
	{
		final float scale = ScaleUtils.getEntityReachScale(player);
		return scale != 1.0F ? scale * scale * value : value;
	}
}
