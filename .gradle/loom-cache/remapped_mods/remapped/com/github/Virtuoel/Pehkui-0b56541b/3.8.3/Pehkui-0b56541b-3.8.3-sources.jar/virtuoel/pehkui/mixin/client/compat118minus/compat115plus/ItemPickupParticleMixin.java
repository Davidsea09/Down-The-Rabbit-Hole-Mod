package virtuoel.pehkui.mixin.client.compat118minus.compat115plus;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1297;
import net.minecraft.class_4184;
import net.minecraft.class_4588;
import net.minecraft.class_693;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_693.class)
public class ItemPickupParticleMixin
{
	@Shadow @Final @Mutable class_1297 interactingEntity;
	
	@ModifyExpressionValue(method = "buildGeometry", at = @At(value = "CONSTANT", args = "doubleValue=0.5D"))
	private double pehkui$buildGeometry$offset(double value, class_4588 vertexConsumer, class_4184 camera, float tickDelta)
	{
		final float scale = ScaleUtils.getEyeHeightScale(interactingEntity, tickDelta);
		
		if (scale != 1.0F)
		{
			return value * scale;
		}
		
		return value;
	}
}
