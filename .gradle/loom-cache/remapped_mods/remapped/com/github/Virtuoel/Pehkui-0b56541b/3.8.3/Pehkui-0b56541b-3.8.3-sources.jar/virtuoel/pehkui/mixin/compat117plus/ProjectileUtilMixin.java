package virtuoel.pehkui.mixin.compat117plus;

import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1675;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1675.class)
public class ProjectileUtilMixin
{
	@WrapOperation(method = "getEntityCollision(Lnet/minecraft/world/World;Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Box;Ljava/util/function/Predicate;F)Lnet/minecraft/util/hit/EntityHitResult;", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;getBoundingBox()Lnet/minecraft/util/math/Box;"))
	private static class_238 pehkui$getEntityCollision$getBoundingBox(class_1297 obj, Operation<class_238> original, class_1937 world, class_1297 except, class_243 vec3d, class_243 vec3d2, class_238 box, Predicate<class_1297> predicate, float value)
	{
		final class_238 bounds = original.call(obj);
		
		final float width = ScaleUtils.getBoundingBoxWidthScale(obj);
		final float height = ScaleUtils.getBoundingBoxHeightScale(obj);
		
		final float interactionWidth = ScaleUtils.getInteractionBoxWidthScale(obj);
		final float interactionHeight = ScaleUtils.getInteractionBoxHeightScale(obj);
		
		if (width != 1.0F || height != 1.0F || interactionWidth != 1.0F || interactionHeight != 1.0F)
		{
			final double scaledXLength = value * ((width * interactionWidth) - 1.0F);
			final double scaledYLength = value * ((height * interactionHeight) - 1.0F);
			final double scaledZLength = value * ((width * interactionWidth) - 1.0F);
			
			return bounds.method_1009(scaledXLength, scaledYLength, scaledZLength);
		}
		
		return bounds;
	}
	
	@WrapOperation(method = "raycast", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;getBoundingBox()Lnet/minecraft/util/math/Box;"))
	private static class_238 pehkui$raycast$getBoundingBox(class_1297 obj, Operation<class_238> original)
	{
		final class_238 bounds = original.call(obj);
		final float margin = obj.method_5871();
		
		final float interactionWidth = ScaleUtils.getInteractionBoxWidthScale(obj);
		final float interactionHeight = ScaleUtils.getInteractionBoxHeightScale(obj);
		
		if (interactionWidth != 1.0F || interactionHeight != 1.0F)
		{
			final double scaledXLength = bounds.method_17939() * 0.5D * (interactionWidth - 1.0F);
			final double scaledYLength = bounds.method_17940() * 0.5D * (interactionHeight - 1.0F);
			final double scaledZLength = bounds.method_17941() * 0.5D * (interactionWidth - 1.0F);
			final double scaledMarginWidth = margin * (interactionWidth - 1.0F);
			final double scaledMarginHeight = margin * (interactionHeight - 1.0F);
			
			return bounds.method_1009(scaledXLength + scaledMarginWidth, scaledYLength + scaledMarginHeight, scaledZLength + scaledMarginWidth);
		}
		
		return bounds;
	}
}
