package virtuoel.pehkui.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1405;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1405.class)
public class TrackTargetGoalMixin
{
	@Shadow class_1309 target;
	@Shadow @Final @Mutable class_1308 mob;
	
	@ModifyReturnValue(method = "getFollowRange", at = @At("RETURN"))
	private double pehkui$getFollowRange(double original)
	{
		class_1309 target = this.mob.method_5968();
		if (target == null && (target = this.target) == null)
		{
			return original;
		}
		
		final float scale = ScaleUtils.getVisibilityScale(target);
		
		return scale != 1.0F ? original * scale : original;
	}
}
