package virtuoel.pehkui.mixin.compat1204minus;

import net.minecraft.class_1297;
import net.minecraft.class_1682;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1682.class)
public abstract class ThrownEntityMixin
{
	@Dynamic @Shadow
	protected abstract float method_7490(); // UNMAPPED_METHOD
	
	@Dynamic
	@ModifyArg(method = "tick()V", index = 1, at = @At(value = "INVOKE", target = MixinConstants.THROWN_ENTITY_SET_VELOCITY))
	private double pehkui$tick$setVelocity(double value)
	{
		final float scale = ScaleUtils.getMotionScale((class_1297) (Object) this);
		
		if (scale != 1.0F)
		{
			return value + ((1.0F - scale) * method_7490());
		}
		
		return value;
	}
}
