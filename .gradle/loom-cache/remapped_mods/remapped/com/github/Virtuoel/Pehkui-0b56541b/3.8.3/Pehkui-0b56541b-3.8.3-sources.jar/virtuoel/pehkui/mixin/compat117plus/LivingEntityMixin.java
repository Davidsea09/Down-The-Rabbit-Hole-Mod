package virtuoel.pehkui.mixin.compat117plus;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin
{
	@ModifyExpressionValue(method = "damage(Lnet/minecraft/entity/damage/DamageSource;F)Z", at = @At(value = "CONSTANT", args = "doubleValue=0.4000000059604645D"))
	private double pehkui$damage$knockback(double value, class_1282 source, float amount)
	{
		final float scale = ScaleUtils.getKnockbackScale(source.method_5529());
		
		return scale != 1.0F ? scale * value : value;
	}
	
	@ModifyExpressionValue(method = "knockback(Lnet/minecraft/entity/LivingEntity;)V", at = @At(value = "CONSTANT", args = "doubleValue=0.5D"))
	private double pehkui$knockback$knockback(double value, class_1309 target)
	{
		final float scale = ScaleUtils.getKnockbackScale((class_1297) (Object) this);
		
		return scale != 1.0F ? scale * value : value;
	}
}
