package virtuoel.pehkui.mixin.reach.compat1204minus.compat1194plus;

import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(value = class_1263.class, priority = 990)
public interface InventoryMixin
{
	/**
	 * Computes reach distance from eye position to the edge of the block
	 * instead of to the center of the block
	 */
	@Dynamic
	@Overwrite // UNMAPPED_METHOD
	public static boolean method_49106(class_2586 blockEntity, class_1657 player, int range)
	{
		class_1937 world = blockEntity.method_10997();
		class_2338 pos = blockEntity.method_11016();
		
		if (world == null)
		{
			return false;
		}
		else if (world.method_8321(pos) != blockEntity)
		{
			return false;
		}
		else
		{
			double x = ((double) pos.method_10263()) + 0.5D;
			double y = ((double) pos.method_10264()) + 0.5D;
			double z = ((double) pos.method_10260()) + 0.5D;
			final class_243 eyePos = player.method_33571();
			x = (x - 0.5D) + ScaleUtils.getBlockXOffset(pos, player) - (eyePos.method_10216() - player.method_23317());
			y = (y - 0.5D) + ScaleUtils.getBlockYOffset(pos, player) - (eyePos.method_10214() - player.method_23318());
			z = (z - 0.5D) + ScaleUtils.getBlockZOffset(pos, player) - (eyePos.method_10215() - player.method_23321());
			final double reach = ScaleUtils.getBlockReachScale(player) * (double) range;
			return player.method_5649(x, y, z) <= reach * reach;
		}
	}
}
