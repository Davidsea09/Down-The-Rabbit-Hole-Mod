package virtuoel.pehkui.mixin.compat1206minus;

import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1668;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1668.class)
public abstract class ExplosiveProjectileEntityMixin
{
	@Dynamic
	@Shadow
	public double field_7601; // UNMAPPED_FIELD
	@Dynamic
	@Shadow
	public double field_7600; // UNMAPPED_FIELD
	@Dynamic
	@Shadow
	public double field_7599; // UNMAPPED_FIELD
	
	@Dynamic
	@Inject(at = @At("RETURN"), method = MixinConstants.EXPLOSIVE_PROJECTILE_ENTITY_INIT)
	private void pehkui$construct(class_1299<? extends class_1668> type, class_1309 owner, double directionX, double directionY, double directionZ, class_1937 world, CallbackInfo info)
	{
		final class_1668 self = (class_1668) (Object) this;
		final float scale = ScaleUtils.setScaleOfProjectile(self, owner);
		
		if (scale != 1.0F)
		{
			field_7601 *= scale;
			field_7600 *= scale;
			field_7599 *= scale;
		}
	}
}
