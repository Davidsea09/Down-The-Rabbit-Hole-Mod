package virtuoel.pehkui.mixin.compat1204minus;

import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_4048;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1657.class)
public class PlayerEntityMixin
{
	@Dynamic
	@ModifyReturnValue(method = MixinConstants.GET_DIMENSIONS, at = @At("RETURN"))
	private class_4048 pehkui$getDimensions(class_4048 original)
	{
		final float widthScale = ScaleUtils.getBoundingBoxWidthScale((class_1297) (Object) this);
		final float heightScale = ScaleUtils.getBoundingBoxHeightScale((class_1297) (Object) this);
		
		if (widthScale != 1.0F || heightScale != 1.0F)
		{
			return original.method_19539(widthScale, heightScale);
		}
		
		return original;
	}
}
