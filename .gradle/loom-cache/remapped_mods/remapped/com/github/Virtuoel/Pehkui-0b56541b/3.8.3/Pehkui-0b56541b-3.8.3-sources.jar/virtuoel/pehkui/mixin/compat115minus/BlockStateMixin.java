package virtuoel.pehkui.mixin.compat115minus;

import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import virtuoel.pehkui.util.PehkuiBlockStateExtensions;

@Mixin(class_2680.class)
public abstract class BlockStateMixin implements PehkuiBlockStateExtensions
{
	@Dynamic @Shadow
	abstract class_265 method_17770(class_1922 world, class_2338 pos); // UNMAPPED_METHOD
	
	@Override
	public class_265 pehkui_getOutlineShape(class_1922 world, class_2338 pos)
	{
		return method_17770(world, pos);
	}
	
	@Dynamic @Shadow
	abstract class_2248 method_11614();
	
	@Override
	public class_2248 pehkui_getBlock()
	{
		return method_11614();
	}
}
