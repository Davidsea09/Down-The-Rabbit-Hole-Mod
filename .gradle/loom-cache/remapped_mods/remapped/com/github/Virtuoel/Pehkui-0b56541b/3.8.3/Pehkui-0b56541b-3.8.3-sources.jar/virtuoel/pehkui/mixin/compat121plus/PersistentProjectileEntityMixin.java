package virtuoel.pehkui.mixin.compat121plus;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1665;
import net.minecraft.class_1676;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1665.class)
public abstract class PersistentProjectileEntityMixin
{
	@Inject(at = @At("RETURN"), method = "<init>(Lnet/minecraft/entity/EntityType;Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/world/World;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)V")
	private void pehkui$construct(class_1299<? extends class_1676> type, class_1309 owner, class_1937 world, class_1799 stack, class_1799 shotFrom, CallbackInfo info)
	{
		final float scale = ScaleUtils.getEyeHeightScale(owner);
		
		if (scale != 1.0F)
		{
			final class_1297 self = ((class_1297) (Object) this);
			
			final class_243 pos = self.method_19538();
			
			self.method_5814(pos.field_1352, pos.field_1351 + ((1.0F - scale) * 0.1D), pos.field_1350);
		}
	}
}
