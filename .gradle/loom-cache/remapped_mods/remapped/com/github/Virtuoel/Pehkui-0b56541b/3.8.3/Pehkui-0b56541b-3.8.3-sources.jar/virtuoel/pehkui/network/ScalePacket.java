package virtuoel.pehkui.network;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1297;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import io.netty.buffer.ByteBuf;
import virtuoel.pehkui.api.ScaleData;
import virtuoel.pehkui.api.ScaleRegistries;
import virtuoel.pehkui.util.ScaleUtils;

public class ScalePacket
{
	public final int entityId;
	public final Collection<ScaleData> scales = new ArrayList<>();
	public final Map<class_2960, class_2487> syncedScales = new HashMap<>();
	
	public ScalePacket(final class_1297 entity, final Collection<ScaleData> scales)
	{
		entityId = entity.method_5628();
		this.scales.addAll(scales);
	}
	
	public ScalePacket(final class_2540 buf)
	{
		entityId = buf.method_10816();
		
		for (int i = buf.readInt(); i > 0; i--)
		{
			final class_2960 typeId = buf.method_10810();
			
			final class_2487 scaleData = ScaleUtils.buildScaleNbtFromPacketByteBuf(buf);
			
			syncedScales.put(typeId, scaleData);
		}
	}
	
	public void write(final class_2540 buf)
	{
		buf.method_10804(entityId);
		((ByteBuf) buf).writeInt(scales.size());
		
		for (final ScaleData s : scales)
		{
			buf.method_10812(ScaleRegistries.getId(ScaleRegistries.SCALE_TYPES, s.getScaleType()));
			s.toPacket(buf);
		}
	}
}
