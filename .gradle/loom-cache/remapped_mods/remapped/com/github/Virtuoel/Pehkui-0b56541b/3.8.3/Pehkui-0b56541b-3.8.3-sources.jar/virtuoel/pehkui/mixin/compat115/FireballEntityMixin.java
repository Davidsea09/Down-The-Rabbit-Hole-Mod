package virtuoel.pehkui.mixin.compat115;

import net.minecraft.class_1297;
import net.minecraft.class_1674;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1674.class)
public abstract class FireballEntityMixin
{
	@Dynamic
	@ModifyArg(method = MixinConstants.EXPLOSIVE_PROJECTILE_ON_COLLISION, at = @At(value = "INVOKE", target = MixinConstants.CREATE_EXPLOSION_OPTIONAL_FIRE))
	private float pehkui$onCollision$createExplosion(float power)
	{
		final float scale = ScaleUtils.getExplosionScale((class_1297) (Object) this);
		
		return scale != 1.0F ? power * scale : power;
	}
}
