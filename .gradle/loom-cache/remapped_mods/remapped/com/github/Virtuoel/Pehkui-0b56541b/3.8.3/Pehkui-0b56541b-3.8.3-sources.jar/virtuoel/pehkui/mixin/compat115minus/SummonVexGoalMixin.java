package virtuoel.pehkui.mixin.compat115minus;

import net.minecraft.class_1297;
import net.minecraft.class_1634;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(targets = "net.minecraft.entity.mob.EvokerEntity$SummonVexGoal")
public class SummonVexGoalMixin
{
	@Dynamic
	@ModifyArg(method = MixinConstants.CAST_SPELL, at = @At(value = "INVOKE", target = MixinConstants.SPAWN_ENTITY))
	private class_1297 pehkui$castSpell$spawnEntity(class_1297 entity)
	{
		if (entity instanceof class_1634)
		{
			ScaleUtils.loadScale(entity, ((class_1634) entity).method_7182());
		}
		
		return entity;
	}
}
