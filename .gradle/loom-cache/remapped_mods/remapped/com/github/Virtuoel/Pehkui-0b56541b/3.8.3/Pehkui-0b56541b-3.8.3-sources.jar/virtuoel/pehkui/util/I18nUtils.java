package virtuoel.pehkui.util;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Optional;
import net.minecraft.class_2561;
import net.minecraft.class_2588;

public class I18nUtils
{
	public static final Object[] EMPTY_VARARGS = new Object[0];
	
	private static final boolean RESOURCE_LOADER_LOADED = ModLoaderUtils.isModLoaded("fabric-resource-loader-v0");
	
	public static class_2561 translate(final String unlocalized, final String defaultLocalized)
	{
		return translate(unlocalized, defaultLocalized, EMPTY_VARARGS);
	}
	
	private static final Constructor<?> LITERAL = ReflectionUtils.getConstructor(Optional.ofNullable(ReflectionUtils.LITERAL_TEXT), String.class).orElse(null);
	private static final Constructor<class_2588> TRANSLATABLE = ReflectionUtils.getConstructor(Optional.of(class_2588.class), String.class, Object[].class).orElse(null);
	
	public static class_2561 translate(final String unlocalized, final String defaultLocalized, final Object... args)
	{
		if (RESOURCE_LOADER_LOADED)
		{
			if (VersionUtils.MINOR < 19)
			{
				try
				{
					return (class_2561) TRANSLATABLE.newInstance(unlocalized, args);
				}
				catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e)
				{
					
				}
			}
			
			return class_2561.method_43469(unlocalized, args);
		}
		
		return literal(defaultLocalized, args);
	}
	
	public static class_2561 literal(final String text, final Object... args)
	{
		if (VersionUtils.MINOR < 19)
		{
			try
			{
				return (class_2561) LITERAL.newInstance(String.format(text, args));
			}
			catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e)
			{
				
			}
		}
		
		return class_2561.method_43470(String.format(text, args));
	}
}
