package virtuoel.pehkui.mixin.reach.compat1204minus.compat119plus;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.class_1657;
import net.minecraft.class_7264;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_7264.class)
public abstract class ChestBoatEntityMixin
{
	@ModifyReturnValue(method = "canPlayerUse", at = @At("RETURN"))
	private boolean pehkui$canPlayerUse(boolean original, class_1657 playerEntity)
	{
		if (!original)
		{
			final float scale = ScaleUtils.getEntityReachScale(playerEntity);
			
			final class_7264 self = (class_7264) (Object) this;
			
			if (scale > 1.0F && !self.method_31481() && self.method_19538().method_24802(playerEntity.method_19538(), 8.0 * scale))
			{
				return true;
			}
		}
		
		return original;
	}
}
