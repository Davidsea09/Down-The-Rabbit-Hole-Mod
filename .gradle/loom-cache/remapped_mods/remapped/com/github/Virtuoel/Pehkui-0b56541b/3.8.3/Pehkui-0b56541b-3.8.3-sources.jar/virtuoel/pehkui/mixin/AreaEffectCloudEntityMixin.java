package virtuoel.pehkui.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1295;
import net.minecraft.class_1297;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1295.class)
public class AreaEffectCloudEntityMixin
{
	@ModifyExpressionValue(method = "tick", at = @At(value = "CONSTANT", args = "floatValue=0.5F"))
	private float pehkui$tick$minRadius(float value)
	{
		final float scale = ScaleUtils.getBoundingBoxWidthScale((class_1297) (Object) this);
		
		return scale != 1.0F ? scale * value : value;
	}
	
	@ModifyExpressionValue(method = "getDimensions", at = @At(value = "CONSTANT", args = "floatValue=0.5F"))
	private float pehkui$getDimensions$height(float value)
	{
		final float scale = ScaleUtils.getBoundingBoxHeightScale((class_1297) (Object) this);
		
		return scale != 1.0F ? scale * value : value;
	}
}
