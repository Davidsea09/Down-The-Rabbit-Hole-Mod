package virtuoel.pehkui.mixin.client.compat1206minus.compat1205plus;

import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1297;
import net.minecraft.class_897;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_897.class)
public abstract class EntityRendererMixin<T extends class_1297>
{
	@Dynamic
	@ModifyExpressionValue(method = MixinConstants.RENDER_LABEL_IF_PRESENT_WITH_DELTA, at = @At(value = "CONSTANT", args = "doubleValue=0.5D"))
	private double pehkui$renderLabelIfPresent$offset(double value, @Local(argsOnly = true) T entity)
	{
		final float scale = ScaleUtils.getBoundingBoxHeightScale(entity);
		
		return scale != 1.0F ? value + (entity.method_17682() * ((1.0F / scale) - 1.0F)) : value;
	}
}
