package virtuoel.pehkui.network;

import java.util.Collection;
import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import virtuoel.pehkui.Pehkui;
import virtuoel.pehkui.util.ConfigSyncUtils.SyncableConfigEntry;

public class ConfigSyncPayload extends ConfigSyncPacket implements class_8710
{
	public static final class_8710.class_9154<ConfigSyncPayload> ID = new class_8710.class_9154<>(Pehkui.CONFIG_SYNC_PACKET);
	public static final class_9139<class_2540, ConfigSyncPayload> CODEC = codec(ID);
	
	public ConfigSyncPayload(final Collection<SyncableConfigEntry<?>> configEntries)
	{
		super(configEntries);
	}
	
	public ConfigSyncPayload(final class_2540 buf)
	{
		super(buf);
	}
	
	@Override
	public class_8710.class_9154<? extends class_8710> method_56479()
	{
		return ID;
	}
	
	private static class_9139<class_2540, ConfigSyncPayload> codec(final class_8710.class_9154<ConfigSyncPayload> id)
	{
		return class_8710.method_56484(ConfigSyncPayload::write, ConfigSyncPayload::new);
	}
}
