package virtuoel.pehkui.mixin.reach;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1657.class)
public abstract class PlayerEntityMixin
{
	@ModifyExpressionValue(method = "attack", at = @At(value = "CONSTANT", args = "doubleValue=9.0F"))
	private double pehkui$attack$distance(double value)
	{
		final float scale = ScaleUtils.getEntityReachScale((class_1297) (Object) this);
		
		return scale > 1.0F ? scale * scale * value : value;
	}
}
