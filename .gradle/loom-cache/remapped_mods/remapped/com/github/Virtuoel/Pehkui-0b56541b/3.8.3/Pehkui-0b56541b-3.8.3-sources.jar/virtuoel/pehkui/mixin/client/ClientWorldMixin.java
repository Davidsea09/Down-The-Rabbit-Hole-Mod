package virtuoel.pehkui.mixin.client;

import net.minecraft.class_128;
import net.minecraft.class_129;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import virtuoel.pehkui.util.ScaleRenderUtils;

@Mixin(class_638.class)
public class ClientWorldMixin
{
	@Inject(method = "addDetailsToCrashReport", at = @At(value = "RETURN"))
	private void pehkui$addDetailsToCrashReport(class_128 report, CallbackInfoReturnable<class_129> info)
	{
		ScaleRenderUtils.addDetailsToCrashReport(info.getReturnValue());
	}
}
