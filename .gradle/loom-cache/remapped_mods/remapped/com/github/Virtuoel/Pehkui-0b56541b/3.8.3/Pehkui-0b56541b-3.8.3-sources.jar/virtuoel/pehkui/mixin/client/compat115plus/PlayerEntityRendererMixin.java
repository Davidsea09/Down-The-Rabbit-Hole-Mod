package virtuoel.pehkui.mixin.client.compat115plus;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.class_1007;
import net.minecraft.class_243;
import net.minecraft.class_742;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1007.class)
public abstract class PlayerEntityRendererMixin
{
	@ModifyReturnValue(method = "getPositionOffset", at = @At("RETURN"))
	private class_243 pehkui$getPositionOffset(class_243 original, class_742 entity, float tickDelta)
	{
		if (original != class_243.field_1353)
		{
			return original.method_1021(ScaleUtils.getModelHeightScale(entity, tickDelta));
		}
		
		return original;
	}
}
