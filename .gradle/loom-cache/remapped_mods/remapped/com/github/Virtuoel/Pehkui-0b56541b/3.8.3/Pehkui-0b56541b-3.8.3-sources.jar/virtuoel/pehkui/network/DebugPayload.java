package virtuoel.pehkui.network;

import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import virtuoel.pehkui.Pehkui;
import virtuoel.pehkui.server.command.DebugCommand;

public class DebugPayload extends DebugPacket implements class_8710
{
	public static final class_8710.class_9154<DebugPayload> ID = new class_8710.class_9154<>(Pehkui.DEBUG_PACKET);
	public static final class_9139<class_2540, DebugPayload> CODEC = codec(ID);
	
	public DebugPayload(final DebugCommand.PacketType type)
	{
		super(type);
	}
	
	public DebugPayload(final class_2540 buf)
	{
		super(buf);
	}
	
	@Override
	public class_8710.class_9154<? extends class_8710> method_56479()
	{
		return ID;
	}
	
	private static class_9139<class_2540, DebugPayload> codec(final class_8710.class_9154<DebugPayload> id)
	{
		return class_8710.method_56484(DebugPayload::write, DebugPayload::new);
	}
}
