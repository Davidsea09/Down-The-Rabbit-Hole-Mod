package virtuoel.pehkui.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1297;
import net.minecraft.class_1501;
import net.minecraft.class_1673;
import net.minecraft.class_1937;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1673.class)
public class LlamaSpitEntityMixin
{
	@Inject(at = @At("RETURN"), method = "<init>(Lnet/minecraft/world/World;Lnet/minecraft/entity/passive/LlamaEntity;)V")
	private void pehkui$construct(class_1937 world, class_1501 owner, CallbackInfo info)
	{
		ScaleUtils.setScaleOfProjectile((class_1297) (Object) this, owner);
	}
	
	@ModifyExpressionValue(method = "<init>(Lnet/minecraft/world/World;Lnet/minecraft/entity/passive/LlamaEntity;)V", at = @At(value = "CONSTANT", args = "doubleValue=0.10000000149011612D"))
	private double pehkui$construct$eyeOffset(double value, class_1937 world, class_1501 owner)
	{
		final float scale = ScaleUtils.getEyeHeightScale(owner);
		
		return scale != 1.0F ? value * scale : value;
	}
	
	@ModifyExpressionValue(method = "<init>(Lnet/minecraft/world/World;Lnet/minecraft/entity/passive/LlamaEntity;)V", at = @At(value = "CONSTANT", args = "floatValue=1.0F"))
	private float pehkui$construct$widthOffset(float value, class_1937 world, class_1501 owner)
	{
		final float scale = ScaleUtils.getBoundingBoxWidthScale(owner);
		
		return scale != 1.0F ? value * scale : value;
	}
}
