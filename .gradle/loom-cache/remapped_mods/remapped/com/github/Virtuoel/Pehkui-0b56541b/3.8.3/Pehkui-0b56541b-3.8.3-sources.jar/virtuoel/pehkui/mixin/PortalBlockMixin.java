package virtuoel.pehkui.mixin;

import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2423;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import virtuoel.pehkui.api.PehkuiConfig;
import virtuoel.pehkui.util.PehkuiBlockStateExtensions;

@Mixin(class_2423.class)
public abstract class PortalBlockMixin
{
	@Inject(at = @At("HEAD"), method = "onEntityCollision", cancellable = true)
	private void pehkui$onEntityCollision(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity, CallbackInfo info)
	{
		if (PehkuiConfig.COMMON.accurateNetherPortals.get())
		{
			if (!entity.method_5829().method_994(((PehkuiBlockStateExtensions) state).pehkui_getOutlineShape(world, pos).method_1107().method_996(pos)))
			{
				info.cancel();
			}
		}
	}
}
