package virtuoel.pehkui.mixin.step_height.compat1205plus;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin
{
	@ModifyReturnValue(method = "getStepHeight()F", at = @At("RETURN"))
	private float pehkui$getStepHeight(float original)
	{
		final float scale = ScaleUtils.getStepHeightScale((class_1297) (Object) this);
		
		return scale != 1.0F ? original * scale : original;
	}
}
