package virtuoel.pehkui.mixin.client.compat1205plus;

import net.minecraft.class_1606;
import net.minecraft.class_2350;
import net.minecraft.class_4587;
import net.minecraft.class_943;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_943.class)
public class ShulkerEntityRendererMixin
{
	@Inject(at = @At("RETURN"), method = "setupTransforms")
	private void pehkui$setupTransforms(class_1606 entity, class_4587 matrices, float animationProgress, float bodyYaw, float tickDelta, float scale, CallbackInfo info)
	{
		final class_2350 face = entity.method_7119();
		if (face != class_2350.field_11033)
		{
			final float h = ScaleUtils.getModelHeightScale(entity, tickDelta);
			if (face != class_2350.field_11036)
			{
				final float w = ScaleUtils.getModelWidthScale(entity, tickDelta);
				if (w != 1.0F || h != 1.0F)
				{
					matrices.method_22904(0.0, -((1.0F - w) * 0.5F) / w, -((1.0F - h) * 0.5F) / h);
				}
			}
			else if (h != 1.0F)
			{
				matrices.method_22904(0.0, -(1.0F - h) / h, 0.0);
			}
		}
	}
}
