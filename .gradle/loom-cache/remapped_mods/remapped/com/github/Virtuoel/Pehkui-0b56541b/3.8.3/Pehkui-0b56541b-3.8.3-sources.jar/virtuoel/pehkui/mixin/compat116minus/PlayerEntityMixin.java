package virtuoel.pehkui.mixin.compat116minus;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1657.class)
public abstract class PlayerEntityMixin
{
	@ModifyExpressionValue(method = "attack(Lnet/minecraft/entity/Entity;)V", at = @At(value = "CONSTANT", args = "floatValue=0.4F"))
	private float pehkui$attack$knockback(float value)
	{
		final float scale = ScaleUtils.getKnockbackScale((class_1297) (Object) this);
		
		return scale != 1.0F ? scale * value : value;
	}
}
