package virtuoel.pehkui.mixin.compat116plus;

import net.minecraft.class_1297;
import net.minecraft.class_2338;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

@Mixin(class_1297.class)
public abstract class EntityMixin
{
	@Shadow
	private class_2338 blockPos;
	
	@Unique
	protected void setPosDirectly(final class_2338 pos)
	{
		blockPos = pos;
	}
}
