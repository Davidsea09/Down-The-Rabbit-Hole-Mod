package virtuoel.pehkui.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;

import io.netty.buffer.Unpooled;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2509;
import net.minecraft.class_2540;
import net.minecraft.class_2596;
import net.minecraft.class_2960;
import net.minecraft.class_3244;
import net.minecraft.class_3532;
import net.minecraft.class_8710;
import virtuoel.pehkui.Pehkui;
import virtuoel.pehkui.api.PehkuiConfig;
import virtuoel.pehkui.api.ScaleData;
import virtuoel.pehkui.api.ScaleModifier;
import virtuoel.pehkui.api.ScaleRegistries;
import virtuoel.pehkui.api.ScaleType;
import virtuoel.pehkui.api.ScaleTypes;
import virtuoel.pehkui.network.ScalePacket;
import virtuoel.pehkui.network.ScalePayload;

public class ScaleUtils
{
	public static void tickScale(ScaleData data)
	{
		final ScaleType type = data.getScaleType();
		
		type.getPreTickEvent().invoker().onEvent(data);
		data.tick();
		type.getPostTickEvent().invoker().onEvent(data);
	}
	
	public static void loadAverageScales(class_1297 target, class_1297 source, class_1297... sources)
	{
		ScaleData scaleData;
		for (ScaleType type : ScaleRegistries.SCALE_TYPES.values())
		{
			scaleData = type.getScaleData(target);
			
			ScaleData[] scales = new ScaleData[sources.length];
			
			for (int i = 0; i < sources.length; i++)
			{
				scales[i] = type.getScaleData(sources[i]);
			}
			
			scaleData.averagedFromScales(type.getScaleData(source), scales);
		}
	}
	
	public static void loadScaleOnRespawn(class_1297 target, class_1297 source, boolean alive)
	{
		if (alive || PehkuiConfig.COMMON.keepAllScalesOnRespawn.get())
		{
			loadScale(target, source);
			return;
		}
		
		final List<? extends String> keptScales = PehkuiConfig.COMMON.scalesKeptOnRespawn.get();
		
		ScaleType type;
		ScaleData sourceData;
		ScaleData targetData;
		SortedSet<ScaleModifier> targetModifiers;
		for (final Map.Entry<class_2960, ScaleType> entry : ScaleRegistries.SCALE_TYPES.entrySet())
		{
			type = entry.getValue();
			sourceData = type.getScaleData(source);
			
			if (sourceData.shouldPersist() || keptScales.contains(entry.getKey().toString()))
			{
				targetData = type.getScaleData(target);
				targetData.fromScale(sourceData);
				
				targetModifiers = targetData.getBaseValueModifiers();
				targetModifiers.clear();
				targetModifiers.addAll(sourceData.getBaseValueModifiers());
			}
		}
	}
	
	public static void loadScale(class_1297 target, class_1297 source)
	{
		for (ScaleType type : ScaleRegistries.SCALE_TYPES.values())
		{
			type.getScaleData(target).fromScale(type.getScaleData(source));
		}
	}
	
	public static final double DEFAULT_MAXIMUM_REACH_BELOW_1_17 = 32.0D * 16.0D / 4.0D;
	
	public static final float DEFAULT_MINIMUM_POSITIVE_SCALE = 0x1P-96F;
	public static final float DEFAULT_MAXIMUM_POSITIVE_SCALE = 0x1P32F;
	
	public static float modifyLimbDistance(float value, class_1297 entity)
	{
		final float scale = getMotionScale(entity);
		
		return divideClamped(value, scale);
	}
	
	public static float divideClamped(float dividend, float divisor)
	{
		return divideClamped(dividend, divisor, DEFAULT_MINIMUM_POSITIVE_SCALE, DEFAULT_MAXIMUM_POSITIVE_SCALE);
	}
	
	public static float divideClamped(float dividend, float divisor, float minLimit, float maxLimit)
	{
		if (divisor == 1.0F)
		{
			return dividend;
		}
		
		final float ret = dividend / divisor;
		
		if (ret == Float.POSITIVE_INFINITY)
		{
			return maxLimit;
		}
		else if (ret == Float.NEGATIVE_INFINITY)
		{
			return -maxLimit;
		}
		else if (ret > minLimit || ret < -minLimit)
		{
			return ret;
		}
		
		return ret < 0 ? -minLimit : minLimit;
	}
	
	public static float setScaleOfDrop(class_1297 entity, class_1297 source)
	{
		return setScaleOnSpawn(entity, getDropScale(source));
	}
	
	public static float setScaleOfProjectile(class_1297 entity, class_1297 source)
	{
		return setScaleOnSpawn(entity, getProjectileScale(source));
	}
	
	public static float setScaleOnSpawn(class_1297 entity, float scale)
	{
		if (scale != 1.0F)
		{
			ScaleTypes.BASE.getScaleData(entity).setScale(scale);
		}
		
		return scale;
	}
	
	public static class_2487 buildScaleNbtFromPacketByteBuf(class_2540 buffer)
	{
		final class_2487 scaleData = new class_2487();
		
		final float scale = buffer.readFloat();
		final float prevScale = buffer.readFloat();
		final float fromScale = buffer.readFloat();
		final float toScale = buffer.readFloat();
		final int scaleTicks = buffer.readInt();
		final int totalScaleTicks = buffer.readInt();
		
		scaleData.method_10548("scale", scale);
		scaleData.method_10548("previous", prevScale);
		scaleData.method_10548("initial", fromScale);
		scaleData.method_10548("target", toScale);
		scaleData.method_10569("ticks", scaleTicks);
		scaleData.method_10569("total_ticks", totalScaleTicks);
		
		final int baseModifierCount = buffer.readInt();
		
		if (baseModifierCount != 0)
		{
			final class_2499 modifiers = new class_2499();
			
			for (int i = 0; i < baseModifierCount; i++)
			{
				modifiers.add(class_2509.field_11560.method_10639(buffer.method_10800(32767)));
			}
			
			scaleData.method_10566("baseValueModifiers", modifiers);
		}
		
		final byte persistent = buffer.readByte();
		
		if (persistent != -1)
		{
			scaleData.method_10556("persistent", persistent == 1);
		}
		
		if (buffer.readBoolean())
		{
			scaleData.method_10566("easing", class_2509.field_11560.method_10639(buffer.method_10800(32767)));
		}
		
		return scaleData;
	}
	
	public static void syncScalesIfNeeded(class_1297 entity, Consumer<class_2596<?>> packetSender)
	{
		if (((PehkuiEntityExtensions) entity).pehkui_shouldSyncScales())
		{
			syncScales(entity, packetSender, ScaleData::shouldSync, true);
			((PehkuiEntityExtensions) entity).pehkui_setShouldSyncScales(false);
		}
	}
	
	public static void syncScalesOnTrackingStart(class_1297 entity, class_3244 handler)
	{
		syncScales(entity, p -> ReflectionUtils.sendPacket(handler, p), ScaleUtils::hasScaleDataChanged, false);
	}
	
	private static boolean hasScaleDataChanged(final ScaleData scaleData)
	{
		return !scaleData.hasDefaultValues();
	}
	
	private static final boolean NETWORKING_API_LOADED = ModLoaderUtils.isModLoaded("fabric-networking-api-v1");
	
	private static final ThreadLocal<Collection<ScaleData>> SYNCED_SCALE_DATA = ThreadLocal.withInitial(ArrayList::new);
	
	public static void syncScales(class_1297 entity, Consumer<class_2596<?>> packetSender, Predicate<ScaleData> condition, boolean unmark)
	{
		final Collection<ScaleData> syncedScales = SYNCED_SCALE_DATA.get();
		
		for (final ScaleData scaleData : ((PehkuiEntityExtensions) entity).pehkui_getScales().values())
		{
			if (scaleData != null && condition.test(scaleData))
			{
				syncedScales.add(scaleData);
				
				if (unmark)
				{
					scaleData.markForSync(false);
				}
			}
		}
		
		if (!syncedScales.isEmpty())
		{
			if (NETWORKING_API_LOADED)
			{
				if (VersionUtils.MINOR > 20 || (VersionUtils.MINOR == 20 && VersionUtils.PATCH >= 5))
				{
					packetSender.accept(ServerPlayNetworking.createS2CPacket((class_8710) (Object) new ScalePayload(entity, syncedScales)));
				}
				else
				{
					final class_2540 buffer = new class_2540(Unpooled.buffer());
					
					new ScalePacket(entity, syncedScales).write(buffer);
					
					packetSender.accept(ReflectionUtils.createS2CPacket(Pehkui.SCALE_PACKET, buffer));
				}
			}
			
			syncedScales.clear();
		}
	}
	
	public static class_243 getEyePos(final class_1297 entity)
	{
		return getEyePos(entity, class_2350.field_11033);
	}
	
	public static class_243 getEyePos(final class_1657 entity)
	{
		return getEyePos(entity, GravityChangerCompatibility.INSTANCE.getGravityDirection(entity));
	}
	
	public static class_243 getEyePos(final class_1297 entity, final class_2350 gravity)
	{
		final double offsetX = entity.method_5751() * -gravity.method_10148();
		final double offsetY = entity.method_5751() * -gravity.method_10164();
		final double offsetZ = entity.method_5751() * -gravity.method_10165();
		final double footXCoord = entity.method_19538().method_10216();
		final double footYCoord = entity.method_19538().method_10214();
		final double footZCoord = entity.method_19538().method_10215();
		final double headXCoord = footXCoord + offsetX;
		final double headYCoord = footYCoord + offsetY;
		final double headZCoord = footZCoord + offsetZ;
		
		return new class_243(headXCoord, headYCoord, headZCoord);
	}
	
	public static double getBlockXOffset(class_2338 pos, class_1657 player)
	{
		final int blockCoord = pos.method_10263();
		final class_2350 gravity = GravityChangerCompatibility.INSTANCE.getGravityDirection(player);
		final double offset = player.method_5751() * -gravity.method_10148();
		final double footCoord = player.method_19538().method_10216();
		final double headCoord = footCoord + offset;
		final int headCoordFloored = class_3532.method_15357(headCoord);
		
		if (headCoordFloored == blockCoord)
		{
			return footCoord - (double) headCoordFloored;
		}
		else if (headCoordFloored > blockCoord)
		{
			return 1.0F - offset;
		}
		
		return -offset;
	}
	
	public static double getBlockYOffset(class_2338 pos, class_1657 player)
	{
		final int blockCoord = pos.method_10264();
		final class_2350 gravity = GravityChangerCompatibility.INSTANCE.getGravityDirection(player);
		final double offset = player.method_5751() * -gravity.method_10164();
		final double footCoord = player.method_19538().method_10214();
		final double headCoord = footCoord + offset;
		final int headCoordFloored = class_3532.method_15357(headCoord);
		
		if (headCoordFloored == blockCoord)
		{
			return footCoord - (double) headCoordFloored;
		}
		else if (headCoordFloored > blockCoord)
		{
			return 1.0F - offset;
		}
		
		return -offset;
	}
	
	public static double getBlockZOffset(class_2338 pos, class_1657 player)
	{
		final int blockCoord = pos.method_10260();
		final class_2350 gravity = GravityChangerCompatibility.INSTANCE.getGravityDirection(player);
		final double offset = player.method_5751() * -gravity.method_10165();
		final double footCoord = player.method_19538().method_10215();
		final double headCoord = footCoord + offset;
		final int headCoordFloored = class_3532.method_15357(headCoord);
		
		if (headCoordFloored == blockCoord)
		{
			return footCoord - (double) headCoordFloored;
		}
		else if (headCoordFloored > blockCoord)
		{
			return 1.0F - offset;
		}
		
		return -offset;
	}
	
	public static float getEyeHeightScale(class_1297 entity)
	{
		return getEyeHeightScale(entity, 1.0F);
	}
	
	public static float getEyeHeightScale(class_1297 entity, float tickDelta)
	{
		return getTypedScale(entity, ScaleTypes.EYE_HEIGHT, tickDelta);
	}
	
	public static float getThirdPersonScale(class_1297 entity, float tickDelta)
	{
		return getTypedScale(entity, ScaleTypes.THIRD_PERSON, tickDelta);
	}
	
	public static float getModelWidthScale(class_1297 entity)
	{
		return getModelWidthScale(entity, 1.0F);
	}
	
	public static float getModelWidthScale(class_1297 entity, float tickDelta)
	{
		return getTypedScale(entity, ScaleTypes.MODEL_WIDTH, tickDelta);
	}
	
	public static float getModelHeightScale(class_1297 entity)
	{
		return getModelHeightScale(entity, 1.0F);
	}
	
	public static float getModelHeightScale(class_1297 entity, float tickDelta)
	{
		return getTypedScale(entity, ScaleTypes.MODEL_HEIGHT, tickDelta);
	}
	
	public static float getBoundingBoxWidthScale(class_1297 entity)
	{
		return getBoundingBoxWidthScale(entity, 1.0F);
	}
	
	public static float getBoundingBoxWidthScale(class_1297 entity, float tickDelta)
	{
		return getTypedScale(entity, ScaleTypes.HITBOX_WIDTH, tickDelta);
	}
	
	public static float getBoundingBoxHeightScale(class_1297 entity)
	{
		return getBoundingBoxHeightScale(entity, 1.0F);
	}
	
	public static float getBoundingBoxHeightScale(class_1297 entity, float tickDelta)
	{
		return getTypedScale(entity, ScaleTypes.HITBOX_HEIGHT, tickDelta);
	}
	
	public static float getInteractionBoxWidthScale(class_1297 entity)
	{
		return getInteractionBoxWidthScale(entity, 1.0F);
	}
	
	public static float getInteractionBoxWidthScale(class_1297 entity, float tickDelta)
	{
		return getTypedScale(entity, ScaleTypes.INTERACTION_BOX_WIDTH, tickDelta);
	}
	
	public static float getInteractionBoxHeightScale(class_1297 entity)
	{
		return getInteractionBoxHeightScale(entity, 1.0F);
	}
	
	public static float getInteractionBoxHeightScale(class_1297 entity, float tickDelta)
	{
		return getTypedScale(entity, ScaleTypes.INTERACTION_BOX_HEIGHT, tickDelta);
	}
	
	public static float getFallingScale(class_1297 entity)
	{
		return getFallingScale(entity, 1.0F);
	}
	
	public static float getFallingScale(class_1297 entity, float tickDelta)
	{
		return getTypedScale(entity, ScaleTypes.FALLING, tickDelta);
	}
	
	public static float getStepHeightScale(class_1297 entity)
	{
		return getStepHeightScale(entity, 1.0F);
	}
	
	public static float getStepHeightScale(class_1297 entity, float tickDelta)
	{
		return getTypedScale(entity, ScaleTypes.STEP_HEIGHT, tickDelta);
	}
	
	public static float getViewBobbingScale(class_1297 entity)
	{
		return getViewBobbingScale(entity, 1.0F);
	}
	
	public static float getViewBobbingScale(class_1297 entity, float tickDelta)
	{
		return getTypedScale(entity, ScaleTypes.VIEW_BOBBING, tickDelta);
	}
	
	public static float getVisibilityScale(class_1297 entity)
	{
		return getVisibilityScale(entity, 1.0F);
	}
	
	public static float getVisibilityScale(class_1297 entity, float tickDelta)
	{
		return getTypedScale(entity, ScaleTypes.VISIBILITY, tickDelta);
	}
	
	public static float getJumpHeightScale(class_1297 entity)
	{
		return getJumpHeightScale(entity, 1.0F);
	}
	
	public static float getJumpHeightScale(class_1297 entity, float tickDelta)
	{
		return getTypedScale(entity, ScaleTypes.JUMP_HEIGHT, tickDelta);
	}
	
	public static float getMotionScale(class_1297 entity)
	{
		return getMotionScale(entity, 1.0F);
	}
	
	public static float getMotionScale(class_1297 entity, float tickDelta)
	{
		return getConfigurableTypedScale(entity, ScaleTypes.MOTION, PehkuiConfig.COMMON.scaledMotion::get, tickDelta);
	}
	
	public static float getFlightScale(class_1297 entity)
	{
		return getFlightScale(entity, 1.0F);
	}
	
	public static float getFlightScale(class_1297 entity, float tickDelta)
	{
		return getTypedScale(entity, ScaleTypes.FLIGHT, tickDelta);
	}
	
	public static float getBlockReachScale(class_1297 entity)
	{
		return getBlockReachScale(entity, 1.0F);
	}
	
	public static float getBlockReachScale(class_1297 entity, float tickDelta)
	{
		return getConfigurableTypedScale(entity, ScaleTypes.BLOCK_REACH, PehkuiConfig.COMMON.scaledReach::get, tickDelta);
	}
	
	public static float getEntityReachScale(class_1297 entity)
	{
		return getEntityReachScale(entity, 1.0F);
	}
	
	public static float getEntityReachScale(class_1297 entity, float tickDelta)
	{
		return getConfigurableTypedScale(entity, ScaleTypes.ENTITY_REACH, PehkuiConfig.COMMON.scaledReach::get, tickDelta);
	}
	
	public static float getMiningSpeedScale(class_1297 entity)
	{
		return getMiningSpeedScale(entity, 1.0F);
	}
	
	public static float getMiningSpeedScale(class_1297 entity, float tickDelta)
	{
		return getTypedScale(entity, ScaleTypes.MINING_SPEED, tickDelta);
	}
	
	public static float getAttackSpeedScale(class_1297 entity)
	{
		return getAttackSpeedScale(entity, 1.0F);
	}
	
	public static float getAttackSpeedScale(class_1297 entity, float tickDelta)
	{
		return getTypedScale(entity, ScaleTypes.ATTACK_SPEED, tickDelta);
	}
	
	public static float getKnockbackScale(class_1297 entity)
	{
		return getKnockbackScale(entity, 1.0F);
	}
	
	public static float getKnockbackScale(class_1297 entity, float tickDelta)
	{
		return getTypedScale(entity, ScaleTypes.KNOCKBACK, tickDelta);
	}
	
	public static float getAttackScale(class_1297 entity)
	{
		return getAttackScale(entity, 1.0F);
	}
	
	public static float getAttackScale(class_1297 entity, float tickDelta)
	{
		return getConfigurableTypedScale(entity, ScaleTypes.ATTACK, PehkuiConfig.COMMON.scaledAttack::get, tickDelta);
	}
	
	public static float getDefenseScale(class_1297 entity)
	{
		return getDefenseScale(entity, 1.0F);
	}
	
	public static float getDefenseScale(class_1297 entity, float tickDelta)
	{
		return getConfigurableTypedScale(entity, ScaleTypes.DEFENSE, PehkuiConfig.COMMON.scaledDefense::get, tickDelta);
	}
	
	public static float getHealthScale(class_1297 entity)
	{
		return getHealthScale(entity, 1.0F);
	}
	
	public static float getHealthScale(class_1297 entity, float tickDelta)
	{
		return getConfigurableTypedScale(entity, ScaleTypes.HEALTH, PehkuiConfig.COMMON.scaledHealth::get, tickDelta);
	}
	
	public static float getDropScale(class_1297 entity)
	{
		return getDropScale(entity, 1.0F);
	}
	
	public static float getDropScale(class_1297 entity, float tickDelta)
	{
		return getConfigurableTypedScale(entity, ScaleTypes.DROPS, PehkuiConfig.COMMON.scaledItemDrops::get, tickDelta);
	}
	
	public static float getHeldItemScale(class_1297 entity)
	{
		return getHeldItemScale(entity, 1.0F);
	}
	
	public static float getHeldItemScale(class_1297 entity, float tickDelta)
	{
		return getConfigurableTypedScale(entity, ScaleTypes.HELD_ITEM, Boolean.TRUE::booleanValue, tickDelta);
	}
	
	public static float getProjectileScale(class_1297 entity)
	{
		return getProjectileScale(entity, 1.0F);
	}
	
	public static float getProjectileScale(class_1297 entity, float tickDelta)
	{
		return getConfigurableTypedScale(entity, ScaleTypes.PROJECTILES, PehkuiConfig.COMMON.scaledProjectiles::get, tickDelta);
	}
	
	public static float getExplosionScale(class_1297 entity)
	{
		return getExplosionScale(entity, 1.0F);
	}
	
	public static float getExplosionScale(class_1297 entity, float tickDelta)
	{
		return getConfigurableTypedScale(entity, ScaleTypes.EXPLOSIONS, PehkuiConfig.COMMON.scaledExplosions::get, tickDelta);
	}
	
	public static float getConfigurableTypedScale(class_1297 entity, ScaleType type, Supplier<Boolean> config, float tickDelta)
	{
		return config.get() ? getTypedScale(entity, type, tickDelta) : type.getDefaultBaseScale();
	}
	
	public static float getTypedScale(class_1297 entity, ScaleType type, float tickDelta)
	{
		return entity == null ? type.getDefaultBaseScale() : type.getScaleData(entity).getScale(tickDelta);
	}
}
