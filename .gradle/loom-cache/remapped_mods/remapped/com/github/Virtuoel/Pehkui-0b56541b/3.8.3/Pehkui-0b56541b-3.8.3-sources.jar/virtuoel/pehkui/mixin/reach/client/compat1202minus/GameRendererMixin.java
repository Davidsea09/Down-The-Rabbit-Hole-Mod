package virtuoel.pehkui.mixin.reach.client.compat1202minus;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_757;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(value = class_757.class, priority = 990)
public class GameRendererMixin
{
	@Shadow @Final @Mutable
	class_310 client;
	
	@ModifyExpressionValue(method = "updateCrosshairTarget", at = @At(value = "CONSTANT", args = "doubleValue=3.0D"))
	private double pehkui$updateCrosshairTarget$distance(double value, float tickDelta)
	{
		final class_1297 entity = client.method_1560();
		
		if (entity != null)
		{
			final float scale = ScaleUtils.getEntityReachScale(entity, tickDelta);
			
			if (scale != 1.0F)
			{
				return scale * value;
			}
		}
		
		return value;
	}
}
