package virtuoel.pehkui.mixin.compat116plus;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1308.class)
public class MobEntityMixin
{
	@Inject(at = @At("RETURN"), method = "convertTo")
	private <T extends class_1308> void pehkui$convertTo(class_1299<T> entityType, boolean bl, CallbackInfoReturnable<T> info)
	{
		final class_1308 e = info.getReturnValue();
		
		if (e != null)
		{
			ScaleUtils.loadScale(e, (class_1297) (Object) this);
		}
	}
}
