package virtuoel.pehkui.mixin.compat116plus;

import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1665;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1665.class)
public abstract class PersistentProjectileEntityMixin
{
	@ModifyArg(method = "getEntityCollision", index = 4, at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/projectile/ProjectileUtil;getEntityCollision(Lnet/minecraft/world/World;Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Box;Ljava/util/function/Predicate;)Lnet/minecraft/util/hit/EntityHitResult;"))
	private class_238 pehkui$getEntityCollision$expand(class_1937 world, class_1297 entity, class_243 vec3d, class_243 vec3d2, class_238 box, Predicate<class_1297> predicate)
	{
		final float width = ScaleUtils.getBoundingBoxWidthScale(entity);
		final float height = ScaleUtils.getBoundingBoxHeightScale(entity);
		
		if (width != 1.0F || height != 1.0F)
		{
			return box.method_1009(width - 1.0D, height - 1.0D, width - 1.0D);
		}
		
		return box;
	}
	
	@ModifyVariable(method = "onEntityHit", at = @At(value = "STORE"))
	private float pehkui$onEntityHit(float value)
	{
		final float scale = ScaleUtils.getMotionScale((class_1297) (Object) this);
		
		return scale != 1.0F ? ScaleUtils.divideClamped(value, scale) : value;
	}
}
