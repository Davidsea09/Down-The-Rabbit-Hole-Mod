package virtuoel.pehkui.mixin.compat1205plus;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_4048;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin
{
	@ModifyArg(method = "getPassengerRidingPos", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;getPassengerAttachmentPos(Lnet/minecraft/entity/Entity;Lnet/minecraft/entity/EntityDimensions;F)Lnet/minecraft/util/math/Vec3d;"))
	private float pehkui$getPassengerRidingPos$getPassengerAttachmentPos(float value)
	{
		final float scale = ScaleUtils.getBoundingBoxHeightScale((class_1297) (Object) this);
		return scale == 1.0F ? value : value * scale;
	}
	
	@ModifyReturnValue(method = "getDimensions", at = @At("RETURN"))
	private class_4048 pehkui$getDimensions(class_4048 original)
	{
		final float widthScale = ScaleUtils.getBoundingBoxWidthScale((class_1297) (Object) this);
		final float heightScale = ScaleUtils.getBoundingBoxHeightScale((class_1297) (Object) this);
		
		if (widthScale != 1.0F || heightScale != 1.0F)
		{
			return original.method_19539(widthScale, heightScale);
		}
		
		return original;
	}
}
