package virtuoel.pehkui.mixin.compat1204minus;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_2885;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_3244.class)
public class ServerPlayNetworkHandlerMixin
{
	@Shadow class_3222 player;
	
	@ModifyExpressionValue(method = "onPlayerInteractBlock", at = @At(value = "CONSTANT", args = "doubleValue=0.5D", ordinal = 0))
	private double pehkui$onPlayerInteractBlock$xOffset(double value, class_2885 packet)
	{
		return ScaleUtils.getBlockXOffset(packet.method_12543().method_17777(), player);
	}
	
	@ModifyExpressionValue(method = "onPlayerInteractBlock", at = @At(value = "CONSTANT", args = "doubleValue=0.5D", ordinal = 1))
	private double pehkui$onPlayerInteractBlock$yOffset(double value, class_2885 packet)
	{
		return ScaleUtils.getBlockYOffset(packet.method_12543().method_17777(), player);
	}
	
	@ModifyExpressionValue(method = "onPlayerInteractBlock", at = @At(value = "CONSTANT", args = "doubleValue=0.5D", ordinal = 2))
	private double pehkui$onPlayerInteractBlock$zOffset(double value, class_2885 packet)
	{
		return ScaleUtils.getBlockZOffset(packet.method_12543().method_17777(), player);
	}
}
