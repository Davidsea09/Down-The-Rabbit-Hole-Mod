package virtuoel.pehkui.mixin.reach.compat1193minus;

import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1657;
import net.minecraft.class_2589;
import net.minecraft.class_2609;
import net.minecraft.class_2621;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin({
	class_2609.class,
	class_2589.class,
	class_2621.class,
})
public abstract class BlockEntityUseDistanceMixin
{
	@Dynamic
	@ModifyExpressionValue(method = MixinConstants.CAN_PLAYER_USE, at = @At(value = "CONSTANT", args = "doubleValue=64.0D"))
	private double pehkui$canPlayerUse$distance(double value, class_1657 player)
	{
		final float scale = ScaleUtils.getBlockReachScale(player);
		return scale != 1.0F ? scale * scale * value : value;
	}
}
