package virtuoel.pehkui.mixin.compat1205plus;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_1297;
import net.minecraft.class_1686;
import net.minecraft.class_238;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1686.class)
public class PotionEntityMixin
{
	@WrapOperation(method = "applySplashPotion", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/math/Box;expand(DDD)Lnet/minecraft/util/math/Box;"))
	private class_238 pehkui$applySplashPotion$expand(class_238 obj, double x, double y, double z, Operation<class_238> original)
	{
		final float widthScale = ScaleUtils.getBoundingBoxWidthScale((class_1297) (Object) this);
		final float heightScale = ScaleUtils.getBoundingBoxHeightScale((class_1297) (Object) this);
		
		if (widthScale != 1.0F)
		{
			x *= widthScale;
			z *= widthScale;
		}
		
		if (heightScale != 1.0F)
		{
			y *= heightScale;
		}
		
		return original.call(obj, x, y, z);
	}
	
	@ModifyExpressionValue(method = "applySplashPotion", at = @At(value = "CONSTANT", args = "doubleValue=16.0D"))
	private double pehkui$applySplashPotion$maxSquaredDist(double value)
	{
		final float scale = ScaleUtils.getBoundingBoxWidthScale((class_1297) (Object) this);
		
		return scale != 1.0F ? scale * scale * value : value;
	}
	
	@ModifyExpressionValue(method = "applySplashPotion", at = @At(value = "CONSTANT", args = "doubleValue=4.0F", ordinal = 2))
	private double pehkui$applySplashPotion$maxDist(double value)
	{
		final float scale = ScaleUtils.getBoundingBoxWidthScale((class_1297) (Object) this);
		
		return scale != 1.0F ? scale * value : value;
	}
	
	@ModifyArg(method = "applyLingeringPotion", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/AreaEffectCloudEntity;setRadius(F)V"))
	private float pehkui$applyLingeringPotion$setRadius(float value)
	{
		return value * ScaleUtils.getBoundingBoxWidthScale((class_1297) (Object) this);
	}
	
	@ModifyArg(method = "applyLingeringPotion", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/AreaEffectCloudEntity;setRadiusOnUse(F)V"))
	private float pehkui$applyLingeringPotion$setRadiusOnUse(float value)
	{
		return value * ScaleUtils.getBoundingBoxWidthScale((class_1297) (Object) this);
	}
	
	@ModifyArg(method = "applyLingeringPotion", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/World;spawnEntity(Lnet/minecraft/entity/Entity;)Z"))
	private class_1297 pehkui$applyLingeringPotion$entity(class_1297 entity)
	{
		ScaleUtils.loadScale(entity, (class_1297) (Object) this);
		
		return entity;
	}
}
