package virtuoel.pehkui.mixin.compat116plus;

import net.minecraft.class_1297;
import net.minecraft.class_1634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(targets = "net.minecraft.entity.mob.EvokerEntity$SummonVexGoal")
public class SummonVexGoalMixin
{
	@ModifyArg(method = "castSpell()V", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/world/ServerWorld;spawnEntityAndPassengers(Lnet/minecraft/entity/Entity;)V"))
	private class_1297 pehkui$castSpell$spawnEntityAndPassengers(class_1297 entity)
	{
		if (entity instanceof class_1634)
		{
			ScaleUtils.loadScale(entity, ((class_1634) entity).method_7182());
		}
		
		return entity;
	}
}
