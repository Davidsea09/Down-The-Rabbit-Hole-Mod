package virtuoel.pehkui.mixin.client.compat1182plus;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1297;
import net.minecraft.class_746;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_746.class)
public class ClientPlayerEntityMixin
{
	@ModifyExpressionValue(method = "sendMovementPackets", at = @At(value = "CONSTANT", args = "doubleValue=2.0E-4D"))
	private double pehkui$sendMovementPackets$minVelocity(double value)
	{
		final float scale = ScaleUtils.getMotionScale((class_1297) (Object) this);
		
		return scale < 1.0F ? scale * value : value;
	}
}
