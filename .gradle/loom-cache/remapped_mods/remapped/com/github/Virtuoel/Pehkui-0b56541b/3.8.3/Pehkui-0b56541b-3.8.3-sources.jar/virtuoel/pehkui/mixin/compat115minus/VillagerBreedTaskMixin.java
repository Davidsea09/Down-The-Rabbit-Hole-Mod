package virtuoel.pehkui.mixin.compat115minus;

import java.util.Optional;
import net.minecraft.class_1646;
import net.minecraft.class_4111;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.llamalad7.mixinextras.sugar.Local;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_4111.class)
public class VillagerBreedTaskMixin
{
	@Dynamic
	@Inject(method = MixinConstants.CREATE_CHILD, at = @At(value = "INVOKE", shift = Shift.BEFORE, target = MixinConstants.SPAWN_ENTITY))
	private void pehkui$createChild(class_1646 villagerEntity, class_1646 villagerEntity2, CallbackInfoReturnable<Optional<class_1646>> info, @Local(ordinal = 2) class_1646 child)
	{
		ScaleUtils.loadAverageScales(child, villagerEntity, villagerEntity2);
	}
}
