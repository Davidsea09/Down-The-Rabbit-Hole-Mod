package virtuoel.pehkui.server.command;

import java.text.DecimalFormat;
import java.util.Random;
import java.util.SortedSet;
import java.util.stream.Collectors;

import org.jetbrains.annotations.Nullable;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;

import it.unimi.dsi.fastutil.floats.Float2FloatFunction;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1297;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2203;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3169;
import virtuoel.pehkui.api.PehkuiConfig;
import virtuoel.pehkui.api.ScaleData;
import virtuoel.pehkui.api.ScaleModifier;
import virtuoel.pehkui.api.ScaleRegistries;
import virtuoel.pehkui.api.ScaleType;
import virtuoel.pehkui.api.ScaleTypes;
import virtuoel.pehkui.command.argument.ScaleEasingArgumentType;
import virtuoel.pehkui.command.argument.ScaleModifierArgumentType;
import virtuoel.pehkui.command.argument.ScaleOperationArgumentType;
import virtuoel.pehkui.command.argument.ScaleTypeArgumentType;
import virtuoel.pehkui.mixin.DataCommandInvoker;
import virtuoel.pehkui.util.CommandUtils;
import virtuoel.pehkui.util.I18nUtils;
import virtuoel.pehkui.util.PehkuiEntityExtensions;

public class ScaleCommand
{
	public static void register(final CommandDispatcher<class_2168> commandDispatcher)
	{
		if (!FabricLoader.getInstance().isDevelopmentEnvironment() && !PehkuiConfig.COMMON.enableCommands.get())
		{
			return;
		}
		
		final LiteralArgumentBuilder<class_2168> builder =
			class_2170.method_9247("scale")
			.requires(source -> source.method_9259(2));
		
		registerOperation(builder);
		registerRandomize(builder);
		registerGet(builder);
		registerCompute(builder);
		registerReset(builder);
		registerModifier(builder);
		registerDelay(builder);
		registerEasing(builder);
		registerPersist(builder);
		registerNbt(builder);
		
		commandDispatcher.register(builder);
	}
	
	private static LiteralArgumentBuilder<class_2168> registerOperation(final LiteralArgumentBuilder<class_2168> builder)
	{
		builder
			.then(class_2170.method_9244("operation", ScaleOperationArgumentType.operation())
				.then(class_2170.method_9244("scale_type", ScaleTypeArgumentType.scaleType())
					.then(class_2170.method_9244("value", FloatArgumentType.floatArg())
						.then(class_2170.method_9244("targets", class_2186.method_9306())
							.executes(context ->
							{
								final float scale = FloatArgumentType.getFloat(context, "value");
								final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
								
								for (final class_1297 e : class_2186.method_9317(context, "targets"))
								{
									final ScaleData data = type.getScaleData(e);
									final ScaleOperationArgumentType.Operation operation = ScaleOperationArgumentType.getOperation(context, "operation");
									
									data.setTargetScale((float) operation.apply(data.getTargetScale(), scale));
								}
								
								return 1;
							})
						)
						.executes(context ->
						{
							final float scale = FloatArgumentType.getFloat(context, "value");
							final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
							
							final ScaleData data = type.getScaleData(context.getSource().method_9229());
							final ScaleOperationArgumentType.Operation operation = ScaleOperationArgumentType.getOperation(context, "operation");
							
							data.setTargetScale((float) operation.apply(data.getTargetScale(), scale));
							
							return 1;
						})
					)
				)
				.then(class_2170.method_9244("value", FloatArgumentType.floatArg())
					.then(class_2170.method_9244("targets", class_2186.method_9306())
						.executes(context ->
						{
							final float scale = FloatArgumentType.getFloat(context, "value");
							
							for (final class_1297 e : class_2186.method_9317(context, "targets"))
							{
								final ScaleData data = ScaleTypes.BASE.getScaleData(e);
								final ScaleOperationArgumentType.Operation operation = ScaleOperationArgumentType.getOperation(context, "operation");
								
								data.setTargetScale((float) operation.apply(data.getTargetScale(), scale));
							}
							
							return 1;
						})
					)
					.executes(context ->
					{
						final float scale = FloatArgumentType.getFloat(context, "value");
						
						final ScaleData data = ScaleTypes.BASE.getScaleData(context.getSource().method_9229());
						final ScaleOperationArgumentType.Operation operation = ScaleOperationArgumentType.getOperation(context, "operation");
						
						data.setTargetScale((float) operation.apply(data.getTargetScale(), scale));
						
						return 1;
					})
				)
			);
		
		return builder;
	}
	
	private static LiteralArgumentBuilder<class_2168> registerRandomize(final LiteralArgumentBuilder<class_2168> builder)
	{
		builder
			.then(class_2170.method_9247("randomize")
				.then(class_2170.method_9244("scale_type", ScaleTypeArgumentType.scaleType())
					.then(class_2170.method_9244("minOperation", ScaleOperationArgumentType.operation())
						.then(class_2170.method_9244("minValue", FloatArgumentType.floatArg())
							.then(class_2170.method_9244("maxOperation", ScaleOperationArgumentType.operation())
								.then(class_2170.method_9244("maxValue", FloatArgumentType.floatArg())
									.then(class_2170.method_9244("targets", class_2186.method_9306())
										.executes(context ->
										{
											final float minValue = FloatArgumentType.getFloat(context, "minValue");
											final float maxValue = FloatArgumentType.getFloat(context, "maxValue");
											
											final ScaleOperationArgumentType.Operation minOperation = ScaleOperationArgumentType.getOperation(context, "minOperation");
											final ScaleOperationArgumentType.Operation maxOperation = ScaleOperationArgumentType.getOperation(context, "maxOperation");
											
											final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
											
											double min, max, target;
											for (final class_1297 e : class_2186.method_9317(context, "targets"))
											{
												final ScaleData data = type.getScaleData(e);
												
												target = data.getTargetScale();
												min = minOperation.apply(target, minValue);
												max = maxOperation.apply(target, maxValue);
												
												if (max < min)
												{
													final double temp = min;
													min = max;
													max = temp;
												}
												
												data.setTargetScale((float) (min + (RANDOM.nextFloat() * (max - min))));
											}
											
											return 1;
										})
									)
									.executes(context ->
									{
										final float minValue = FloatArgumentType.getFloat(context, "minValue");
										final float maxValue = FloatArgumentType.getFloat(context, "maxValue");
										
										final ScaleOperationArgumentType.Operation minOperation = ScaleOperationArgumentType.getOperation(context, "minOperation");
										final ScaleOperationArgumentType.Operation maxOperation = ScaleOperationArgumentType.getOperation(context, "maxOperation");
										
										final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
										
										final ScaleData data = type.getScaleData(context.getSource().method_9229());
										
										final double target = data.getTargetScale();
										double min = minOperation.apply(target, minValue);
										double max = maxOperation.apply(target, maxValue);
										
										if (max < min)
										{
											final double temp = min;
											min = max;
											max = temp;
										}
										
										data.setTargetScale((float) (min + (RANDOM.nextFloat() * (max - min))));
										
										return 1;
									})
								)
							)
						)
					)
				)
			);
		
		return builder;
	}
	
	private static LiteralArgumentBuilder<class_2168> registerGet(final LiteralArgumentBuilder<class_2168> builder)
	{
		builder
			.then(class_2170.method_9247("get")
				.then(class_2170.method_9244("scale_type", ScaleTypeArgumentType.scaleType())
					.then(class_2170.method_9244("entity", class_2186.method_9309())
						.then(class_2170.method_9244("scalingFactor", FloatArgumentType.floatArg())
							.executes(context ->
							{
								final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
								final float scale = type.getScaleData(class_2186.method_9313(context, "entity")).getBaseScale();
								final int scaled = (int) (scale * FloatArgumentType.getFloat(context, "scalingFactor"));
								CommandUtils.sendFeedback(context.getSource(), () -> scaleText(scale, scaled), false);
								
								return scaled;
							})
						)
						.executes(context ->
						{
							final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
							final float scale = type.getScaleData(class_2186.method_9313(context, "entity")).getBaseScale();
							CommandUtils.sendFeedback(context.getSource(), () -> scaleText(scale), false);
							
							return (int) scale;
						})
					)
					.then(class_2170.method_9244("scalingFactor", FloatArgumentType.floatArg())
						.executes(context ->
						{
							final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
							final float scale = type.getScaleData(context.getSource().method_9229()).getBaseScale();
							final int scaled = (int) (scale * FloatArgumentType.getFloat(context, "scalingFactor"));
							CommandUtils.sendFeedback(context.getSource(), () -> scaleText(scale, scaled), false);
							
							return scaled;
						})
					)
					.executes(context ->
					{
						final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
						final float scale = type.getScaleData(context.getSource().method_9229()).getBaseScale();
						CommandUtils.sendFeedback(context.getSource(), () -> scaleText(scale), false);
						
						return (int) scale;
					})
				)
				.then(class_2170.method_9244("scalingFactor", FloatArgumentType.floatArg())
					.executes(context ->
					{
						final float scale = ScaleTypes.BASE.getScaleData(context.getSource().method_9229()).getBaseScale();
						final int scaled = (int) (scale * FloatArgumentType.getFloat(context, "scalingFactor"));
						CommandUtils.sendFeedback(context.getSource(), () -> scaleText(scale, scaled), false);
						
						return scaled;
					})
				)
				.then(class_2170.method_9244("entity", class_2186.method_9309())
					.then(class_2170.method_9244("scalingFactor", FloatArgumentType.floatArg())
						.executes(context ->
						{
							final float scale = ScaleTypes.BASE.getScaleData(class_2186.method_9313(context, "entity")).getBaseScale();
							final int scaled = (int) (scale * FloatArgumentType.getFloat(context, "scalingFactor"));
							CommandUtils.sendFeedback(context.getSource(), () -> scaleText(scale, scaled), false);
							
							return scaled;
						})
					)
					.executes(context ->
					{
						final float scale = ScaleTypes.BASE.getScaleData(class_2186.method_9313(context, "entity")).getBaseScale();
						CommandUtils.sendFeedback(context.getSource(), () -> scaleText(scale), false);
						
						return (int) scale;
					})
				)
				.executes(context ->
				{
					final float scale = ScaleTypes.BASE.getScaleData(context.getSource().method_9229()).getBaseScale();
					CommandUtils.sendFeedback(context.getSource(), () -> scaleText(scale), false);
					
					return (int) scale;
				})
			);
		
		return builder;
	}
	
	private static LiteralArgumentBuilder<class_2168> registerCompute(final LiteralArgumentBuilder<class_2168> builder)
	{
		builder
			.then(class_2170.method_9247("compute")
				.then(class_2170.method_9244("scale_type", ScaleTypeArgumentType.scaleType())
					.then(class_2170.method_9244("entity", class_2186.method_9309())
						.then(class_2170.method_9244("scalingFactor", FloatArgumentType.floatArg())
							.executes(context ->
							{
								final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
								final float scale = type.getScaleData(class_2186.method_9313(context, "entity")).getScale();
								final int scaled = (int) (scale * FloatArgumentType.getFloat(context, "scalingFactor"));
								CommandUtils.sendFeedback(context.getSource(), () -> scaleText(scale, scaled), false);
								
								return scaled;
							})
						)
						.executes(context ->
						{
							final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
							final float scale = type.getScaleData(class_2186.method_9313(context, "entity")).getScale();
							CommandUtils.sendFeedback(context.getSource(), () -> scaleText(scale), false);
							
							return (int) scale;
						})
					)
					.then(class_2170.method_9244("scalingFactor", FloatArgumentType.floatArg())
						.executes(context ->
						{
							final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
							final float scale = type.getScaleData(context.getSource().method_9229()).getScale();
							final int scaled = (int) (scale * FloatArgumentType.getFloat(context, "scalingFactor"));
							CommandUtils.sendFeedback(context.getSource(), () -> scaleText(scale, scaled), false);
							
							return scaled;
						})
					)
					.executes(context ->
					{
						final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
						final float scale = type.getScaleData(context.getSource().method_9229()).getScale();
						CommandUtils.sendFeedback(context.getSource(), () -> scaleText(scale), false);
						
						return (int) scale;
					})
				)
			);
		
		return builder;
	}
	
	private static LiteralArgumentBuilder<class_2168> registerReset(final LiteralArgumentBuilder<class_2168> builder)
	{
		builder
			.then(class_2170.method_9247("reset")
				.then(class_2170.method_9244("scale_type", ScaleTypeArgumentType.scaleType())
					.then(class_2170.method_9244("targets", class_2186.method_9306())
						.executes(context ->
						{
							for (final class_1297 e : class_2186.method_9317(context, "targets"))
							{
								final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
								final ScaleData data = type.getScaleData(e);
								final Boolean persist = data.getPersistence();
								data.resetScale();
								data.setPersistence(persist);
							}
							
							return 1;
						})
					)
					.executes(context ->
					{
						final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
						final ScaleData data = type.getScaleData(context.getSource().method_9229());
						final Boolean persist = data.getPersistence();
						data.resetScale();
						data.setPersistence(persist);
						
						return 1;
					})
				)
				.then(class_2170.method_9244("targets", class_2186.method_9306())
					.executes(context ->
					{
						for (final class_1297 e : class_2186.method_9317(context, "targets"))
						{
							for (final ScaleType type : ScaleRegistries.SCALE_TYPES.values())
							{
								final ScaleData data = type.getScaleData(e);
								final Boolean persist = data.getPersistence();
								data.resetScale();
								data.setPersistence(persist);
							}
						}
						
						return 1;
					})
				)
				.executes(context ->
				{
					for (final ScaleType type : ScaleRegistries.SCALE_TYPES.values())
					{
						final ScaleData data = type.getScaleData(context.getSource().method_9229());
						final Boolean persist = data.getPersistence();
						data.resetScale();
						data.setPersistence(persist);
					}
					
					return 1;
				})
			);
		
		return builder;
	}
	
	private static LiteralArgumentBuilder<class_2168> registerModifier(final LiteralArgumentBuilder<class_2168> builder)
	{
		builder
			.then(class_2170.method_9247("modifier")
				.then(class_2170.method_9247("get")
					.then(class_2170.method_9244("scale_type", ScaleTypeArgumentType.scaleType())
						.then(class_2170.method_9244("entity", class_2186.method_9309())
							.executes(context ->
							{
								final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
								final ScaleData data = type.getScaleData(class_2186.method_9313(context, "entity"));
								
								final String modifierString = String.join(", ", data.getBaseValueModifiers().stream().map(e -> ScaleRegistries.getId(ScaleRegistries.SCALE_MODIFIERS, e).toString()).collect(Collectors.toList()));
								
								CommandUtils.sendFeedback(context.getSource(), () -> modifierText(modifierString), false);
								
								return 1;
							})
						)
						.executes(context ->
						{
							final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
							
							final String modifierString = String.join(", ", type.getDefaultBaseValueModifiers().stream().map(e -> ScaleRegistries.getId(ScaleRegistries.SCALE_MODIFIERS, e).toString()).collect(Collectors.toList()));
							
							CommandUtils.sendFeedback(context.getSource(), () -> modifierText(modifierString), false);
							
							return 1;
						})
					)
				)
				.then(class_2170.method_9247("add")
					.then(class_2170.method_9244("scale_type", ScaleTypeArgumentType.scaleType())
						.then(class_2170.method_9244("scale_modifier", ScaleModifierArgumentType.scaleModifier())
							.then(class_2170.method_9244("targets", class_2186.method_9306())
								.executes(context ->
								{
									for (final class_1297 e : class_2186.method_9317(context, "targets"))
									{
										final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
										final ScaleModifier modifier = ScaleModifierArgumentType.getScaleModifierArgument(context, "scale_modifier");
										final ScaleData data = type.getScaleData(e);
										data.getBaseValueModifiers().add(modifier);
									}
									
									return 1;
								})
							)
							.executes(context ->
							{
								final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
								final ScaleModifier modifier = ScaleModifierArgumentType.getScaleModifierArgument(context, "scale_modifier");
								final ScaleData data = type.getScaleData(context.getSource().method_9229());
								data.getBaseValueModifiers().add(modifier);
								
								return 1;
							})
						)
					)
				)
				.then(class_2170.method_9247("remove")
					.then(class_2170.method_9244("scale_type", ScaleTypeArgumentType.scaleType())
						.then(class_2170.method_9244("scale_modifier", ScaleModifierArgumentType.scaleModifier())
							.then(class_2170.method_9244("targets", class_2186.method_9306())
								.executes(context ->
								{
									for (final class_1297 e : class_2186.method_9317(context, "targets"))
									{
										final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
										final ScaleModifier modifier = ScaleModifierArgumentType.getScaleModifierArgument(context, "scale_modifier");
										final ScaleData data = type.getScaleData(e);
										data.getBaseValueModifiers().remove(modifier);
									}
									
									return 1;
								})
							)
							.executes(context ->
							{
								final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
								final ScaleModifier modifier = ScaleModifierArgumentType.getScaleModifierArgument(context, "scale_modifier");
								final ScaleData data = type.getScaleData(context.getSource().method_9229());
								data.getBaseValueModifiers().remove(modifier);
								
								return 1;
							})
						)
					)
				)
				.then(class_2170.method_9247("reset")
					.then(class_2170.method_9244("scale_type", ScaleTypeArgumentType.scaleType())
						.then(class_2170.method_9244("targets", class_2186.method_9306())
							.executes(context ->
							{
								for (final class_1297 e : class_2186.method_9317(context, "targets"))
								{
									final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
									final ScaleData data = type.getScaleData(e);
									
									final SortedSet<ScaleModifier> baseValueModifiers = data.getBaseValueModifiers();
									
									baseValueModifiers.clear();
									baseValueModifiers.addAll(type.getDefaultBaseValueModifiers());
								}
								
								return 1;
							})
						)
						.executes(context ->
						{
							final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
							final ScaleData data = type.getScaleData(context.getSource().method_9229());
							
							final SortedSet<ScaleModifier> baseValueModifiers = data.getBaseValueModifiers();
							
							baseValueModifiers.clear();
							baseValueModifiers.addAll(type.getDefaultBaseValueModifiers());
							
							return 1;
						})
					)
				)
			);
		
		return builder;
	}
	
	private static LiteralArgumentBuilder<class_2168> registerDelay(final LiteralArgumentBuilder<class_2168> builder)
	{
		builder
			.then(class_2170.method_9247("delay")
				.then(class_2170.method_9247("set")
					.then(class_2170.method_9244("scale_type", ScaleTypeArgumentType.scaleType())
						.then(class_2170.method_9244("ticks", IntegerArgumentType.integer())
							.then(class_2170.method_9244("targets", class_2186.method_9306())
								.executes(context ->
								{
									final int ticks = IntegerArgumentType.getInteger(context, "ticks");
									final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
									
									for (final class_1297 e : class_2186.method_9317(context, "targets"))
									{
										final ScaleData data = type.getScaleData(e);
										
										data.setScaleTickDelay(ticks);
									}
									
									return 1;
								})
							)
							.executes(context ->
							{
								final int ticks = IntegerArgumentType.getInteger(context, "ticks");
								final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
								
								final ScaleData data = type.getScaleData(context.getSource().method_9229());
								
								data.setScaleTickDelay(ticks);
								
								return 1;
							})
						)
					)
					.then(class_2170.method_9244("ticks", IntegerArgumentType.integer())
						.then(class_2170.method_9244("targets", class_2186.method_9306())
							.executes(context ->
							{
								final int ticks = IntegerArgumentType.getInteger(context, "ticks");
								
								for (final class_1297 e : class_2186.method_9317(context, "targets"))
								{
									final ScaleData data = ScaleTypes.BASE.getScaleData(e);
									
									data.setScaleTickDelay(ticks);
								}
								
								return 1;
							})
						)
						.executes(context ->
						{
							final int ticks = IntegerArgumentType.getInteger(context, "ticks");
							
							final ScaleData data = ScaleTypes.BASE.getScaleData(context.getSource().method_9229());
							
							data.setScaleTickDelay(ticks);
							
							return 1;
						})
					)
				)
				.then(class_2170.method_9247("get")
					.then(class_2170.method_9244("scale_type", ScaleTypeArgumentType.scaleType())
						.then(class_2170.method_9244("entity", class_2186.method_9309())
							.executes(context ->
							{
								final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
								final int ticks = type.getScaleData(class_2186.method_9313(context, "entity")).getScaleTickDelay();
								CommandUtils.sendFeedback(context.getSource(), () -> delayText(ticks), false);
								return 1;
							})
						)
						.executes(context ->
						{
							final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
							final int ticks = type.getScaleData(context.getSource().method_9229()).getScaleTickDelay();
							CommandUtils.sendFeedback(context.getSource(), () -> delayText(ticks), false);
							return 1;
						})
					)
					.then(class_2170.method_9244("entity", class_2186.method_9309())
						.executes(context ->
						{
							final int ticks = ScaleTypes.BASE.getScaleData(class_2186.method_9313(context, "entity")).getScaleTickDelay();
							CommandUtils.sendFeedback(context.getSource(), () -> delayText(ticks), false);
							return 1;
						})
					)
					.executes(context ->
					{
						final int ticks = ScaleTypes.BASE.getScaleData(context.getSource().method_9229()).getScaleTickDelay();
						CommandUtils.sendFeedback(context.getSource(), () -> delayText(ticks), false);
						return 1;
					})
				)
				.then(class_2170.method_9247("reset")
					.then(class_2170.method_9244("scale_type", ScaleTypeArgumentType.scaleType())
						.then(class_2170.method_9244("targets", class_2186.method_9306())
							.executes(context ->
							{
								final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
								final int ticks = type.getDefaultTickDelay();
								
								for (final class_1297 e : class_2186.method_9317(context, "targets"))
								{
									final ScaleData data = type.getScaleData(e);
									
									data.setScaleTickDelay(ticks);
								}
								
								CommandUtils.sendFeedback(context.getSource(), () -> delayText(ticks), false);
								
								return 1;
							})
						)
						.executes(context ->
						{
							final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
							final int ticks = type.getDefaultTickDelay();
							
							final ScaleData data = type.getScaleData(context.getSource().method_9229());
							
							data.setScaleTickDelay(ticks);
							
							CommandUtils.sendFeedback(context.getSource(), () -> delayText(ticks), false);
							
							return 1;
						})
					)
					.then(class_2170.method_9244("targets", class_2186.method_9306())
						.executes(context ->
						{
							final int ticks = ScaleTypes.BASE.getDefaultTickDelay();
							
							for (final class_1297 e : class_2186.method_9317(context, "targets"))
							{
								final ScaleData data = ScaleTypes.BASE.getScaleData(e);
								
								data.setScaleTickDelay(ticks);
							}
							
							CommandUtils.sendFeedback(context.getSource(), () -> delayText(ticks), false);
							
							return 1;
						})
					)
					.executes(context ->
					{
						final int ticks = ScaleTypes.BASE.getDefaultTickDelay();
						
						final ScaleData data = ScaleTypes.BASE.getScaleData(context.getSource().method_9229());
						
						data.setScaleTickDelay(ticks);
						
						CommandUtils.sendFeedback(context.getSource(), () -> delayText(ticks), false);
						
						return 1;
					})
				)
			);
		
		return builder;
	}
	
	private static LiteralArgumentBuilder<class_2168> registerEasing(final LiteralArgumentBuilder<class_2168> builder)
	{
		builder
			.then(class_2170.method_9247("easing")
				.then(class_2170.method_9247("set")
					.then(class_2170.method_9244("scale_type", ScaleTypeArgumentType.scaleType())
						.then(class_2170.method_9244("easing", ScaleEasingArgumentType.scaleEasing())
							.then(class_2170.method_9244("targets", class_2186.method_9306())
								.executes(context ->
								{
									final Float2FloatFunction easing = ScaleEasingArgumentType.getScaleEasingArgument(context, "easing");
									final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
									
									for (final class_1297 e : class_2186.method_9317(context, "targets"))
									{
										final ScaleData data = type.getScaleData(e);
										
										data.setEasing(easing);
									}
									
									return 1;
								})
							)
							.executes(context ->
							{
								final Float2FloatFunction easing = ScaleEasingArgumentType.getScaleEasingArgument(context, "easing");
								final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
								
								final ScaleData data = type.getScaleData(context.getSource().method_9229());
								
								data.setEasing(easing);
								
								return 1;
							})
						)
					)
				)
				.then(class_2170.method_9247("get")
					.then(class_2170.method_9244("scale_type", ScaleTypeArgumentType.scaleType())
						.then(class_2170.method_9244("entity", class_2186.method_9309())
							.executes(context ->
							{
								final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
								final Float2FloatFunction easing = type.getScaleData(class_2186.method_9313(context, "entity")).getEasing();
								CommandUtils.sendFeedback(context.getSource(), () -> easingText(easing, type), false);
								return 1;
							})
						)
						.executes(context ->
						{
							final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
							final Float2FloatFunction easing = type.getScaleData(context.getSource().method_9229()).getEasing();
							CommandUtils.sendFeedback(context.getSource(), () -> easingText(easing, type), false);
							return 1;
						})
					)
					.then(class_2170.method_9244("entity", class_2186.method_9309())
						.executes(context ->
						{
							final Float2FloatFunction easing = ScaleTypes.BASE.getScaleData(class_2186.method_9313(context, "entity")).getEasing();
							CommandUtils.sendFeedback(context.getSource(), () -> easingText(easing, ScaleTypes.BASE), false);
							return 1;
						})
					)
					.executes(context ->
					{
						final Float2FloatFunction easing = ScaleTypes.BASE.getScaleData(context.getSource().method_9229()).getEasing();
						CommandUtils.sendFeedback(context.getSource(), () -> easingText(easing, ScaleTypes.BASE), false);
						return 1;
					})
				)
				.then(class_2170.method_9247("reset")
					.then(class_2170.method_9244("scale_type", ScaleTypeArgumentType.scaleType())
						.then(class_2170.method_9244("targets", class_2186.method_9306())
							.executes(context ->
							{
								final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
								
								for (final class_1297 e : class_2186.method_9317(context, "targets"))
								{
									final ScaleData data = type.getScaleData(e);
									
									data.setEasing(null);
								}
								
								CommandUtils.sendFeedback(context.getSource(), () -> easingText(null, type), false);
								
								return 1;
							})
						)
						.executes(context ->
						{
							final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
							
							final ScaleData data = type.getScaleData(context.getSource().method_9229());
							
							data.setEasing(null);
							
							CommandUtils.sendFeedback(context.getSource(), () -> easingText(null, type), false);
							
							return 1;
						})
					)
					.then(class_2170.method_9244("targets", class_2186.method_9306())
						.executes(context ->
						{
							for (final class_1297 e : class_2186.method_9317(context, "targets"))
							{
								final ScaleData data = ScaleTypes.BASE.getScaleData(e);
								
								data.setEasing(null);
							}
							
							CommandUtils.sendFeedback(context.getSource(), () -> easingText(null, ScaleTypes.BASE), false);
							
							return 1;
						})
					)
					.executes(context ->
					{
						final ScaleData data = ScaleTypes.BASE.getScaleData(context.getSource().method_9229());
						
						data.setEasing(null);
						
						CommandUtils.sendFeedback(context.getSource(), () -> easingText(null, ScaleTypes.BASE), false);
						
						return 1;
					})
				)
			);
		
		return builder;
	}
	
	private static LiteralArgumentBuilder<class_2168> registerPersist(final LiteralArgumentBuilder<class_2168> builder)
	{
		builder
			.then(class_2170.method_9247("persist")
				.then(class_2170.method_9247("set")
					.then(class_2170.method_9244("scale_type", ScaleTypeArgumentType.scaleType())
						.then(class_2170.method_9244("enabled", BoolArgumentType.bool())
							.then(class_2170.method_9244("targets", class_2186.method_9306())
								.executes(context ->
								{
									final boolean persist = BoolArgumentType.getBool(context, "enabled");
									final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
									
									for (final class_1297 e : class_2186.method_9317(context, "targets"))
									{
										final ScaleData data = type.getScaleData(e);
										
										data.setPersistence(persist);
									}
									
									return 1;
								})
							)
							.executes(context ->
							{
								final boolean persist = BoolArgumentType.getBool(context, "enabled");
								final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
								
								final ScaleData data = type.getScaleData(context.getSource().method_9229());
								
								data.setPersistence(persist);
								
								return 1;
							})
						)
					)
					.then(class_2170.method_9244("enabled", BoolArgumentType.bool())
						.then(class_2170.method_9244("targets", class_2186.method_9306())
							.executes(context ->
							{
								final boolean persist = BoolArgumentType.getBool(context, "enabled");
								
								for (final class_1297 e : class_2186.method_9317(context, "targets"))
								{
									for (final ScaleType type : ScaleRegistries.SCALE_TYPES.values())
									{
										final ScaleData data = type.getScaleData(e);
										data.setPersistence(persist);
									}
								}
								
								return 1;
							})
						)
						.executes(context ->
						{
							final boolean persist = BoolArgumentType.getBool(context, "enabled");
							
							for (final ScaleType type : ScaleRegistries.SCALE_TYPES.values())
							{
								final ScaleData data = type.getScaleData(context.getSource().method_9229());
								data.setPersistence(persist);
							}
							
							return 1;
						})
					)
				)
				.then(class_2170.method_9247("get")
					.then(class_2170.method_9244("scale_type", ScaleTypeArgumentType.scaleType())
						.then(class_2170.method_9244("entity", class_2186.method_9309())
							.executes(context ->
							{
								final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
								final Boolean persist = type.getScaleData(class_2186.method_9313(context, "entity")).getPersistence();
								CommandUtils.sendFeedback(context.getSource(), () -> persistenceText(persist, type), false);
								return 1;
							})
						)
						.executes(context ->
						{
							final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
							final Boolean persist = type.getScaleData(context.getSource().method_9229()).getPersistence();
							CommandUtils.sendFeedback(context.getSource(), () -> persistenceText(persist, type), false);
							return 1;
						})
					)
				)
				.then(class_2170.method_9247("reset")
					.then(class_2170.method_9244("scale_type", ScaleTypeArgumentType.scaleType())
						.then(class_2170.method_9244("targets", class_2186.method_9306())
							.executes(context ->
							{
								final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
								
								for (final class_1297 e : class_2186.method_9317(context, "targets"))
								{
									final ScaleData data = type.getScaleData(e);
									
									data.setPersistence(null);
								}
								
								return 1;
							})
						)
						.executes(context ->
						{
							final ScaleType type = ScaleTypeArgumentType.getScaleTypeArgument(context, "scale_type");
							
							final ScaleData data = type.getScaleData(context.getSource().method_9229());
							
							data.setPersistence(null);
							
							return 1;
						})
					)
					.then(class_2170.method_9244("targets", class_2186.method_9306())
						.executes(context ->
						{
							for (final class_1297 e : class_2186.method_9317(context, "targets"))
							{
								for (final ScaleType type : ScaleRegistries.SCALE_TYPES.values())
								{
									final ScaleData data = type.getScaleData(e);
									data.setPersistence(null);
								}
							}
							
							return 1;
						})
					)
					.executes(context ->
					{
						for (final ScaleType type : ScaleRegistries.SCALE_TYPES.values())
						{
							final ScaleData data = type.getScaleData(context.getSource().method_9229());
							data.setPersistence(null);
						}
						
						return 1;
					})
				)
			);
		
		return builder;
	}
	
	private static LiteralArgumentBuilder<class_2168> registerNbt(final LiteralArgumentBuilder<class_2168> builder)
	{
		builder
			.then(class_2170.method_9247("nbt")
				.then(class_2170.method_9247("get")
					.then(class_2170.method_9244("entity", class_2186.method_9309())
						.then(class_2170.method_9244("path", class_2203.method_9360())
							.executes(context ->
								DataCommandInvoker.Path.callExecuteGet(
									context.getSource(),
									new EntityScaleDataObject(class_2186.method_9313(context, "entity")),
									class_2203.method_9358(context, "path")
								)
							)
							.then(class_2170.method_9244("scale", DoubleArgumentType.doubleArg())
								.executes(context ->
									DataCommandInvoker.Scaled.callExecuteGet(
										context.getSource(),
										new EntityScaleDataObject(class_2186.method_9313(context, "entity")),
										class_2203.method_9358(context, "path"),
										DoubleArgumentType.getDouble(context, "scale")
									)
								)
							)
						)
						.executes(context ->
							DataCommandInvoker.Get.callExecuteGet(
								context.getSource(),
								new EntityScaleDataObject(class_2186.method_9313(context, "entity"))
							)
						)
					)
					.executes(context ->
					{
						final class_3169 obj = new EntityScaleDataObject(context.getSource().method_9229());
						
						final class_2487 nbt = obj.method_13881();
						CommandUtils.sendFeedback(context.getSource(), () -> obj.method_13882(nbt), false);
						
						return nbt.method_10546();
					})
				)
			);
		
		return builder;
	}
	
	private static class EntityScaleDataObject extends class_3169
	{
		private final class_1297 entity;
		
		public EntityScaleDataObject(class_1297 entity)
		{
			super(entity);
			this.entity = entity;
		}
		
		@Override
		public void method_13880(class_2487 nbt) throws CommandSyntaxException
		{
			((PehkuiEntityExtensions) entity).pehkui_readScaleNbt(nbt);
		}
		
		@Override
		public class_2487 method_13881()
		{
			return ((PehkuiEntityExtensions) entity).pehkui_writeScaleNbt(new class_2487());
		}
	}
	
	private static class_2561 scaleText(float scale)
	{
		final long denominator = (long) (1.0F / scale);
		if (((long) scale) != 1L && Float.compare(scale, 1.0F / denominator) == 0)
		{
			return I18nUtils.translate("commands.pehkui.scale.get.fraction.message", "Scale: %s (1/%s)", format(scale), format(denominator));
		}
		
		return I18nUtils.translate("commands.pehkui.scale.get.message", "Scale: %s", format(scale));
	}
	
	private static class_2561 scaleText(float scale, int multiplied)
	{
		final long denominator = (long) (1.0F / scale);
		if (((long) scale) != 1L && Float.compare(scale, 1.0F / denominator) == 0)
		{
			return I18nUtils.translate("commands.pehkui.scale.get.fraction.factor.message", "Scale: %s (1/%s) | (%s)", format(scale), format(denominator), format(multiplied));
		}
		
		return I18nUtils.translate("commands.pehkui.scale.get.factor.message", "Scale: %s | (%s)", format(scale), format(multiplied));
	}
	
	private static class_2561 modifierText(String modifierString)
	{
		return I18nUtils.translate("commands.pehkui.scale.modifier.get.message", "%s", modifierString.isEmpty() ? "N/A" : modifierString);
	}
	
	private static class_2561 delayText(int ticks)
	{
		return I18nUtils.translate("commands.pehkui.scale.delay.get.message", "Delay: %s ticks", format(ticks));
	}
	
	private static class_2561 persistenceText(@Nullable Boolean persist, ScaleType type)
	{
		final String unlocalized = "commands.pehkui.scale.persist." + (persist != null ? persist : ("default." + type.getDefaultPersistence()));
		final String message = "Persistent: " + (persist == null ? "default (" + type.getDefaultPersistence() + ")" : persist);
		return I18nUtils.translate(unlocalized, message);
	}
	
	private static class_2561 easingText(@Nullable Float2FloatFunction easing, ScaleType type)
	{
		final String easingId = ScaleRegistries.getId(ScaleRegistries.SCALE_EASINGS, easing != null ? easing : type.getDefaultEasing()).toString();
		final String unlocalized = "commands.pehkui.scale.easing" + (easing != null ? "" : ".default");
		final String message = "Easing: " + (easing == null ? "default (" + easingId + ")" : easingId);
		return I18nUtils.translate(unlocalized, message, easingId);
	}
	
	private static final Random RANDOM = new Random();
	
	private static final DecimalFormat SCALE_FORMAT;
	
	static
	{
		SCALE_FORMAT = new DecimalFormat("#,##0");
		SCALE_FORMAT.setMaximumFractionDigits(340);
	}
	
	private static String format(int scale)
	{
		return SCALE_FORMAT.format(scale);
	}
	
	private static String format(long scale)
	{
		return SCALE_FORMAT.format(scale);
	}
	
	private static String format(float scale)
	{
		return SCALE_FORMAT.format(scale);
	}
}
