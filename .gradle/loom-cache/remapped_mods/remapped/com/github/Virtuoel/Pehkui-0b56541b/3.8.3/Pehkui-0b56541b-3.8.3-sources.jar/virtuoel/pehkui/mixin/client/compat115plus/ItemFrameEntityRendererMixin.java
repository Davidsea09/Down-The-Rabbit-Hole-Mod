package virtuoel.pehkui.mixin.client.compat115plus;

import net.minecraft.class_1533;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_915;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_915.class)
public class ItemFrameEntityRendererMixin
{
	@ModifyVariable(method = "render", at = @At(value = "STORE"))
	private class_243 pehkui$render(class_243 value, class_1533 itemFrameEntity, float f, float g, class_4587 matrixStack, class_4597 vertexConsumerProvider, int i)
	{
		final float widthScale = ScaleUtils.getBoundingBoxWidthScale(itemFrameEntity);
		final float heightScale = ScaleUtils.getBoundingBoxHeightScale(itemFrameEntity);
		
		if (widthScale != 1.0F || heightScale != 1.0F)
		{
			value = value.method_18805(1.0F / widthScale, 1.0F / heightScale, 1.0F / widthScale);
			
			final class_2350 facing = itemFrameEntity.method_5735();
			
			final double widthOffset = ((0.0625D - (0.03125D * widthScale)) - 0.03125D) / widthScale;
			final double heightOffset = ((0.0625D - (0.03125D * heightScale)) - 0.03125D) / heightScale;
			
			value = value.method_1031(widthOffset * facing.method_10148(), heightOffset * facing.method_10164(), widthOffset * facing.method_10165());
		}
		
		return value;
	}
}
