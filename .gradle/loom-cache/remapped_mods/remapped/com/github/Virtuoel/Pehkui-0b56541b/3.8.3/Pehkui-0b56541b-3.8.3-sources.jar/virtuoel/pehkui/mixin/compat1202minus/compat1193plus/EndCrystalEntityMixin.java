package virtuoel.pehkui.mixin.compat1202minus.compat1193plus;

import net.minecraft.class_1297;
import net.minecraft.class_1511;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1511.class)
public abstract class EndCrystalEntityMixin
{
	@Dynamic
	@ModifyArg(method = "damage", at = @At(value = "INVOKE", target = MixinConstants.CREATE_EXPLOSION_TYPED))
	private float pehkui$damage$createExplosion(float power)
	{
		final float scale = ScaleUtils.getExplosionScale((class_1297) (Object) this);
		
		return scale != 1.0F ? power * scale : power;
	}
}
