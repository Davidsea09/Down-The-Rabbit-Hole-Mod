package virtuoel.pehkui.mixin.compat1204minus.compat1193plus;

import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.class_1297;
import net.minecraft.class_4048;
import net.minecraft.class_4050;
import net.minecraft.class_7689;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_7689.class)
public class CamelEntityMixin
{
	@Dynamic
	@ModifyReturnValue(method = MixinConstants.GET_DIMENSIONS, at = @At("RETURN"))
	private class_4048 pehkui$getDimensions(class_4048 original, class_4050 pose)
	{
		if (pose == class_4050.field_40118)
		{
			original = original.method_19539(ScaleUtils.getBoundingBoxWidthScale((class_1297) (Object) this), ScaleUtils.getBoundingBoxHeightScale((class_1297) (Object) this));
		}
		
		return original;
	}
}
