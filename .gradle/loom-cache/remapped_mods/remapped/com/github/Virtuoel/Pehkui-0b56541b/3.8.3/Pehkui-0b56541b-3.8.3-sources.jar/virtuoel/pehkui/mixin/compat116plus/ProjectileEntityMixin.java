package virtuoel.pehkui.mixin.compat116plus;

import net.minecraft.class_1297;
import net.minecraft.class_1676;
import net.minecraft.class_238;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1676.class)
public abstract class ProjectileEntityMixin
{
	@ModifyArg(method = "shouldLeaveOwner", index = 1, at = @At(value = "INVOKE", target = "Lnet/minecraft/world/World;getOtherEntities(Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/Box;Ljava/util/function/Predicate;)Ljava/util/List;"))
	private class_238 pehkui$shouldLeaveOwner$expand(class_238 value)
	{
		final float width = ScaleUtils.getBoundingBoxWidthScale((class_1297) (Object) this);
		final float height = ScaleUtils.getBoundingBoxHeightScale((class_1297) (Object) this);
		
		if (width != 1.0F || height != 1.0F)
		{
			return value.method_1009(width - 1.0D, height - 1.0D, width - 1.0D);
		}
		
		return value;
	}
	
	@ModifyVariable(method = "setVelocity(DDDFF)V", ordinal = 0, argsOnly = true, at = @At("HEAD"))
	private float pehkui$setVelocity$power(float value)
	{
		final float scale = ScaleUtils.getMotionScale((class_1297) (Object) this);
		
		return scale != 1.0F ? value * scale : value;
	}
	
	@Inject(at = @At("HEAD"), method = "setOwner")
	private void pehkui$setOwner(@Nullable class_1297 entity, CallbackInfo info)
	{
		if (entity != null)
		{
			ScaleUtils.setScaleOfProjectile((class_1297) (Object) this, entity);
		}
	}
}
