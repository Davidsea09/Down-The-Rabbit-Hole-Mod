package virtuoel.pehkui.mixin.compat114;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin
{
	@Dynamic
	@ModifyArg(method = MixinConstants.DEATH, at = @At(value = "INVOKE", target = MixinConstants.SPAWN_ENTITY))
	private class_1297 pehkui$onDeath$entity(class_1297 entity)
	{
		ScaleUtils.setScaleOfDrop(entity, (class_1297) (Object) this);
		
		return entity;
	}
	
	@Dynamic
	@ModifyArg(method = MixinConstants.POST_DEATH, at = @At(value = "INVOKE", target = MixinConstants.SPAWN_ENTITY))
	private class_1297 pehkui$updatePostDeath$entity(class_1297 entity)
	{
		ScaleUtils.setScaleOfDrop(entity, (class_1297) (Object) this);
		
		return entity;
	}
}
