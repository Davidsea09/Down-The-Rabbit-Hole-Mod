package virtuoel.pehkui.mixin.compat1193minus;

import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1657;
import net.minecraft.class_2586;
import net.minecraft.class_2589;
import net.minecraft.class_2609;
import net.minecraft.class_2621;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin({
	class_2609.class,
	class_2589.class,
	class_2621.class,
})
public abstract class BlockEntityUseDistanceMixin
{
	@Dynamic
	@ModifyExpressionValue(method = MixinConstants.CAN_PLAYER_USE, at = @At(value = "CONSTANT", args = "doubleValue=0.5D", ordinal = 0))
	private double pehkui$canPlayerUse$xOffset(double value, class_1657 player)
	{
		return ScaleUtils.getBlockXOffset(((class_2586) (Object) this).method_11016(), player);
	}
	
	@Dynamic
	@ModifyExpressionValue(method = MixinConstants.CAN_PLAYER_USE, at = @At(value = "CONSTANT", args = "doubleValue=0.5D", ordinal = 1))
	private double pehkui$canPlayerUse$yOffset(double value, class_1657 player)
	{
		return ScaleUtils.getBlockYOffset(((class_2586) (Object) this).method_11016(), player);
	}
	
	@Dynamic
	@ModifyExpressionValue(method = MixinConstants.CAN_PLAYER_USE, at = @At(value = "CONSTANT", args = "doubleValue=0.5D", ordinal = 2))
	private double pehkui$canPlayerUse$zOffset(double value, class_1657 player)
	{
		return ScaleUtils.getBlockZOffset(((class_2586) (Object) this).method_11016(), player);
	}
}
