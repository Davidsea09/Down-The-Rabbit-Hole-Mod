package virtuoel.pehkui.mixin.client.compat116plus;

import net.minecraft.class_1297;
import net.minecraft.class_1542;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1542.class)
public abstract class ItemEntityMixin
{
	@Inject(at = @At("RETURN"), method = "<init>(Lnet/minecraft/entity/ItemEntity;)V")
	private void pehkui$construct(class_1542 entity, CallbackInfo info)
	{
		ScaleUtils.loadScale((class_1297) (Object) this, entity);
	}
}
