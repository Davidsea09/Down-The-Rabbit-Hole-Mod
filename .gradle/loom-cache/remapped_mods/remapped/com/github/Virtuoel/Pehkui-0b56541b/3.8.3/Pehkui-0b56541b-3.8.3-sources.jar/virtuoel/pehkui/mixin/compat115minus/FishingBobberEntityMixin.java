package virtuoel.pehkui.mixin.compat115minus;

import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1536;
import net.minecraft.class_1657;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1536.class)
public abstract class FishingBobberEntityMixin
{
	@Dynamic @Shadow @Final @Mutable
	class_1657 field_7177; // UNMAPPED_FIELD
	
	@Dynamic
	@ModifyExpressionValue(method = MixinConstants.REMOVE_IF_INVALID, at = @At(value = "CONSTANT", args = "doubleValue=1024.0D"))
	private double pehkui$removeIfInvalid$distance(double value)
	{
		final float scale = ScaleUtils.getProjectileScale(field_7177);
		
		if (scale != 1.0F)
		{
			return value * scale * scale;
		}
		
		return value;
	}
}
