package virtuoel.pehkui.mixin.compat115minus;

import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin extends EntityMixin
{
	@Dynamic
	@ModifyExpressionValue(method = MixinConstants.TRAVEL, at = @At(value = "CONSTANT", args = "floatValue=4.0F"))
	private float pehkui$travel$limbDistance(float value)
	{
		return ScaleUtils.modifyLimbDistance(value, (class_1297) (Object) this);
	}
	
	@Unique class_243 pehkui$initialClimbingPos = null;
	
	@ModifyReturnValue(method = "isClimbing()Z", at = @At("RETURN"))
	private boolean pehkui$isClimbing(boolean original)
	{
		final class_1309 self = (class_1309) (Object) this;
		
		if (pehkui$initialClimbingPos != null || original || self.method_7325())
		{
			return original;
		}
		
		final float width = ScaleUtils.getBoundingBoxWidthScale(self);
		
		if (width > 1.0F)
		{
			final class_238 bounds = self.method_5829();
			
			final double halfUnscaledXLength = (bounds.method_17939() / width) / 2.0D;
			final int minX = class_3532.method_15357(bounds.field_1323 + halfUnscaledXLength);
			final int maxX = class_3532.method_15357(bounds.field_1320 - halfUnscaledXLength);
			
			final int minY = class_3532.method_15357(bounds.field_1322);
			
			final double halfUnscaledZLength = (bounds.method_17941() / width) / 2.0D;
			final int minZ = class_3532.method_15357(bounds.field_1321 + halfUnscaledZLength);
			final int maxZ = class_3532.method_15357(bounds.field_1324 - halfUnscaledZLength);
			
			pehkui$initialClimbingPos = method_5812();
			
			for (final class_2338 pos : class_2338.method_10094(minX, minY, minZ, maxX, minY, maxZ))
			{
				setPosDirectly(pos.method_10263(), pos.method_10264(), pos.method_10260());
				if (self.method_6101())
				{
					return true;
				}
			}
			
			setPosDirectly(pehkui$initialClimbingPos.method_10216(), pehkui$initialClimbingPos.method_10214(), pehkui$initialClimbingPos.method_10215());
			pehkui$initialClimbingPos = null;
		}
		
		return original;
	}
}
