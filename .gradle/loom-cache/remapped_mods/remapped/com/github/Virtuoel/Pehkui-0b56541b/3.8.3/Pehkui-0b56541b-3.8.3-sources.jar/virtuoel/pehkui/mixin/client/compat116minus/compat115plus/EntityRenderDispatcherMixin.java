package virtuoel.pehkui.mixin.client.compat116minus.compat115plus;

import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleRenderUtils;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_898.class)
public class EntityRenderDispatcherMixin
{
	@Dynamic
	@Inject(method = MixinConstants.RENDER_HITBOX, at = @At(value = "TAIL"))
	private void pehkui$renderHitbox(class_4587 matrices, class_4588 vertices, class_1297 entity, float tickDelta, CallbackInfo ci)
	{
		final float interactionWidth = ScaleUtils.getInteractionBoxWidthScale(entity);
		final float interactionHeight = ScaleUtils.getInteractionBoxHeightScale(entity);
		final float margin = entity.method_5871();
		
		if (interactionWidth != 1.0F || interactionHeight != 1.0F || margin != 0.0F)
		{
			class_238 bounds = entity.method_5829();
			
			final double scaledXLength = bounds.method_17939() * 0.5D * (interactionWidth - 1.0F);
			final double scaledYLength = bounds.method_17940() * 0.5D * (interactionHeight - 1.0F);
			final double scaledZLength = bounds.method_17941() * 0.5D * (interactionWidth - 1.0F);
			final double scaledMarginWidth = margin * interactionWidth;
			final double scaledMarginHeight = margin * interactionHeight;
			
			bounds = bounds.method_1009(scaledXLength + scaledMarginWidth, scaledYLength + scaledMarginHeight, scaledZLength + scaledMarginWidth)
				.method_989(-entity.method_23317(), -entity.method_23318(), -entity.method_23321());
			
			ScaleRenderUtils.renderInteractionBox(matrices, vertices, bounds);
		}
	}
}
