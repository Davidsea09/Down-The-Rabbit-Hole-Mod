package virtuoel.pehkui.mixin;

import net.minecraft.class_1297;
import net.minecraft.class_1530;
import net.minecraft.class_1542;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1530.class)
public abstract class AbstractDecorationEntityMixin
{
	@ModifyVariable(method = "dropStack(Lnet/minecraft/item/ItemStack;F)Lnet/minecraft/entity/ItemEntity;", at = @At(value = "STORE"))
	private class_1542 pehkui$dropStack(class_1542 entity)
	{
		ScaleUtils.setScaleOfDrop(entity, (class_1297) (Object) this);
		return entity;
	}
	
	@ModifyArg(method = "updateAttachmentPosition()V", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/decoration/AbstractDecorationEntity;setBoundingBox(Lnet/minecraft/util/math/Box;)V"))
	private class_238 pehkui$updateAttachmentPosition$setBoundingBox(class_238 box)
	{
		final class_1530 entity = (class_1530) (Object) this;
		
		final class_2350 facing = entity.method_5735();
		
		final double xLength = box.method_17939() / -2.0D;
		final double yLength = box.method_17940() / -2.0D;
		final double zLength = box.method_17941() / -2.0D;
		
		final float widthScale = ScaleUtils.getBoundingBoxWidthScale(entity);
		final float heightScale = ScaleUtils.getBoundingBoxHeightScale(entity);
		
		if (widthScale != 1.0F || heightScale != 1.0F)
		{
			final double dX = xLength * (1.0D - widthScale);
			final double dY = yLength * (1.0D - heightScale);
			final double dZ = zLength * (1.0D - widthScale);
			box = box.method_1009(dX, dY, dZ);
			box = box.method_989(dX * facing.method_10148(), dY * facing.method_10164(), dZ * facing.method_10165());
		}
		
		return box;
	}
}
