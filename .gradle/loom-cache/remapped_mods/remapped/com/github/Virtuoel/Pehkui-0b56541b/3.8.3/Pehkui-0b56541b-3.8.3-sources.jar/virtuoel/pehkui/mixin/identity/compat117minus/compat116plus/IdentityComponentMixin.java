package virtuoel.pehkui.mixin.identity.compat117minus.compat116plus;

import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2487;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import virtuoel.pehkui.util.ScaleUtils;

@Pseudo
@Mixin(targets = "draylar.identity.cca.IdentityComponent", remap = false)
public class IdentityComponentMixin
{
	@Shadow(remap = false) class_1657 player;
	@Shadow(remap = false) class_1309 identity;
	
	@Inject(at = @At("RETURN"), method = "readFromNbt", remap = false)
	private void pehkui$readFromNbt(class_2487 nbt, CallbackInfo info)
	{
		if (this.identity != null)
		{
			ScaleUtils.loadScale(player, identity);
		}
	}
	
	@Inject(at = @At("TAIL"), method = "setIdentity", remap = false)
	private void pehkui$setIdentity(class_1309 identity, CallbackInfoReturnable<Boolean> info)
	{
		if (identity != null)
		{
			ScaleUtils.loadScale(identity, player);
		}
	}
}
