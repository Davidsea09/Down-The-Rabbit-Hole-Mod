package virtuoel.pehkui.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3736;
import virtuoel.pehkui.util.MulticonnectCompatibility;
import virtuoel.pehkui.util.PehkuiBlockStateExtensions;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin
{
	@Inject(method = "tickMovement", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;setVelocity(DDD)V", shift = Shift.AFTER))
	private void pehkui$tickMovement$minVelocity(CallbackInfo info, @Local class_243 velocity)
	{
		final class_1309 self = (class_1309) (Object) this;
		
		final float scale = ScaleUtils.getMotionScale(self);
		
		if (scale < 1.0F)
		{
			final double min = scale * MulticonnectCompatibility.INSTANCE.getProtocolDependentValue(ver -> ver <= 47, 0.005D, 0.003D);
			
			double vX = velocity.field_1352;
			double vY = velocity.field_1351;
			double vZ = velocity.field_1350;
			
			if (Math.abs(vX) < min)
			{
				vX = 0.0D;
			}
			
			if (Math.abs(vY) < min)
			{
				vY = 0.0D;
			}
			
			if (Math.abs(vZ) < min)
			{
				vZ = 0.0D;
			}
			
			self.method_18800(vX, vY, vZ);
		}
	}
	
	@ModifyVariable(method = "applyArmorToDamage(Lnet/minecraft/entity/damage/DamageSource;F)F", at = @At("HEAD"), argsOnly = true)
	private float pehkui$applyArmorToDamage(float value, class_1282 source, float amount)
	{
		final class_1297 attacker = source.method_5529();
		final float attackScale = attacker == null ? 1.0F : ScaleUtils.getAttackScale(attacker);
		final float defenseScale = ScaleUtils.getDefenseScale((class_1297) (Object) this);
		
		if (attackScale != 1.0F || defenseScale != 1.0F)
		{
			value = attackScale * value / defenseScale;
		}
		
		return value;
	}
	
	@ModifyReturnValue(method = "getMaxHealth", at = @At("RETURN"))
	private float pehkui$getMaxHealth(float original)
	{
		final float scale = ScaleUtils.getHealthScale((class_1297) (Object) this);
		
		return scale != 1.0F ? original * scale : original;
	}
	
	@ModifyReturnValue(method = "getAttackDistanceScalingFactor", at = @At("RETURN"))
	private double pehkui$getAttackDistanceScalingFactor(double original)
	{
		final float scale = ScaleUtils.getVisibilityScale((class_1297) (Object) this);
		
		return scale != 1.0F ? original * scale : original;
	}
	
	@ModifyReturnValue(method = "applyClimbingSpeed(Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;", at = @At("RETURN"))
	private class_243 pehkui$applyClimbingSpeed(class_243 original)
	{
		final class_1309 self = (class_1309) (Object) this;
		
		if (!self.method_6101())
		{
			return original;
		}
		
		final float width = ScaleUtils.getBoundingBoxWidthScale(self);
		
		if (width > 1.0F)
		{
			final class_238 bounds = self.method_5829();
			
			final double halfUnscaledXLength = (bounds.method_17939() / width) / 2.0D;
			final int minX = class_3532.method_15357(bounds.field_1323 + halfUnscaledXLength);
			final int maxX = class_3532.method_15357(bounds.field_1320 - halfUnscaledXLength);
			
			final int minY = class_3532.method_15357(bounds.field_1322);
			
			final double halfUnscaledZLength = (bounds.method_17941() / width) / 2.0D;
			final int minZ = class_3532.method_15357(bounds.field_1321 + halfUnscaledZLength);
			final int maxZ = class_3532.method_15357(bounds.field_1324 - halfUnscaledZLength);
			
			final class_1937 world = self.method_5770();
			
			for (final class_2338 pos : class_2338.method_10094(minX, minY, minZ, maxX, minY, maxZ))
			{
				if (((PehkuiBlockStateExtensions) world.method_8320(pos)).pehkui_getBlock() instanceof class_3736)
				{
					return new class_243(original.field_1352, Math.max(self.method_18798().field_1351, -0.15D), original.field_1350);
				}
			}
		}
		
		return original;
	}
	
	@WrapOperation(method = "tickCramming", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;getBoundingBox()Lnet/minecraft/util/math/Box;"))
	private class_238 pehkui$tickCramming$getBoundingBox(class_1309 obj, Operation<class_238> original)
	{
		final class_238 bounds = original.call(obj);
		
		final float interactionWidth = ScaleUtils.getInteractionBoxWidthScale(obj);
		final float interactionHeight = ScaleUtils.getInteractionBoxHeightScale(obj);
		
		if (interactionWidth != 1.0F || interactionHeight != 1.0F)
		{
			final double scaledXLength = bounds.method_17939() * 0.5D * (interactionWidth - 1.0F);
			final double scaledYLength = bounds.method_17940() * 0.5D * (interactionHeight - 1.0F);
			final double scaledZLength = bounds.method_17941() * 0.5D * (interactionWidth - 1.0F);
			
			return bounds.method_1009(scaledXLength, scaledYLength, scaledZLength);
		}
		
		return bounds;
	}
}
