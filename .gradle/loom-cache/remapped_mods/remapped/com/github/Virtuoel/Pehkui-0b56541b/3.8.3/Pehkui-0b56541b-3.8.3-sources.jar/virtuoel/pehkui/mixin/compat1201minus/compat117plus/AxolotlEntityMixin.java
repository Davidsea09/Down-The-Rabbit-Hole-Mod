package virtuoel.pehkui.mixin.compat1201minus.compat117plus;

import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1297;
import net.minecraft.class_5762;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_5762.class)
public class AxolotlEntityMixin
{
	@Dynamic
	@ModifyExpressionValue(method = MixinConstants.SQUARED_ATTACK_RANGE, at = @At(value = "CONSTANT", args = "doubleValue=1.5D"))
	private double pehkui$squaredAttackRange$range(double value)
	{
		final float scale = ScaleUtils.getBoundingBoxWidthScale((class_1297) (Object) this);
		
		if (scale != 1.0F)
		{
			return scale * scale * value;
		}
		
		return value;
	}
}
