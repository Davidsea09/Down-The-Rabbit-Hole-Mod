package virtuoel.pehkui.network;

import java.util.Collection;
import net.minecraft.class_1297;
import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import virtuoel.pehkui.Pehkui;
import virtuoel.pehkui.api.ScaleData;

public class ScalePayload extends ScalePacket implements class_8710
{
	public static final class_8710.class_9154<ScalePayload> ID = new class_8710.class_9154<>(Pehkui.SCALE_PACKET);
	public static final class_9139<class_2540, ScalePayload> CODEC = codec(ID);
	
	public ScalePayload(final class_1297 entity, final Collection<ScaleData> scales)
	{
		super(entity, scales);
	}
	
	public ScalePayload(final class_2540 buf)
	{
		super(buf);
	}
	
	@Override
	public class_8710.class_9154<? extends class_8710> method_56479()
	{
		return ID;
	}
	
	private static class_9139<class_2540, ScalePayload> codec(final class_8710.class_9154<ScalePayload> id)
	{
		return class_8710.method_56484(ScalePayload::write, ScalePayload::new);
	}
}
