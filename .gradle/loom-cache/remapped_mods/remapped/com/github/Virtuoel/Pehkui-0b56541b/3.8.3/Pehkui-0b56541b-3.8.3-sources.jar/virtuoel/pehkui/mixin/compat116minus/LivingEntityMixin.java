package virtuoel.pehkui.mixin.compat116minus;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin
{
	@ModifyExpressionValue(method = "damage(Lnet/minecraft/entity/damage/DamageSource;F)Z", at = @At(value = "CONSTANT", args = "floatValue=0.4F"))
	private float pehkui$damage$knockback(float value, class_1282 source, float amount)
	{
		final float scale = ScaleUtils.getKnockbackScale(source.method_5529());
		
		return scale != 1.0F ? scale * value : value;
	}
	
	@ModifyExpressionValue(method = "knockback(Lnet/minecraft/entity/LivingEntity;)V", at = @At(value = "CONSTANT", args = "floatValue=0.5F"))
	private float pehkui$knockback$knockback(float value, class_1309 target)
	{
		final float scale = ScaleUtils.getKnockbackScale((class_1297) (Object) this);
		
		return scale != 1.0F ? scale * value : value;
	}
}
