package virtuoel.pehkui.util;

import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.jetbrains.annotations.Nullable;

import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import net.fabricmc.api.EnvType;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.MappingResolver;
import net.minecraft.class_129;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_2540;
import net.minecraft.class_2724;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_634;
import net.minecraft.class_636;
import net.minecraft.class_761;
import virtuoel.pehkui.Pehkui;
import virtuoel.pehkui.api.PehkuiConfig;

public class ScaleRenderUtils
{
	public static final MethodHandles.Lookup LOOKUP;
	public static final MethodHandle DRAW_BOX_OUTLINE, SHOULD_KEEP_PLAYER_ATTRIBUTES, HAS_EXTENDED_REACH, GET_TICK_DELTA;
	public static final MethodType RECEIVE_TYPE, FACTORY_METHOD_TYPE;
	public static final Method REGISTER_GLOBAL_RECEIVER;
	public static final Class<?> PACKET_SENDER;
	
	static
	{
		final EnvType env = FabricLoader.getInstance().getEnvironmentType();
		
		final MappingResolver mappingResolver = FabricLoader.getInstance().getMappingResolver();
		final Int2ObjectMap<MethodHandle> handles = new Int2ObjectArrayMap<MethodHandle>();
		final Int2ObjectMap<MethodType> types = new Int2ObjectArrayMap<MethodType>();
		final Int2ObjectMap<Method> methods = new Int2ObjectArrayMap<Method>();
		final Class<?>[] classes = new Class<?>[1];
		
		final MethodHandles.Lookup lookup = LOOKUP = MethodHandles.lookup();
		String mapped = "unset";
		Method m;
		MethodType t;
		
		try
		{
			final boolean is114Minus = VersionUtils.MINOR <= 14;
			final boolean is116Plus = VersionUtils.MINOR >= 16;
			final boolean is1192Minus = VersionUtils.MINOR < 19 || (VersionUtils.MINOR == 19 && VersionUtils.PATCH <= 2);
			final boolean is1204Minus = VersionUtils.MINOR < 20 || (VersionUtils.MINOR == 20 && VersionUtils.PATCH <= 4);
			final boolean is1206Minus = VersionUtils.MINOR < 20 || (VersionUtils.MINOR == 20 && VersionUtils.PATCH <= 6);
			
			if (is114Minus && env == EnvType.CLIENT)
			{
				mapped = mappingResolver.mapMethodName("intermediary", "net.minecraft.class_761", "method_3260", "(Lnet/minecraft/class_238;FFFF)V");
				m = class_761.class.getMethod(mapped, class_238.class, float.class, float.class, float.class, float.class);
				handles.put(0, lookup.unreflect(m));
			}
			
			if (is116Plus && is1192Minus)
			{
				mapped = mappingResolver.mapMethodName("intermediary", "net.minecraft.class_2724", "method_27904", "()Z");
				m = class_2724.class.getMethod(mapped);
				handles.put(1, lookup.unreflect(m));
			}
			
			if (is1204Minus && env == EnvType.CLIENT)
			{
				if (ModLoaderUtils.isModLoaded("fabric-networking-api-v1"))
				{
					mapped = "net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking";
					final Class<?> networkingClass = Class.forName(mapped);
					
					mapped = "net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking$PlayChannelHandler";
					final Class<?> handlerClass = Class.forName(mapped);
					
					mapped = "net.fabricmc.fabric.api.networking.v1.PacketSender";
					classes[0] = Class.forName(mapped);
					
					m = networkingClass.getMethod("registerGlobalReceiver", class_2960.class, handlerClass);
					methods.put(2, m);
					
					m = handlerClass.getDeclaredMethod("receive", class_310.class, class_634.class, class_2540.class, classes[0]);
					t = MethodType.methodType(m.getReturnType(), m.getParameterTypes());
					types.put(3, t);
					
					t = MethodType.methodType(handlerClass);
					types.put(4, t);
				}
				
				mapped = mappingResolver.mapMethodName("intermediary", "net.minecraft.class_636", "method_2926", "()Z");
				m = class_636.class.getMethod(mapped);
				handles.put(5, lookup.unreflect(m));
			}
			
			if (is1206Minus && env == EnvType.CLIENT)
			{
				mapped = mappingResolver.mapMethodName("intermediary", "net.minecraft.class_310", "method_1488", "()F");
				m = class_310.class.getMethod(mapped);
				handles.put(6, lookup.unreflect(m));
			}
		}
		catch (NoSuchMethodException | SecurityException | IllegalAccessException | ClassNotFoundException e)
		{
			Pehkui.LOGGER.error("Current name lookup: {}", mapped);
			Pehkui.LOGGER.catching(e);
		}
		
		DRAW_BOX_OUTLINE = handles.get(0);
		SHOULD_KEEP_PLAYER_ATTRIBUTES = handles.get(1);
		REGISTER_GLOBAL_RECEIVER = methods.get(2);
		RECEIVE_TYPE = types.get(3);
		FACTORY_METHOD_TYPE = types.get(4);
		PACKET_SENDER = classes[0];
		HAS_EXTENDED_REACH = handles.get(5);
		GET_TICK_DELTA = handles.get(6);
	}
	
	public static void registerPacketHandler(class_2960 id, Class<?> clazz, String methodName)
	{
		if (REGISTER_GLOBAL_RECEIVER != null && RECEIVE_TYPE != null && FACTORY_METHOD_TYPE != null && PACKET_SENDER != null)
		{
			try
			{
				final Method staticRegister = clazz.getDeclaredMethod(methodName, class_310.class, class_634.class, class_2540.class, Object.class);
				final MethodHandle staticRegisterHandle = LOOKUP.unreflect(staticRegister);
				final MethodType staticRegisterType = staticRegisterHandle.type().changeParameterType(3, PACKET_SENDER);
				
				final CallSite lambdaFactory = LambdaMetafactory.metafactory(LOOKUP, "receive", FACTORY_METHOD_TYPE, RECEIVE_TYPE, staticRegisterHandle, staticRegisterType);
				final MethodHandle factoryInvoker = lambdaFactory.getTarget();
				
				final Object handlerLambda = factoryInvoker.asType(FACTORY_METHOD_TYPE).invokeWithArguments(Collections.emptyList());
				
				REGISTER_GLOBAL_RECEIVER.invoke(null, id, handlerLambda);
			}
			catch (Throwable e)
			{
				throw new RuntimeException(e);
			}
		}
	}
	
	public static float getTickDelta(final class_310 client)
	{
		if (GET_TICK_DELTA != null)
		{
			try
			{
				return (float) GET_TICK_DELTA.invoke(client);
			}
			catch (Throwable e)
			{
				throw new RuntimeException(e);
			}
		}
		
		return client.method_60646().method_60637(false);
	}
	
	public static boolean hasExtendedReach(final class_636 interactionManager)
	{
		if (HAS_EXTENDED_REACH != null)
		{
			try
			{
				return (boolean) HAS_EXTENDED_REACH.invoke(interactionManager);
			}
			catch (Throwable e)
			{
				throw new RuntimeException(e);
			}
		}
		
		return interactionManager.method_2920().method_8386();
	}
	
	public static boolean wasPlayerAlive(final class_2724 packet)
	{
		if (VersionUtils.MINOR < 19 || (VersionUtils.MINOR == 19 && VersionUtils.PATCH <= 2))
		{
			if (SHOULD_KEEP_PLAYER_ATTRIBUTES != null)
			{
				try
				{
					return (boolean) SHOULD_KEEP_PLAYER_ATTRIBUTES.invoke(packet);
				}
				catch (Throwable e)
				{
					throw new RuntimeException(e);
				}
			}
		}
		
		return packet.method_48016((byte) 1);
	}
	
	public static void renderInteractionBox(@Nullable final Object matrices, @Nullable final Object vertices, final class_238 box)
	{
		renderInteractionBox(matrices, vertices, box, 0.25F, 1.0F, 0.0F, 1.0F);
	}
	
	public static void renderInteractionBox(@Nullable final Object matrices, @Nullable final Object vertices, final class_238 box, final float red, final float green, final float blue, final float alpha)
	{
		if (VersionUtils.MINOR >= 15)
		{
			class_761.method_22982((class_4587) matrices, (class_4588) vertices, box, red, green, blue, alpha);
		}
		else if (DRAW_BOX_OUTLINE != null)
		{
			try
			{
				DRAW_BOX_OUTLINE.invoke(box, red, green, blue, alpha);
			}
			catch (Throwable e)
			{
				throw new RuntimeException(e);
			}
		}
	}
	
	public static final float modifyProjectionMatrixDepthByWidth(float depth, @Nullable class_1297 entity, float tickDelta)
	{
		return entity == null ? depth : modifyProjectionMatrixDepth(ScaleUtils.getBoundingBoxWidthScale(entity, tickDelta), depth, entity, tickDelta);
	}
	
	public static final float modifyProjectionMatrixDepthByHeight(float depth, @Nullable class_1297 entity, float tickDelta)
	{
		return entity == null ? depth : modifyProjectionMatrixDepth(ScaleUtils.getEyeHeightScale(entity, tickDelta), depth, entity, tickDelta);
	}
	
	public static final float modifyProjectionMatrixDepth(float depth, @Nullable class_1297 entity, float tickDelta)
	{
		return entity == null ? depth : modifyProjectionMatrixDepth(Math.min(ScaleUtils.getBoundingBoxWidthScale(entity, tickDelta), ScaleUtils.getEyeHeightScale(entity, tickDelta)), depth, entity, tickDelta);
	}
	
	public static final float modifyProjectionMatrixDepth(float scale, float depth, class_1297 entity, float tickDelta)
	{
		if (scale < 1.0F)
		{
			return Math.max(depth * scale, (float) PehkuiConfig.CLIENT.minimumCameraDepth.get().doubleValue());
		}
		
		return depth;
	}
	
	public static boolean shouldSkipHeadItemScaling(@Nullable class_1309 entity, class_1799 item, Object renderMode)
	{
		if ("HEAD".equals(((Enum<?>) renderMode).name()))
		{
			if (entity == null || (entity.method_6118(class_1304.field_6173) != item && entity.method_6118(class_1304.field_6171) != item))
			{
				return true;
			}
		}
		
		return false;
	}
	
	public static void logIfRenderCancelled()
	{
		logIfItemRenderCancelled(true);
		logIfEntityRenderCancelled(true);
	}
	
	private static final Set<class_1792> loggedItems = ConcurrentHashMap.newKeySet();
	private static class_1799 lastRenderedStack = null;
	private static int itemRecursionDepth = 0;
	private static int maxItemRecursionDepth = 2;
	
	public static void logIfItemRenderCancelled()
	{
		logIfItemRenderCancelled(false);
	}
	
	private static void logIfItemRenderCancelled(final boolean force)
	{
		if (lastRenderedStack != null && (force || itemRecursionDepth >= maxItemRecursionDepth))
		{
			final class_1792 i = lastRenderedStack.method_7909();
			if (force || !loggedItems.contains(i))
			{
				final String stackKey = lastRenderedStack.method_7922();
				final String itemKey = lastRenderedStack.method_7909().method_7876();
				if (stackKey.equals(itemKey))
				{
					Pehkui.LOGGER.error("[{}]: Did something cancel item rendering early? Matrix stack was not popped after rendering item {} ({}).", Pehkui.MOD_ID, stackKey, lastRenderedStack.method_7909());
				}
				else
				{
					Pehkui.LOGGER.error("[{}]: Did something cancel item rendering early? Matrix stack was not popped after rendering item {} ({}) ({})", Pehkui.MOD_ID, stackKey, itemKey, lastRenderedStack.method_7909());
				}
				
				loggedItems.add(i);
			}
		}
	}
	
	public static void saveLastRenderedItem(final class_1799 currentStack)
	{
		if (itemRecursionDepth == 0)
		{
			lastRenderedStack = currentStack;
		}
		
		itemRecursionDepth++;
	}
	
	public static void clearLastRenderedItem()
	{
		lastRenderedStack = null;
		itemRecursionDepth = 0;
	}
	
	private static final Set<class_1299<?>> loggedEntityTypes = ConcurrentHashMap.newKeySet();
	private static class_1299<?> lastRenderedEntity = null;
	private static int entityRecursionDepth = 0;
	private static int maxEntityRecursionDepth = 2;
	
	public static void logIfEntityRenderCancelled()
	{
		logIfEntityRenderCancelled(false);
	}
	
	private static void logIfEntityRenderCancelled(final boolean force)
	{
		if (lastRenderedEntity != null && (force || entityRecursionDepth >= maxEntityRecursionDepth))
		{
			if (force || !loggedEntityTypes.contains(lastRenderedEntity))
			{
				final class_2960 id = class_1299.method_5890(lastRenderedEntity);
				
				Pehkui.LOGGER.error("[{}]: Did something cancel entity rendering early? Matrix stack was not popped after rendering entity {}.", Pehkui.MOD_ID, id);
				
				loggedEntityTypes.add(lastRenderedEntity);
			}
		}
	}
	
	public static void saveLastRenderedEntity(final class_1299<?> type)
	{
		if (entityRecursionDepth == 0)
		{
			lastRenderedEntity = type;
		}
		
		entityRecursionDepth++;
	}
	
	public static void clearLastRenderedEntity()
	{
		lastRenderedEntity = null;
		entityRecursionDepth = 0;
	}
	
	public static void addDetailsToCrashReport(class_129 section)
	{
		if (lastRenderedStack != null)
		{
			section.method_578("pehkui:debug/render/item", lastRenderedStack.method_7909().method_7876());
		}
		
		if (lastRenderedEntity != null)
		{
			final class_2960 id = class_1299.method_5890(lastRenderedEntity);
			
			section.method_578("pehkui:debug/render/entity", id);
		}
	}
}
