package virtuoel.pehkui.mixin.client.compat1204minus.compat120plus;

import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_897;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleRenderUtils;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_897.class)
public abstract class EntityRendererMixin
{
	@Dynamic
	@WrapOperation(method = MixinConstants.RENDER_LABEL_IF_PRESENT, at = @At(value = "INVOKE", target = MixinConstants.GET_NAME_LABEL_HEIGHT))
	private float pehkui$renderLabelIfPresent$getNameLabelHeight(class_1297 entity, Operation<Float> original)
	{
		final float delta = ScaleRenderUtils.getTickDelta(class_310.method_1551());
		return (original.call(entity) - entity.method_17682()) + (entity.method_17682() / ScaleUtils.getBoundingBoxHeightScale(entity, delta));
	}
}
