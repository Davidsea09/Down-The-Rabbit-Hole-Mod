package virtuoel.pehkui.mixin.compat116plus;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1297;
import net.minecraft.class_1538;
import net.minecraft.class_1640;
import net.minecraft.class_1646;
import net.minecraft.class_3218;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1646.class)
public class VillagerEntityMixin
{
	@Inject(method = "onStruckByLightning(Lnet/minecraft/server/world/ServerWorld;Lnet/minecraft/entity/LightningEntity;)V", at = @At(value = "INVOKE", shift = Shift.BEFORE, target = "Lnet/minecraft/entity/mob/WitchEntity;refreshPositionAndAngles(DDDFF)V"))
	private void pehkui$onStruckByLightning(class_3218 world, class_1538 lightning, CallbackInfo info, @Local class_1640 witchEntity)
	{
		ScaleUtils.loadScale(witchEntity, (class_1297) (Object) this);
	}
}
