package virtuoel.pehkui.mixin.compat117plus;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.class_1606;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1606.class)
public class ShulkerEntityMixin
{
	@ModifyReturnValue(method = "calculateBoundingBox", at = @At("RETURN"))
	private class_238 pehkui$calculateBoundingBox(class_238 box)
	{
		final class_1606 entity = (class_1606) (Object) this;
		
		final float widthScale = ScaleUtils.getBoundingBoxWidthScale(entity);
		final float heightScale = ScaleUtils.getBoundingBoxHeightScale(entity);
		
		if (widthScale != 1.0F || heightScale != 1.0F)
		{
			final class_2350 facing = entity.method_7119().method_10153();
			
			final double xLength = box.method_17939() / -2.0D;
			final double yLength = box.method_17940() / -2.0D;
			final double zLength = box.method_17941() / -2.0D;
			
			final double dX = xLength * (1.0D - widthScale);
			final double dY = yLength * (1.0D - heightScale);
			final double dZ = zLength * (1.0D - widthScale);
			box = box.method_1009(dX, dY, dZ);
			box = box.method_989(dX * facing.method_10148(), dY * facing.method_10164(), dZ * facing.method_10165());
		}
		
		return box;
	}
}
