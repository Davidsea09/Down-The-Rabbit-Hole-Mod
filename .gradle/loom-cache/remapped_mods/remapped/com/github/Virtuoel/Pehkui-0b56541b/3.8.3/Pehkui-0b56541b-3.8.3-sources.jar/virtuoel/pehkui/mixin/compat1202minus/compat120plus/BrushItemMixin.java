package virtuoel.pehkui.mixin.compat1202minus.compat120plus;

import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_239;
import net.minecraft.class_8162;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_8162.class)
public class BrushItemMixin
{
	@Dynamic
	@WrapOperation(method = MixinConstants.GET_HIT_RESULT, at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/projectile/ProjectileUtil;getCollision(Lnet/minecraft/entity/Entity;Ljava/util/function/Predicate;D)Lnet/minecraft/util/hit/HitResult;"))
	private class_239 pehkui$getHitResult$getCollision(class_1297 entity, Predicate<class_1297> predicate, double range, Operation<class_239> original)
	{
		final float scale = ScaleUtils.getBlockReachScale(entity);
		
		return original.call(entity, predicate, scale != 1.0F ? range * scale : range);
	}
}
