package virtuoel.pehkui.mixin.compat115minus;

import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1297;
import net.minecraft.class_1641;
import net.minecraft.class_1646;
import net.minecraft.class_3218;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1641.class)
public class ZombieVillagerEntityMixin
{
	@Dynamic
	@Inject(method = MixinConstants.FINISH_CONVERSION, at = @At(value = "INVOKE", shift = Shift.BEFORE, target = MixinConstants.VILLAGER_COPY_POS_AND_ROT))
	private void pehkui$finishConversion(class_3218 world, CallbackInfo info, @Local class_1646 villagerEntity)
	{
		ScaleUtils.loadScale(villagerEntity, (class_1297) (Object) this);
	}
}
