package virtuoel.pehkui.mixin.compat1204minus;

import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.class_1606;
import net.minecraft.class_2350;
import net.minecraft.class_4048;
import net.minecraft.class_4050;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1606.class)
public class ShulkerEntityMixin
{
	@Dynamic
	@ModifyReturnValue(method = MixinConstants.GET_ACTIVE_EYE_HEIGHT, at = @At("RETURN"))
	private float pehkui$getActiveEyeHeight(float original, class_4050 pose, class_4048 dimensions)
	{
		final class_1606 entity = (class_1606) (Object) this;
		
		final class_2350 face = entity.method_7119();
		if (face != class_2350.field_11033)
		{
			final float scale = ScaleUtils.getEyeHeightScale(entity);
			if (scale != 1.0F)
			{
				if (face == class_2350.field_11036)
				{
					return ScaleUtils.divideClamped(1.0F, scale) - original;
				}
				else
				{
					return ScaleUtils.divideClamped(1.0F - original, scale);
				}
			}
		}
		
		return original;
	}
}
