package virtuoel.pehkui.mixin.compat1204minus;

import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_4048;
import net.minecraft.class_4050;
import virtuoel.pehkui.api.PehkuiConfig;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1309.class)
public class LivingEntityMixin
{
	@Dynamic
	@ModifyArg(method = MixinConstants.GET_EYE_HEIGHT, index = 1, at = @At(value = "INVOKE", target = MixinConstants.GET_ACTIVE_EYE_HEIGHT_TARGET))
	private class_4048 pehkui$getEyeHeight$dimensions(class_4048 dimensions)
	{
		return dimensions.method_18383(1.0F / ScaleUtils.getEyeHeightScale((class_1297) (Object) this));
	}
	
	@ModifyExpressionValue(method = "travel", at = @At(value = "CONSTANT", args = "floatValue=1.0F", ordinal = 0))
	private float pehkui$travel$fallDistance(float value)
	{
		final float scale = ScaleUtils.getFallingScale((class_1297) (Object) this);
		
		if (scale != 1.0F)
		{
			if (PehkuiConfig.COMMON.scaledFallDamage.get())
			{
				return value / scale;
			}
		}
		
		return value;
	}
	
	@Dynamic
	@ModifyReturnValue(method = MixinConstants.GET_EYE_HEIGHT, at = @At("RETURN"))
	private float pehkui$getEyeHeight(float original, class_4050 pose, class_4048 dimensions)
	{
		if (pose != class_4050.field_18078)
		{
			final float scale = ScaleUtils.getEyeHeightScale((class_1297) (Object) this);
			
			if (scale != 1.0F)
			{
				return original * scale;
			}
		}
		
		return original;
	}
	
	@ModifyReturnValue(method = "getJumpVelocity()F", at = @At("RETURN"))
	private float pehkui$getJumpVelocity(float original)
	{
		final float scale = ScaleUtils.getJumpHeightScale((class_1297) (Object) this);
		
		return scale != 1.0F ? original * scale : original;
	}
}
