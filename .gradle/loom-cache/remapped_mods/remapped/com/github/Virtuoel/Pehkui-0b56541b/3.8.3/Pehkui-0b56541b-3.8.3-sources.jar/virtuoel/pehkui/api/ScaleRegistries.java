package virtuoel.pehkui.api;

import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.DoubleBinaryOperator;
import java.util.function.Supplier;
import net.minecraft.class_2960;
import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import com.google.common.collect.Maps;

import it.unimi.dsi.fastutil.floats.Float2FloatFunction;
import virtuoel.pehkui.Pehkui;

public class ScaleRegistries
{
	private static final Map<Map<class_2960, ?>, class_2960> REGISTRY_IDS = new IdentityHashMap<>();
	private static final Map<class_2960, Supplier<?>> DEFAULT_ENTRIES = new LinkedHashMap<>();
	private static final Map<class_2960, class_2960> DEFAULT_IDS = new LinkedHashMap<>();
	
	public static final BiMap<class_2960, ScaleType> SCALE_TYPES = create("scale_types", "invalid", () -> ScaleTypes.INVALID);
	public static final BiMap<class_2960, ScaleModifier> SCALE_MODIFIERS = create("scale_modifiers", "identity", () -> ScaleModifiers.IDENTITY);
	public static final BiMap<class_2960, Float2FloatFunction> SCALE_EASINGS = create("scale_easings", "linear", () -> ScaleEasings.LINEAR);
	public static final BiMap<class_2960, DoubleBinaryOperator> SCALE_OPERATIONS = create("scale_operations", "noop", () -> ScaleOperations.NOOP);
	
	public static <E> E register(Map<class_2960, E> registry, class_2960 id, E entry)
	{
		return registry.computeIfAbsent(id, i -> entry);
	}
	
	public static <E> E getEntry(Map<class_2960, E> registry, class_2960 id)
	{
		return registry.get(id);
	}
	
	public static <E> class_2960 getDefaultId(BiMap<class_2960, E> registry)
	{
		return DEFAULT_IDS.get(REGISTRY_IDS.get(registry));
	}
	
	public static <E> class_2960 getId(BiMap<class_2960, E> registry, E entry)
	{
		return registry.inverse().get(entry);
	}
	
	private static <E> BiMap<class_2960, E> create(String id, String defaultPath, Supplier<E> defaultEntry)
	{
		return create(Pehkui.id(id), Pehkui.id(defaultPath), defaultEntry);
	}
	
	private static <E> BiMap<class_2960, E> create(class_2960 id, class_2960 defaultId, Supplier<E> defaultEntry)
	{
		final BiMap<class_2960, E> registry = Maps.synchronizedBiMap(HashBiMap.create());
		REGISTRY_IDS.put(registry, id);
		DEFAULT_IDS.put(id, defaultId);
		DEFAULT_ENTRIES.put(id, defaultEntry);
		return registry;
	}
	
	private ScaleRegistries()
	{
		
	}
}
