package virtuoel.pehkui.network;

import java.util.Collection;
import net.minecraft.class_2540;
import virtuoel.pehkui.util.ConfigSyncUtils;
import virtuoel.pehkui.util.ConfigSyncUtils.SyncableConfigEntry;

public class ConfigSyncPacket
{
	public Collection<SyncableConfigEntry<?>> configEntries;
	public Runnable action;
	
	public ConfigSyncPacket(final Collection<SyncableConfigEntry<?>> configEntries)
	{
		this.configEntries = configEntries;
	}
	
	public ConfigSyncPacket(final class_2540 buf)
	{
		this.action = ConfigSyncUtils.readConfigs(buf);
	}
	
	public void write(final class_2540 buf)
	{
		ConfigSyncUtils.write(configEntries, buf);
	}
}
