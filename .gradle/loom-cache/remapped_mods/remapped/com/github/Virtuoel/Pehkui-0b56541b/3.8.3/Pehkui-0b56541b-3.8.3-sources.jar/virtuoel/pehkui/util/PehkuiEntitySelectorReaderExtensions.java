package virtuoel.pehkui.util;

import net.minecraft.class_2096;
import virtuoel.pehkui.api.ScaleType;

public interface PehkuiEntitySelectorReaderExtensions
{
	ScaleType pehkui_getScaleType();
	void pehkui_setScaleType(final ScaleType scaleType);
	
	class_2096<? extends Number> pehkui_getScaleRange();
	void pehkui_setScaleRange(final class_2096.class_2099 baseScaleRange);
	
	ScaleType pehkui_getComputedScaleType();
	void pehkui_setComputedScaleType(final ScaleType computedScaleType);
	
	class_2096<? extends Number> pehkui_getComputedScaleRange();
	void pehkui_setComputedScaleRange(final class_2096.class_2099 computedScaleRange);
}
