package virtuoel.pehkui.mixin.compat117plus;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_4048;
import virtuoel.pehkui.util.ReflectionUtils;

@Mixin(class_1297.class)
public abstract class EntityCalculateDimensionsMixin
{
	@Inject(method = "calculateDimensions", at = @At(value = "INVOKE", shift = Shift.AFTER, target = "Lnet/minecraft/entity/Entity;refreshPosition()V"))
	private void pehkui$calculateDimensions(CallbackInfo info, @Local(ordinal = 0) class_4048 previous, @Local(ordinal = 1) class_4048 current)
	{
		final class_1297 self = (class_1297) (Object) this;
		final class_1937 world = self.method_5770();
		
		final float currentWidth = ReflectionUtils.getDimensionsWidth(current);
		final float previousWidth = ReflectionUtils.getDimensionsWidth(previous);
		if (world.field_9236 && self.method_5864() == class_1299.field_6097 && currentWidth > previousWidth)
		{
			final double prevW = Math.min(previousWidth, 4.0D);
			final double prevH = Math.min(ReflectionUtils.getDimensionsHeight(previous), 4.0D);
			final double currW = Math.min(currentWidth, 4.0D);
			final double currH = Math.min(ReflectionUtils.getDimensionsHeight(current), 4.0D);
			final class_243 lastCenter = self.method_19538().method_1031(0.0D, prevH / 2.0D, 0.0D);
			final double w = Math.max(0.0F, currW - prevW) + 1.0E-6D;
			final double h = Math.max(0.0F, currH - prevH) + 1.0E-6D;
			final class_265 voxelShape = class_259.method_1078(class_238.method_30048(lastCenter, w, h, w));
			world.method_33594(self, voxelShape, lastCenter, currW, currH, currW)
				.ifPresent(vec -> self.method_33574(vec.method_1031(0.0D, -currH / 2.0D, 0.0D)));
		}
	}
}
