package virtuoel.pehkui.mixin.compat116minus;

import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1297;
import net.minecraft.class_1621;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1621.class)
public class SlimeEntityMixin
{
	@Dynamic
	@ModifyArg(method = MixinConstants.REMOVE, at = @At(value = "INVOKE", target = MixinConstants.SPAWN_ENTITY))
	private class_1297 pehkui$remove$spawnEntity(class_1297 entity)
	{
		ScaleUtils.loadScale(entity, (class_1297) (Object) this);
		
		return entity;
	}
	
	@Dynamic
	@ModifyExpressionValue(method = MixinConstants.REMOVE, at = @At(value = "CONSTANT", args = "floatValue=4.0F"))
	private float pehkui$remove$horizontalOffset(float value)
	{
		final float scale = ScaleUtils.getBoundingBoxWidthScale((class_1297) (Object) this);
		
		if (scale != 1.0F)
		{
			return value / scale;
		}
		
		return value;
	}
	
	@Dynamic
	@ModifyExpressionValue(method = MixinConstants.REMOVE, at = @At(value = "CONSTANT", args = "doubleValue=0.5D"))
	private double pehkui$remove$verticalOffset(double value)
	{
		final float scale = ScaleUtils.getBoundingBoxHeightScale((class_1297) (Object) this);
		
		if (scale != 1.0F)
		{
			return value * scale;
		}
		
		return value;
	}
}
