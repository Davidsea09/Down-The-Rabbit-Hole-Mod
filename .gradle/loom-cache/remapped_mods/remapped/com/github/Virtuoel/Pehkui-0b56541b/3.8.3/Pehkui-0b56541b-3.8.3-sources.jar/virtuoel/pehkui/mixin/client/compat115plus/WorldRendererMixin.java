package virtuoel.pehkui.mixin.client.compat115plus;

import net.minecraft.class_4587;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import virtuoel.pehkui.util.ScaleRenderUtils;

@Mixin(class_761.class)
public class WorldRendererMixin
{
	@Inject(method = "checkEmpty", at = @At(value = "HEAD"))
	private void pehkui$checkEmpty(class_4587 matrices, CallbackInfo info)
	{
		if (!matrices.method_22911())
		{
			ScaleRenderUtils.logIfRenderCancelled();
		}
	}
}
