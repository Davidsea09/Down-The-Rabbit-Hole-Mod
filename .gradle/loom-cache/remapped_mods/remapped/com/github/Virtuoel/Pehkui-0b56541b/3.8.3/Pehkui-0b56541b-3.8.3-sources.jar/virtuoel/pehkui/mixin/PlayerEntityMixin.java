package virtuoel.pehkui.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_243;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1657.class)
public abstract class PlayerEntityMixin
{
	@Inject(at = @At("RETURN"), method = "dropItem(Lnet/minecraft/item/ItemStack;ZZ)Lnet/minecraft/entity/ItemEntity;")
	private void pehkui$dropItem(class_1799 stack, boolean spread, boolean thrown, CallbackInfoReturnable<class_1542> info)
	{
		final class_1542 entity = info.getReturnValue();
		
		if (entity != null)
		{
			ScaleUtils.setScaleOfDrop(entity, (class_1297) (Object) this);
			
			final float scale = ScaleUtils.getEyeHeightScale((class_1297) (Object) this);
			
			if (scale != 1.0F)
			{
				final class_243 pos = entity.method_19538();
				
				entity.method_5814(pos.field_1352, pos.field_1351 + ((1.0F - scale) * 0.3D), pos.field_1350);
			}
		}
	}
	
	@WrapOperation(method = "tickMovement()V", at = @At(value = "INVOKE", ordinal = 1, target = "Lnet/minecraft/util/math/Box;expand(DDD)Lnet/minecraft/util/math/Box;"))
	private class_238 pehkui$tickMovement$expand(class_238 obj, double x, double y, double z, Operation<class_238> original)
	{
		final float widthScale = ScaleUtils.getBoundingBoxWidthScale((class_1297) (Object) this);
		final float heightScale = ScaleUtils.getBoundingBoxHeightScale((class_1297) (Object) this);
		
		if (widthScale != 1.0F)
		{
			x *= widthScale;
			z *= widthScale;
		}
		
		if (heightScale != 1.0F)
		{
			y *= heightScale;
		}
		
		return original.call(obj, x, y, z);
	}
	
	@ModifyExpressionValue(method = "attack(Lnet/minecraft/entity/Entity;)V", at = { @At(value = "CONSTANT", args = "floatValue=0.5F", ordinal = 1), @At(value = "CONSTANT", args = "floatValue=0.5F", ordinal = 2), @At(value = "CONSTANT", args = "floatValue=0.5F", ordinal = 3) })
	private float pehkui$attack$knockback(float value)
	{
		final float scale = ScaleUtils.getKnockbackScale((class_1297) (Object) this);
		
		return scale != 1.0F ? scale * value : value;
	}
	
	@ModifyExpressionValue(method = "getAttackCooldownProgressPerTick", at = @At(value = "CONSTANT", args = "doubleValue=20.0D"))
	private double pehkui$getAttackCooldownProgressPerTick$multiplier(double value)
	{
		final float scale = ScaleUtils.getAttackSpeedScale((class_1297) (Object) this);
		
		return scale != 1.0F ? value / scale : value;
	}
	
	@ModifyReturnValue(method = "getBlockBreakingSpeed", at = @At("RETURN"))
	private float pehkui$getBlockBreakingSpeed(float original)
	{
		final float scale = ScaleUtils.getMiningSpeedScale((class_1297) (Object) this);
		
		return scale != 1.0F ? original * scale : original;
	}
	
	@ModifyExpressionValue(method = "updateCapeAngles", at = { @At(value = "CONSTANT", args = "doubleValue=10.0D"), @At(value = "CONSTANT", args = "doubleValue=-10.0D") })
	private double pehkui$updateCapeAngles$limits(double value)
	{
		final float scale = ScaleUtils.getMotionScale((class_1297) (Object) this);
		
		return scale != 1.0F ? scale * value : value;
	}
	
	@WrapOperation(method = "attack(Lnet/minecraft/entity/Entity;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/math/Box;expand(DDD)Lnet/minecraft/util/math/Box;"))
	private class_238 pehkui$attack$expand(class_238 obj, double x, double y, double z, Operation<class_238> original, @Local(argsOnly = true) class_1297 target)
	{
		final float widthScale = ScaleUtils.getBoundingBoxWidthScale(target);
		final float heightScale = ScaleUtils.getBoundingBoxHeightScale(target);
		
		if (widthScale != 1.0F)
		{
			x *= widthScale;
			z *= widthScale;
		}
		
		if (heightScale != 1.0F)
		{
			y *= heightScale;
		}
		
		return original.call(obj, x, y, z);
	}
}
