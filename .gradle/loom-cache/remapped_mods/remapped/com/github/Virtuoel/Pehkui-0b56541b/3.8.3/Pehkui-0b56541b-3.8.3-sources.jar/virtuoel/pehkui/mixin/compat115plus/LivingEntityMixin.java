package virtuoel.pehkui.mixin.compat115plus;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin
{
	@ModifyArg(method = "onKilledBy", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/World;spawnEntity(Lnet/minecraft/entity/Entity;)Z"))
	private class_1297 pehkui$onKilledBy$spawnEntity(class_1297 entity)
	{
		ScaleUtils.setScaleOfDrop(entity, (class_1297) (Object) this);
		
		return entity;
	}
}
