package virtuoel.pehkui.mixin.reach.compat1204minus.compat116plus;

import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1792.class)
public class ItemMixin
{
	@ModifyVariable(method = "raycast", ordinal = 1, at = @At(value = "STORE"))
	private static class_243 pehkui$raycast$end(class_243 value, class_1937 world, class_1657 player, class_3959.class_242 fluidHandling)
	{
		final float scale = ScaleUtils.getBlockReachScale(player);
		
		if (scale != 1.0F)
		{
			final class_243 eyePos = ScaleUtils.getEyePos(player);
			final class_243 distance = value.method_1020(eyePos);
			
			return eyePos.method_1019(distance.method_1021(scale));
		}
		
		return value;
	}
}
