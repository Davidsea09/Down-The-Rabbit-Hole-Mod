package virtuoel.pehkui.mixin.compat116plus;

import net.minecraft.class_1297;
import net.minecraft.class_1681;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1681.class)
public class EggEntityMixin
{
	@ModifyArg(method = "onCollision(Lnet/minecraft/util/hit/HitResult;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/World;spawnEntity(Lnet/minecraft/entity/Entity;)Z"))
	private class_1297 pehkui$onCollision$entity(class_1297 entity)
	{
		ScaleUtils.loadScale(entity, (class_1297) (Object) this);
		
		return entity;
	}
}
