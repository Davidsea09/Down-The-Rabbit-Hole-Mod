package virtuoel.pehkui.mixin.compat116minus;

import net.minecraft.class_1657;
import net.minecraft.class_3719;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;
import virtuoel.pehkui.util.ViewerCountingBlockEntityExtensions;

@Mixin(class_3719.class)
public class BarrelBlockEntityMixin implements ViewerCountingBlockEntityExtensions
{
	@Dynamic @Shadow
	int field_17583; // UNMAPPED_FIELD
	
	@Unique
	float viewerSearchRange = 5.0F;
	
	@Override
	public float pehkui_getViewerSearchRange()
	{
		return viewerSearchRange;
	}
	
	@Dynamic
	@Inject(at = @At("HEAD"), method = MixinConstants.ON_OPEN)
	private void pehkui$onOpen(class_1657 player, CallbackInfo info)
	{
		if (field_17583 < 0)
		{
			field_17583 = 0;
			
			viewerSearchRange = 5.0F;
		}
		
		final float scale = ScaleUtils.getBlockReachScale(player);
		
		if (scale != 1.0F)
		{
			final float nextRange = 5.0F * scale;
			
			if (nextRange > viewerSearchRange)
			{
				viewerSearchRange = nextRange;
			}
		}
	}
	
	@Dynamic
	@Inject(at = @At("HEAD"), method = MixinConstants.ON_CLOSE)
	private void pehkui$onClose(class_1657 player, CallbackInfo info)
	{
		if (field_17583 <= 1)
		{
			field_17583 = 1;
			
			viewerSearchRange = 5.0F;
		}
	}
}
