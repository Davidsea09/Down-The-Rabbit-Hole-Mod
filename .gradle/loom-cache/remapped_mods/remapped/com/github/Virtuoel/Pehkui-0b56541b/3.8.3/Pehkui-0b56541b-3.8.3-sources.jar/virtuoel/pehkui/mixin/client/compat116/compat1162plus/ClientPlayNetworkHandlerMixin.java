package virtuoel.pehkui.mixin.client.compat116.compat1162plus;

import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_2724;
import net.minecraft.class_634;
import net.minecraft.class_746;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleRenderUtils;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_634.class)
public class ClientPlayNetworkHandlerMixin
{
	@Dynamic
	@Inject(method = MixinConstants.ON_PLAYER_RESPAWN, at = @At(value = "INVOKE", target = MixinConstants.AFTER_SPAWN))
	private void pehkui$onPlayerRespawn(class_2724 packet, CallbackInfo info, @Local(ordinal = 0) class_746 oldPlayer, @Local(ordinal = 1) class_746 newPlayer)
	{
		ScaleUtils.loadScaleOnRespawn(newPlayer, oldPlayer, ScaleRenderUtils.wasPlayerAlive(packet));
	}
}
