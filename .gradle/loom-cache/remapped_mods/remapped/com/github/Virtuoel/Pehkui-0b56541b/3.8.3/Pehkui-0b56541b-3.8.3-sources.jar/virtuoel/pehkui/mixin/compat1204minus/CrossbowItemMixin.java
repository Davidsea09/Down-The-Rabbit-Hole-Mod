package virtuoel.pehkui.mixin.compat1204minus;

import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1764;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1764.class)
public class CrossbowItemMixin
{
	@Dynamic
	@ModifyExpressionValue(method = MixinConstants.SHOOT, at = @At(value = "CONSTANT", args = "doubleValue=0.15000000596046448D"))
	private static double pehkui$shoot$yOffset(double value, class_1937 world, class_1309 shooter, class_1268 hand, class_1799 crossbow, class_1799 projectile, float soundPitch, boolean creative, float speed, float divergence, float simulated)
	{
		final float scale = ScaleUtils.getEyeHeightScale(shooter);
		
		return scale != 1.0F ? value * scale : value;
	}
}
