package virtuoel.pehkui.mixin.compat115minus;

import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1297;
import net.minecraft.class_1428;
import net.minecraft.class_1681;
import net.minecraft.class_239;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1681.class)
public class EggEntityMixin
{
	@Dynamic
	@Inject(method = MixinConstants.ON_COLLISION, at = @At(value = "INVOKE", shift = Shift.BEFORE, target = MixinConstants.SPAWN_ENTITY))
	private void pehkui$onCollision(class_239 hitResult, CallbackInfo info, @Local class_1428 chickenEntity)
	{
		ScaleUtils.loadScale(chickenEntity, (class_1297) (Object) this);
	}
}
