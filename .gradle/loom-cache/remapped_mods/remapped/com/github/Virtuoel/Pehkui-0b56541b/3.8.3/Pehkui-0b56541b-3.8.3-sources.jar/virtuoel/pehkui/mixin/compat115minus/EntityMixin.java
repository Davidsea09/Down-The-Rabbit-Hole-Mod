package virtuoel.pehkui.mixin.compat115minus;

import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1297.class)
public abstract class EntityMixin
{
	@Dynamic @Shadow
	private double field_5987; // UNMAPPED_FIELD
	@Dynamic @Shadow
	private double field_6010; // UNMAPPED_FIELD
	@Dynamic @Shadow
	private double field_6035; // UNMAPPED_FIELD
	@Dynamic @Shadow
	abstract class_243 method_5812(); // UNMAPPED_METHOD
	
	@Unique
	protected void setPosDirectly(final double x, final double y, final double z)
	{
		field_5987 = x;
		field_6010 = y;
		field_6035 = z;
	}
	
	@ModifyExpressionValue(method = "isInsideWall()Z", at = @At(value = "CONSTANT", args = "floatValue=0.1F"))
	private float pehkui$isInsideWall$offset(float value)
	{
		final float scale = ScaleUtils.getEyeHeightScale((class_1297) (Object) this);
		
		return scale != 1.0F ? value * scale : value;
	}
}
