package virtuoel.pehkui.mixin.compat120plus;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1297;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1297.class)
public class EntityMixin
{
	@ModifyExpressionValue(method = "updateSupportingBlockPos", at = @At(value = "CONSTANT", args = "doubleValue=1.0E-6"))
	private double pehkui$updateSupportingBlockPos$offset(double value)
	{
		final float scale = ScaleUtils.getMotionScale((class_1297) (Object) this);
		
		return scale < 1.0F ? value * scale : value;
	}
}
