package virtuoel.pehkui.mixin.client.compat114;

import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_898;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleRenderUtils;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_898.class)
public class EntityRenderDispatcherMixin
{
	@Dynamic
	@Inject(method = MixinConstants.RENDER, at = @At(value = "INVOKE", shift = Shift.BEFORE, target = MixinConstants.RENDER_IN_WORLD))
	private <E extends class_1297> void pehkui$render$before(E entity, double x, double y, double z, float yaw, float tickDelta, boolean forceHideHitbox, CallbackInfo info)
	{
		ScaleRenderUtils.logIfEntityRenderCancelled();
		
		final float widthScale = ScaleUtils.getModelWidthScale(entity, tickDelta);
		final float heightScale = ScaleUtils.getModelHeightScale(entity, tickDelta);
		
		GL11.glPushMatrix();
		GL11.glScalef(widthScale, heightScale, widthScale);
		GL11.glTranslated((x / widthScale) - x, (y / heightScale) - y, (z / widthScale) - z);
		GL11.glPushMatrix();
		
		ScaleRenderUtils.saveLastRenderedEntity(entity.method_5864());
	}
	
	@Dynamic
	@Inject(method = MixinConstants.RENDER, at = @At(value = "INVOKE", shift = Shift.AFTER, target = MixinConstants.RENDER_IN_WORLD))
	private <E extends class_1297> void pehkui$render$after(E entity, double x, double y, double z, float yaw, float tickDelta, boolean forceHideHitbox, CallbackInfo info)
	{
		ScaleRenderUtils.clearLastRenderedEntity();
		
		GL11.glPopMatrix();
		GL11.glPopMatrix();
	}
	
	@Dynamic
	@Inject(method = MixinConstants.RENDER_HITBOX, at = @At(value = "INVOKE", target = MixinConstants.TESSELATOR_GET_INSTANCE))
	private void pehkui$renderHitbox(class_1297 entity, double d, double e, double f, float g, float h, CallbackInfo ci)
	{
		final float interactionWidth = ScaleUtils.getInteractionBoxWidthScale(entity);
		final float interactionHeight = ScaleUtils.getInteractionBoxHeightScale(entity);
		final float margin = entity.method_5871();
		
		if (interactionWidth != 1.0F || interactionHeight != 1.0F || margin != 0.0F)
		{
			class_238 bounds = entity.method_5829();
			
			final double scaledXLength = bounds.method_17939() * 0.5D * (interactionWidth - 1.0F);
			final double scaledYLength = bounds.method_17940() * 0.5D * (interactionHeight - 1.0F);
			final double scaledZLength = bounds.method_17941() * 0.5D * (interactionWidth - 1.0F);
			final double scaledMarginWidth = margin * interactionWidth;
			final double scaledMarginHeight = margin * interactionHeight;
			
			final class_243 pos = entity.method_19538();
			bounds = bounds.method_1009(scaledXLength + scaledMarginWidth, scaledYLength + scaledMarginHeight, scaledZLength + scaledMarginWidth)
				.method_989(-pos.field_1352 + d, -pos.field_1351 + e, -pos.field_1350 + f);
			
			ScaleRenderUtils.renderInteractionBox(null, null, bounds);
		}
	}
}
