package virtuoel.pehkui.mixin.identity.compat;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import virtuoel.pehkui.api.ScaleData;
import virtuoel.pehkui.api.ScaleType;
import virtuoel.pehkui.util.CombinedScaleData;
import virtuoel.pehkui.util.IdentityCompatibility;
import virtuoel.pehkui.util.PehkuiEntityExtensions;

@Mixin(class_1657.class)
public abstract class PlayerEntityMixin implements PehkuiEntityExtensions
{
	@Unique
	private static final ScaleData[] pehkui$EMPTY = {};
	
	@Override
	public ScaleData pehkui_constructScaleData(ScaleType type)
	{
		return new CombinedScaleData(type, (class_1297) (Object) this, () ->
		{
			final class_1309 identity = IdentityCompatibility.INSTANCE.getIdentity((class_1657) (Object) this);
			
			return identity == null ? pehkui$EMPTY : new ScaleData[] { type.getScaleData(identity) };
		});
	}
}
