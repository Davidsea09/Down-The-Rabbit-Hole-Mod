package virtuoel.pehkui.mixin.compat1206minus;

import net.minecraft.class_1530;
import net.minecraft.class_1533;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1533.class)
public abstract class ItemFrameEntityMixin
{
	@Dynamic
	@ModifyArg(method = MixinConstants.UPDATE_ATTACHMENT_POSITION, at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/decoration/ItemFrameEntity;setBoundingBox(Lnet/minecraft/util/math/Box;)V"))
	private class_238 pehkui$updateAttachment$box(class_238 box)
	{
		final class_1530 entity = (class_1530) (Object) this;
		
		final class_2350 facing = entity.method_5735();
		
		final double xLength = box.method_17939() / -2.0D;
		final double yLength = box.method_17940() / -2.0D;
		final double zLength = box.method_17941() / -2.0D;
		
		final float widthScale = ScaleUtils.getBoundingBoxWidthScale(entity);
		final float heightScale = ScaleUtils.getBoundingBoxHeightScale(entity);
		
		if (widthScale != 1.0F || heightScale != 1.0F)
		{
			final double dX = xLength * (1.0D - widthScale);
			final double dY = yLength * (1.0D - heightScale);
			final double dZ = zLength * (1.0D - widthScale);
			box = box.method_1009(dX, dY, dZ);
			box = box.method_989(dX * facing.method_10148(), dY * facing.method_10164(), dZ * facing.method_10165());
		}
		
		return box;
	}
}
