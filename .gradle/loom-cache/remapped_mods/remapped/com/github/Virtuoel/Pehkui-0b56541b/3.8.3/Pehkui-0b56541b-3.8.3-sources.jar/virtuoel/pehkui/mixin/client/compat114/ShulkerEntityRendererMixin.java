package virtuoel.pehkui.mixin.client.compat114;

import net.minecraft.class_1309;
import net.minecraft.class_1606;
import net.minecraft.class_2350;
import net.minecraft.class_943;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_943.class)
public class ShulkerEntityRendererMixin
{
	@Dynamic
	@Inject(at = @At("RETURN"), method = MixinConstants.SETUP_TRANSFORMS)
	private void pehkui$setupTransforms(class_1309 entity, float animationProgress, float bodyYaw, float tickDelta, CallbackInfo info)
	{
		final class_2350 face = entity instanceof class_1606 ? ((class_1606) entity).method_7119() : class_2350.field_11033;
		
		if (face != class_2350.field_11033)
		{
			final float h = ScaleUtils.getModelHeightScale(entity, tickDelta);
			if (face != class_2350.field_11036)
			{
				final float w = ScaleUtils.getModelWidthScale(entity, tickDelta);
				if (w != 1.0F || h != 1.0F)
				{
					GL11.glTranslated(0.0, -((1.0F - w) * 0.5F) / w, -((1.0F - h) * 0.5F) / h);
				}
			}
			else if (h != 1.0F)
			{
				GL11.glTranslated(0.0, -(1.0F - h) / h, 0.0);
			}
		}
	}
}
