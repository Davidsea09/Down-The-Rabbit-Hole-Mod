package virtuoel.pehkui.mixin.compat1193minus;

import net.minecraft.class_1657;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import virtuoel.pehkui.util.ReflectionUtils;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1657.class)
public abstract class PlayerEntityMixin
{
	@Inject(method = "travel(Lnet/minecraft/util/math/Vec3d;)V", at = @At(value = "INVOKE", ordinal = 0, shift = Shift.BEFORE, target = "Lnet/minecraft/entity/LivingEntity;travel(Lnet/minecraft/util/math/Vec3d;)V"))
	private void pehkui$travel$flightSpeed(class_243 movementInput, CallbackInfo info)
	{
		final class_1657 self = (class_1657) (Object) this;
		final float scale = ScaleUtils.getFlightScale(self);
		
		if (scale != 1.0F)
		{
			ReflectionUtils.setFlyingSpeed(self, ReflectionUtils.getFlyingSpeed(self) * scale);
		}
	}
}
