package virtuoel.pehkui.mixin.client.compat1193minus.compat117plus;

import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_918;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleRenderUtils;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(value = class_918.class, priority = 1010)
public class ItemRendererMixin
{
	@Dynamic
	@Inject(method = MixinConstants.RENDER_ITEM_WITH_SEED, at = @At(value = "HEAD"))
	private void pehkui$renderItem$head(@Nullable class_1309 entity, class_1799 item, @Coerce Object renderMode, boolean leftHanded, class_4587 matrices, class_4597 vertexConsumers, @Nullable class_1937 world, int light, int overlay, int seed, CallbackInfo info)
	{
		if (ScaleRenderUtils.shouldSkipHeadItemScaling(entity, item, renderMode))
		{
			return;
		}
		
		ScaleRenderUtils.logIfItemRenderCancelled();
		
		matrices.method_22903();
		
		if (!item.method_7960() && entity != null)
		{
			final float tickDelta = ScaleRenderUtils.getTickDelta(class_310.method_1551());
			final float scale = ScaleUtils.getHeldItemScale(entity, tickDelta);
			
			if (scale != 1.0F)
			{
				matrices.method_22905(scale, scale, scale);
			}
		}
		
		matrices.method_22903();
		
		ScaleRenderUtils.saveLastRenderedItem(item);
	}
	
	@Dynamic
	@Inject(method = MixinConstants.RENDER_ITEM_WITH_SEED, at = @At(value = "RETURN"))
	private void pehkui$renderItem$return(@Nullable class_1309 entity, class_1799 item, @Coerce Object renderMode, boolean leftHanded, class_4587 matrices, class_4597 vertexConsumers, @Nullable class_1937 world, int light, int overlay, int seed, CallbackInfo info)
	{
		if (ScaleRenderUtils.shouldSkipHeadItemScaling(entity, item, renderMode))
		{
			return;
		}
		
		ScaleRenderUtils.clearLastRenderedItem();
		
		matrices.method_22909();
		matrices.method_22909();
	}
}
