package virtuoel.pehkui.mixin.compat1204minus.compat116plus;

import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_4861;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_4861.class)
public class ForgingScreenHandlerMixin
{
	@Dynamic
	@ModifyExpressionValue(method = "method_24924", at = @At(value = "CONSTANT", args = "doubleValue=0.5D", ordinal = 0))
	private double pehkui$canUse$xOffset(double value, class_1657 player, class_1937 world, class_2338 pos)
	{
		return ScaleUtils.getBlockXOffset(pos, player);
	}
	
	@Dynamic
	@ModifyExpressionValue(method = "method_24924", at = @At(value = "CONSTANT", args = "doubleValue=0.5D", ordinal = 1))
	private double pehkui$canUse$yOffset(double value, class_1657 player, class_1937 world, class_2338 pos)
	{
		return ScaleUtils.getBlockYOffset(pos, player);
	}
	
	@Dynamic
	@ModifyExpressionValue(method = "method_24924", at = @At(value = "CONSTANT", args = "doubleValue=0.5D", ordinal = 2))
	private double pehkui$canUse$zOffset(double value, class_1657 player, class_1937 world, class_2338 pos)
	{
		return ScaleUtils.getBlockZOffset(pos, player);
	}
}
