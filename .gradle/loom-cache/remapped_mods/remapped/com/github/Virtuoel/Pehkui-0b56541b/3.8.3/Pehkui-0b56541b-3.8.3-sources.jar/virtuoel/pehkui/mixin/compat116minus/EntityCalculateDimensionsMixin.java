package virtuoel.pehkui.mixin.compat116minus;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1313;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_4048;
import virtuoel.pehkui.util.ReflectionUtils;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1297.class)
public abstract class EntityCalculateDimensionsMixin
{
	@Shadow class_1937 world;
	@Shadow @Final @Mutable class_1299<?> type;
	@Shadow abstract void move(class_1313 type, class_243 movement);
	
	@Inject(method = "calculateDimensions", at = @At(value = "INVOKE", shift = Shift.AFTER, ordinal = 1, target = "Lnet/minecraft/entity/Entity;setBoundingBox(Lnet/minecraft/util/math/Box;)V"))
	private void pehkui$calculateDimensions(CallbackInfo info, @Local(ordinal = 0) class_4048 previous, @Local(ordinal = 1) class_4048 current)
	{
		final float currentWidth = ReflectionUtils.getDimensionsWidth(current);
		final float previousWidth = ReflectionUtils.getDimensionsWidth(previous);
		if (this.world.field_9236 && type == class_1299.field_6097 && currentWidth > previousWidth)
		{
			final float scale = ScaleUtils.getBoundingBoxWidthScale((class_1297) (Object) this);
			final float dist = (previousWidth - currentWidth) / 2.0F;
			
			move(class_1313.field_6308, new class_243(dist / scale, 0.0D, dist / scale));
		}
	}
	
	@ModifyVariable(method = "calculateDimensions", at = @At("STORE"))
	private float pehkui$calculateDimensions$vector(float value)
	{
		final float scale = ScaleUtils.getBoundingBoxWidthScale((class_1297) (Object) this);
		
		return (scale != 1.0F ? value / scale : value) / 2.0F;
	}
}
