package virtuoel.pehkui.mixin.compat1201minus.compat1193plus;

import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1297;
import net.minecraft.class_7689;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_7689.class)
public class CamelEntityMixin
{
	@Dynamic
	@ModifyExpressionValue(method = MixinConstants.GET_MOUNTED_HEIGHT_OFFSET, at = @At(value = "CONSTANT", args = "floatValue=0.6F"))
	private float pehkui$getMountedHeightOffset$adultOffset(float value)
	{
		final float scale = ScaleUtils.getBoundingBoxHeightScale((class_1297) (Object) this);
		
		return scale != 1.0F ? scale * value : value;
	}
	
	@Dynamic
	@ModifyExpressionValue(method = MixinConstants.GET_MOUNTED_HEIGHT_OFFSET, at = @At(value = "CONSTANT", args = "floatValue=0.35F"))
	private float pehkui$getMountedHeightOffset$babyOffset(float value)
	{
		final float scale = ScaleUtils.getBoundingBoxHeightScale((class_1297) (Object) this);
		
		return scale != 1.0F ? scale * value : value;
	}
	
	@Dynamic
	@ModifyExpressionValue(method = MixinConstants.GET_PASSENGER_ATTACHMENT_Y, at = @At(value = "CONSTANT", args = "floatValue=0.5F"))
	private float pehkui$camelMountedHeightOffset$sittingFrontOffset(float value)
	{
		final float scale = ScaleUtils.getBoundingBoxHeightScale((class_1297) (Object) this);
		
		return scale != 1.0F ? scale * value : value;
	}
	
	@Dynamic
	@ModifyExpressionValue(method = MixinConstants.GET_PASSENGER_ATTACHMENT_Y, at = @At(value = "CONSTANT", args = "floatValue=0.1F"))
	private float pehkui$camelMountedHeightOffset$sittingBackOffset(float value)
	{
		final float scale = ScaleUtils.getBoundingBoxHeightScale((class_1297) (Object) this);
		
		return scale != 1.0F ? scale * value : value;
	}
	
	@Dynamic
	@ModifyExpressionValue(method = MixinConstants.GET_PASSENGER_ATTACHMENT_Y, at = @At(value = "CONSTANT", args = "floatValue=0.6F"))
	private float pehkui$camelMountedHeightOffset$standingFrontOffset(float value)
	{
		final float scale = ScaleUtils.getBoundingBoxHeightScale((class_1297) (Object) this);
		
		return scale != 1.0F ? scale * value : value;
	}
	
	@Dynamic
	@ModifyExpressionValue(method = MixinConstants.GET_PASSENGER_ATTACHMENT_Y, at = @At(value = "CONSTANT", args = "floatValue=0.35F"))
	private float pehkui$camelMountedHeightOffset$standingBackOffset(float value)
	{
		final float scale = ScaleUtils.getBoundingBoxHeightScale((class_1297) (Object) this);
		
		return scale != 1.0F ? scale * value : value;
	}
	
	@Dynamic
	@ModifyExpressionValue(method = MixinConstants.GET_PASSENGER_ATTACHMENT_Y, at = @At(value = "CONSTANT", args = "floatValue=1.43F"))
	private float pehkui$camelMountedHeightOffset$firstMultiplier(float value)
	{
		final float scale = ScaleUtils.getBoundingBoxHeightScale((class_1297) (Object) this);
		
		return scale != 1.0F ? scale * value : value;
	}
	
	@Dynamic
	@ModifyExpressionValue(method = MixinConstants.GET_PASSENGER_ATTACHMENT_Y, at = @At(value = "CONSTANT", args = "floatValue=0.2F"))
	private float pehkui$camelMountedHeightOffset$secondMultiplier(float value)
	{
		final float scale = ScaleUtils.getBoundingBoxHeightScale((class_1297) (Object) this);
		
		return scale != 1.0F ? scale * value : value;
	}
}
