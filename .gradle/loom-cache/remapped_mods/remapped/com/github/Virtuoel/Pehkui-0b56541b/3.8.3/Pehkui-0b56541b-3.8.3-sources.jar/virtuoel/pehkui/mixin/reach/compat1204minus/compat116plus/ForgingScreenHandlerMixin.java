package virtuoel.pehkui.mixin.reach.compat1204minus.compat116plus;

import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1657;
import net.minecraft.class_4861;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_4861.class)
public class ForgingScreenHandlerMixin
{
	@Dynamic
	@ModifyExpressionValue(method = "method_24924", at = @At(value = "CONSTANT", args = "doubleValue=64.0D"))
	private double pehkui$canUse$distance(double value, class_1657 player)
	{
		final float scale = ScaleUtils.getBlockReachScale(player);
		return scale != 1.0F ? scale * scale * value : value;
	}
}
