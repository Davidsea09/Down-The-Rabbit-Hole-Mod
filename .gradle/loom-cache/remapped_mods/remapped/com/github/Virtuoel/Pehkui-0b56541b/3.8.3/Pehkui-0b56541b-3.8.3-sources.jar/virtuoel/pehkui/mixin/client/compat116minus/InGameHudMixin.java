package virtuoel.pehkui.mixin.client.compat116minus;

import net.minecraft.class_310;
import net.minecraft.class_329;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleRenderUtils;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_329.class)
public abstract class InGameHudMixin
{
	@Dynamic
	@ModifyVariable(method = MixinConstants.RENDER_STATUS_BARS, at = @At(value = "INVOKE", shift = Shift.BEFORE, target = MixinConstants.GET_ABSORPTION_AMOUNT))
	private float pehkui$renderStatusBars(float value)
	{
		final class_310 client = class_310.method_1551();
		
		final float healthScale = ScaleUtils.getHealthScale(client.method_1560(), ScaleRenderUtils.getTickDelta(client));
		
		return healthScale != 1.0F ? value * healthScale : value;
	}
}
