package virtuoel.pehkui.mixin;

import net.minecraft.class_2168;
import net.minecraft.class_2203;
import net.minecraft.class_3162;
import net.minecraft.class_3164;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

public interface DataCommandInvoker
{
	@Mixin(class_3164.class)
	public interface Get
	{
		@Invoker
		public static int callExecuteGet(class_2168 source, class_3162 object)
		{
			throw new NoSuchMethodError();
		}
	}
	
	@Mixin(class_3164.class)
	public interface Path
	{
		@Invoker
		public static int callExecuteGet(class_2168 source, class_3162 object, class_2203.class_2209 path)
		{
			throw new NoSuchMethodError();
		}
	}
	
	@Mixin(class_3164.class)
	public interface Scaled
	{
		@Invoker
		public static int callExecuteGet(class_2168 source, class_3162 object, class_2203.class_2209 path, double scale)
		{
			throw new NoSuchMethodError();
		}
	}
}
