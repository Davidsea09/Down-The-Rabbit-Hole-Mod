package virtuoel.pehkui.mixin.compat119plus;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.class_1297;
import net.minecraft.class_7264;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_7264.class)
public abstract class ChestBoatEntityMixin
{
	@ModifyReturnValue(method = "getPassengerHorizontalOffset", at = @At("RETURN"))
	private float pehkui$getPassengerHorizontalOffset(float original)
	{
		final float scale = ScaleUtils.getBoundingBoxWidthScale((class_1297) (Object) this);
		
		return scale != 1.0F ? original * scale : original;
	}
}
