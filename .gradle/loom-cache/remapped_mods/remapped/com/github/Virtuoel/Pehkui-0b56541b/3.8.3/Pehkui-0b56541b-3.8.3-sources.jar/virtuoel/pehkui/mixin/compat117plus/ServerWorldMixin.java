package virtuoel.pehkui.mixin.compat117plus;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_5579;
import virtuoel.pehkui.Pehkui;
import virtuoel.pehkui.api.ScaleRegistries;
import virtuoel.pehkui.api.ScaleType;

@Mixin(class_3218.class)
public class ServerWorldMixin
{
	@Shadow @Final @Mutable
	class_5579<class_1297> entityManager;
	
	@ModifyReturnValue(method = "getDebugString", at = @At("RETURN"))
	private String pehkui$getDebugString(String value)
	{
		String additional = "";
		
		for (final class_1297 entity : entityManager.method_31841().method_31803())
		{
			float maxScale = 1.0F;
			ScaleType maxType = null;
			
			float scale;
			for (final ScaleType type : ScaleRegistries.SCALE_TYPES.values())
			{
				scale = type.getScaleData(entity).getBaseScale();
				if (scale != type.getDefaultBaseScale() && scale > maxScale)
				{
					maxScale = scale;
					maxType = type;
				}
			}
			
			if (maxType != null)
			{
				additional += additional.isEmpty() ? ", pehkui:scaled_entities: {[{" : "}, {";
				
				final class_2960 id = ScaleRegistries.getId(ScaleRegistries.SCALE_TYPES, maxType);
				
				final String idString = Pehkui.MOD_ID.equals(id.method_12836()) ? id.method_12832() : id.toString();
				
				additional += "\"" + entity.method_5845() + "\":\"" + class_1299.method_5890(entity.method_5864()) + "\",\"" + idString + "\":" + maxScale;
			}
		}
		
		return additional.isEmpty() ? value : (value + additional + "}]}");
	}
}
