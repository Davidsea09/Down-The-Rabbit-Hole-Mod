package virtuoel.pehkui.mixin.compat115minus;

import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1641;
import net.minecraft.class_1642;
import net.minecraft.class_1646;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1642.class)
public class ZombieEntityMixin
{
	@Dynamic
	@Inject(method = MixinConstants.CONVERT_TO, at = @At(value = "INVOKE", shift = Shift.BEFORE, target = MixinConstants.ZOMBIE_COPY_POS_AND_ROT))
	private void pehkui$convertTo(class_1299<? extends class_1642> entityType, CallbackInfo info, @Local class_1642 zombieEntity)
	{
		ScaleUtils.loadScale(zombieEntity, (class_1297) (Object) this);
	}
	
	@Dynamic
	@Inject(method = MixinConstants.ON_KILLED_OTHER, at = @At(value = "INVOKE", shift = Shift.BEFORE, target = MixinConstants.ZOMBIE_VILLAGER_COPY_POS_AND_ROT))
	private void pehkui$onKilledOther(class_1309 other, CallbackInfo info, @Local class_1646 villagerEntity, @Local class_1641 zombieVillagerEntity)
	{
		ScaleUtils.loadScale(zombieVillagerEntity, villagerEntity);
	}
}
