package virtuoel.pehkui.mixin.compat116plus;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1296;
import net.minecraft.class_1429;
import net.minecraft.class_3218;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1429.class)
public class AnimalEntityMixin
{
	@Inject(method = "breed(Lnet/minecraft/server/world/ServerWorld;Lnet/minecraft/entity/passive/AnimalEntity;)V", at = @At(value = "INVOKE", shift = Shift.BEFORE, target = "Lnet/minecraft/server/world/ServerWorld;spawnEntityAndPassengers(Lnet/minecraft/entity/Entity;)V"))
	private void pehkui$breed(class_3218 serverWorld, class_1429 other, CallbackInfo info, @Local class_1296 passiveEntity)
	{
		ScaleUtils.loadAverageScales(passiveEntity, (class_1429) (Object) this, other);
	}
}
