package virtuoel.pehkui.mixin.compat121plus;

import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1668;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1668.class)
public abstract class ExplosiveProjectileEntityMixin
{
	@Shadow
	abstract void setVelocityWithAcceleration(class_243 velocity, double accelerationPower);
	
	@Inject(at = @At("RETURN"), method = "<init>(Lnet/minecraft/entity/EntityType;Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/world/World;)V")
	private void pehkui$construct(class_1299<? extends class_1668> type, class_1309 owner, class_243 velocity, class_1937 world, CallbackInfo info)
	{
		final class_1668 self = (class_1668) (Object) this;
		final float scale = ScaleUtils.setScaleOfProjectile(self, owner);
		
		if (scale != 1.0F)
		{
			self.field_51893 *= scale;
			setVelocityWithAcceleration(velocity, self.field_51893);
		}
	}
}
