package virtuoel.pehkui.mixin;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1682;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1682.class)
public abstract class ThrownEntityMixin
{
	@Inject(at = @At("RETURN"), method = "<init>(Lnet/minecraft/entity/EntityType;Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/world/World;)V")
	private void pehkui$construct(class_1299<? extends class_1682> type, class_1309 owner, class_1937 world, CallbackInfo info)
	{
		final float heightScale = ScaleUtils.getEyeHeightScale(owner);
		if (heightScale != 1.0F)
		{
			final class_1297 self = ((class_1297) (Object) this);
			
			final class_243 pos = self.method_19538();
			
			self.method_5814(pos.field_1352, pos.field_1351 + ((1.0F - heightScale) * 0.1D), pos.field_1350);
		}
		
		ScaleUtils.setScaleOfProjectile((class_1297) (Object) this, owner);
	}
}
