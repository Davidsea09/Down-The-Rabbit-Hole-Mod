package virtuoel.pehkui.mixin;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1669;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1669.class)
public class EvokerFangsEntityMixin
{
	@Inject(at = @At("RETURN"), method = "<init>(Lnet/minecraft/world/World;DDDFILnet/minecraft/entity/LivingEntity;)V")
	private void pehkui$construct(class_1937 world, double x, double y, double z, float yaw, int warmup, class_1309 owner, CallbackInfo info)
	{
		ScaleUtils.setScaleOfProjectile((class_1297) (Object) this, owner);
	}
}
