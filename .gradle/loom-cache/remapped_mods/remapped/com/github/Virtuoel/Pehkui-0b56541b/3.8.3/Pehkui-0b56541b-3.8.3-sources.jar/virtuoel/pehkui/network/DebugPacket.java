package virtuoel.pehkui.network;

import net.minecraft.class_2540;
import virtuoel.pehkui.server.command.DebugCommand;

public class DebugPacket
{
	public final DebugCommand.PacketType type;
	
	public DebugPacket(final DebugCommand.PacketType type)
	{
		this.type = type;
	}
	
	public DebugPacket(final class_2540 buf)
	{
		DebugCommand.PacketType read;
		
		try
		{
			read = buf.method_10818(DebugCommand.PacketType.class);
		}
		catch (Exception e)
		{
			read = null;
		}
		
		this.type = read;
	}
	
	public void write(final class_2540 buf)
	{
		buf.method_10817(this.type);
	}
}
