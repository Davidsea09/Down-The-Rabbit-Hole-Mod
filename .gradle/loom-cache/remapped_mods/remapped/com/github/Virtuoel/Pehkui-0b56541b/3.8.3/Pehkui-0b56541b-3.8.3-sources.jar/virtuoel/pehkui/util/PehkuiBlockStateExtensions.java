package virtuoel.pehkui.util;

import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_265;

public interface PehkuiBlockStateExtensions
{
	class_265 pehkui_getOutlineShape(class_1922 world, class_2338 pos);
	
	class_2248 pehkui_getBlock();
}
