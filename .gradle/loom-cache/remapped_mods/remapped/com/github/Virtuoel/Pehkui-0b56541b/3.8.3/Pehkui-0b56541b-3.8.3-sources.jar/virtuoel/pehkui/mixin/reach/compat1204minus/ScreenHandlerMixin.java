package virtuoel.pehkui.mixin.reach.compat1204minus;

import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_2248;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1703.class)
public class ScreenHandlerMixin
{
	@Dynamic
	@ModifyExpressionValue(method = "method_17696", at = @At(value = "CONSTANT", args = "doubleValue=64.0D"))
	private static double pehkui$canUse$distance(double value, class_2248 block, class_1657 player)
	{
		final float scale = ScaleUtils.getBlockReachScale(player);
		return scale > 1.0F ? scale * scale * value : value;
	}
}
