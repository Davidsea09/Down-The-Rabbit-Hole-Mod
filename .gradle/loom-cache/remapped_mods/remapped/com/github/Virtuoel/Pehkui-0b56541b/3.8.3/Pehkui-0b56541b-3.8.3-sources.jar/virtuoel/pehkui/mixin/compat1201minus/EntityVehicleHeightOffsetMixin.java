package virtuoel.pehkui.mixin.compat1201minus;

import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.class_1297;
import net.minecraft.class_1429;
import net.minecraft.class_1531;
import net.minecraft.class_1547;
import net.minecraft.class_1559;
import net.minecraft.class_1614;
import net.minecraft.class_1642;
import net.minecraft.class_1657;
import net.minecraft.class_3732;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ReflectionUtils;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin({
	class_1531.class,
	class_1547.class,
	class_1559.class,
	class_3732.class,
	class_1614.class,
	class_1642.class,
	class_1429.class,
	class_1657.class
})
public abstract class EntityVehicleHeightOffsetMixin
{
	@Dynamic
	@ModifyReturnValue(method = MixinConstants.GET_HEIGHT_OFFSET, at = @At("RETURN"))
	private double pehkui$getHeightOffset(double offset)
	{
		final class_1297 self = (class_1297) (Object) this;
		final class_1297 vehicle = self.method_5854();
		
		if (vehicle != null)
		{
			final float scale = ScaleUtils.getBoundingBoxHeightScale(self);
			final float vehicleScale = ScaleUtils.getBoundingBoxHeightScale(vehicle);
			
			if (scale != 1.0F || vehicleScale != 1.0F)
			{
				final double vehicleScaledHeight = vehicle.method_17682();
				final double vehicleHeight = vehicleScaledHeight / vehicleScale;
				final double scaledMountedOffset = ReflectionUtils.getMountedHeightOffset(vehicle);
				final double mountedOffset = scaledMountedOffset / vehicleScale;
				final double scaledOffset = offset * scale;
				
				final double bottom = vehicleHeight - mountedOffset - offset;
				final double down = vehicleScaledHeight - scaledMountedOffset - (bottom * scale);
				
				return (down < scaledOffset ? scaledOffset : down);
			}
		}
		
		return offset;
	}
}
