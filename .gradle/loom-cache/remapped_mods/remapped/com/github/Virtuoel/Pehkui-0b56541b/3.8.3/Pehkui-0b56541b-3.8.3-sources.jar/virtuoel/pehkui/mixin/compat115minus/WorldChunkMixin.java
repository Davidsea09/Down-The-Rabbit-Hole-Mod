package virtuoel.pehkui.mixin.compat115minus;

import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_2818;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_2818.class)
public class WorldChunkMixin
{
	@Dynamic
	@WrapOperation(method = MixinConstants.GET_ENTITIES, at = @At(value = "INVOKE", target = MixinConstants.GET_BOUNDING_BOX, ordinal = 0))
	private class_238 pehkui$getEntities$getBoundingBox(class_1297 obj, Operation<class_238> original)
	{
		final class_238 bounds = original.call(obj);
		
		final float interactionWidth = ScaleUtils.getInteractionBoxWidthScale(obj);
		final float interactionHeight = ScaleUtils.getInteractionBoxHeightScale(obj);
		
		if (interactionWidth != 1.0F || interactionHeight != 1.0F)
		{
			final double scaledXLength = bounds.method_17939() * 0.5D * (interactionWidth - 1.0F);
			final double scaledYLength = bounds.method_17940() * 0.5D * (interactionHeight - 1.0F);
			final double scaledZLength = bounds.method_17941() * 0.5D * (interactionWidth - 1.0F);
			
			return bounds.method_1009(scaledXLength, scaledYLength, scaledZLength);
		}
		
		return bounds;
	}
	
	@Dynamic
	@WrapOperation(method = MixinConstants.GET_ENTITIES_ENTITY_TYPE, at = @At(value = "INVOKE", target = MixinConstants.GET_BOUNDING_BOX))
	private class_238 pehkui$getEntities$getBoundingBox$type(class_1297 obj, Operation<class_238> original)
	{
		final class_238 bounds = original.call(obj);
		
		final float interactionWidth = ScaleUtils.getInteractionBoxWidthScale(obj);
		final float interactionHeight = ScaleUtils.getInteractionBoxHeightScale(obj);
		
		if (interactionWidth != 1.0F || interactionHeight != 1.0F)
		{
			final double scaledXLength = bounds.method_17939() * 0.5D * (interactionWidth - 1.0F);
			final double scaledYLength = bounds.method_17940() * 0.5D * (interactionHeight - 1.0F);
			final double scaledZLength = bounds.method_17941() * 0.5D * (interactionWidth - 1.0F);
			
			return bounds.method_1009(scaledXLength, scaledYLength, scaledZLength);
		}
		
		return bounds;
	}
	
	@Dynamic
	@WrapOperation(method = MixinConstants.GET_ENTITIES_CLASS, at = @At(value = "INVOKE", target = MixinConstants.GET_BOUNDING_BOX))
	private class_238 pehkui$getEntities$getBoundingBox$class(class_1297 obj, Operation<class_238> original)
	{
		final class_238 bounds = original.call(obj);
		
		final float interactionWidth = ScaleUtils.getInteractionBoxWidthScale(obj);
		final float interactionHeight = ScaleUtils.getInteractionBoxHeightScale(obj);
		
		if (interactionWidth != 1.0F || interactionHeight != 1.0F)
		{
			final double scaledXLength = bounds.method_17939() * 0.5D * (interactionWidth - 1.0F);
			final double scaledYLength = bounds.method_17940() * 0.5D * (interactionHeight - 1.0F);
			final double scaledZLength = bounds.method_17941() * 0.5D * (interactionWidth - 1.0F);
			
			return bounds.method_1009(scaledXLength, scaledYLength, scaledZLength);
		}
		
		return bounds;
	}
}
