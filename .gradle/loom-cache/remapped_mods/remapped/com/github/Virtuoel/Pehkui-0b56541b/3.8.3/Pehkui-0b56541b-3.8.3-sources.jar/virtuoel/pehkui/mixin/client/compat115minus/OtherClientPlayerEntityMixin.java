package virtuoel.pehkui.mixin.client.compat115minus;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1297;
import net.minecraft.class_745;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_745.class)
public class OtherClientPlayerEntityMixin
{
	@ModifyExpressionValue(method = "tick", at = @At(value = "CONSTANT", args = "floatValue=4.0F"))
	private float pehkui$tick$limbDistance(float value)
	{
		return ScaleUtils.modifyLimbDistance(value, (class_1297) (Object) this);
	}
}
