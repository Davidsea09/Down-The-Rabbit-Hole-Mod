package virtuoel.pehkui.mixin;

import net.minecraft.class_1297;
import net.minecraft.class_1531;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1531.class)
public abstract class ArmorStandEntityMixin
{
	@ModifyVariable(method = "getSlotFromPosition", at = @At(value = "STORE"))
	private double pehkui$getSlotFromPosition(double value)
	{
		final float scale = ScaleUtils.getBoundingBoxHeightScale((class_1297) (Object) this);
		return scale != 1.0F ? value / scale : value;
	}
}
