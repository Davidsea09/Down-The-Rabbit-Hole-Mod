package virtuoel.pehkui.mixin;

import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_2096;
import net.minecraft.class_2303;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import virtuoel.pehkui.api.ScaleType;
import virtuoel.pehkui.api.ScaleTypes;
import virtuoel.pehkui.util.CommandUtils;
import virtuoel.pehkui.util.PehkuiEntitySelectorReaderExtensions;

@Mixin(class_2303.class)
public abstract class EntitySelectorReaderMixin implements PehkuiEntitySelectorReaderExtensions
{
	@Shadow
	abstract void addPredicate(Predicate<class_1297> predicate);
	
	@Unique
	class_2096.class_2099 pehkui$scaleRange = (class_2096.class_2099) (Object) class_2096.class_2099.field_9705;
	@Unique
	class_2096.class_2099 pehkui$computedScaleRange = (class_2096.class_2099) (Object) class_2096.class_2099.field_9705;
	@Unique
	ScaleType pehkui$scaleType = ScaleTypes.INVALID;
	@Unique
	ScaleType pehkui$computedScaleType = ScaleTypes.INVALID;
	
	@Inject(method = "buildPredicate", at = @At("HEAD"))
	private void pehkui$buildPredicate(CallbackInfo info)
	{
		if (!this.pehkui$scaleRange.method_9041())
		{
			final ScaleType scaleType = this.pehkui$scaleType == ScaleTypes.INVALID ? ScaleTypes.BASE : this.pehkui$scaleType;
			addPredicate(e -> CommandUtils.testFloatRange(this.pehkui$scaleRange, scaleType.getScaleData(e).getBaseScale()));
		}
		
		if (!this.pehkui$computedScaleRange.method_9041())
		{
			final ScaleType scaleType = this.pehkui$computedScaleType == ScaleTypes.INVALID ? ScaleTypes.BASE : this.pehkui$computedScaleType;
			addPredicate(e -> CommandUtils.testFloatRange(this.pehkui$computedScaleRange, scaleType.getScaleData(e).getScale()));
		}
	}
	
	@Override
	public ScaleType pehkui_getScaleType()
	{
		return this.pehkui$scaleType;
	}
	
	@Override
	public void pehkui_setScaleType(final ScaleType scaleType)
	{
		this.pehkui$scaleType = scaleType;
	}
	
	@Override
	public class_2096<? extends Number> pehkui_getScaleRange()
	{
		return this.pehkui$scaleRange;
	}
	
	@Override
	public void pehkui_setScaleRange(final class_2096.class_2099 baseScaleRange)
	{
		this.pehkui$scaleRange = baseScaleRange;
	}
	
	@Override
	public ScaleType pehkui_getComputedScaleType()
	{
		return this.pehkui$computedScaleType;
	}
	
	@Override
	public void pehkui_setComputedScaleType(final ScaleType computedScaleType)
	{
		this.pehkui$computedScaleType = computedScaleType;
	}
	
	@Override
	public class_2096<? extends Number> pehkui_getComputedScaleRange()
	{
		return this.pehkui$computedScaleRange;
	}
	
	@Override
	public void pehkui_setComputedScaleRange(final class_2096.class_2099 computedScaleRange)
	{
		this.pehkui$computedScaleRange = computedScaleRange;
	}
}
