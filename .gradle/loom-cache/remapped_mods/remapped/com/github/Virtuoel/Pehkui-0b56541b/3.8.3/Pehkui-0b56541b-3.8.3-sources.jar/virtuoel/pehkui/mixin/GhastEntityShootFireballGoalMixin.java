package virtuoel.pehkui.mixin;

import net.minecraft.class_1297;
import net.minecraft.class_1571;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(targets = "net.minecraft.entity.mob.GhastEntity$ShootFireballGoal")
public abstract class GhastEntityShootFireballGoalMixin
{
	@Shadow @Final class_1571 ghast;
	
	@ModifyArg(method = "tick()V", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/World;spawnEntity(Lnet/minecraft/entity/Entity;)Z"))
	private class_1297 pehkui$tick$spawnEntity(class_1297 entity)
	{
		final float scale = ScaleUtils.getBoundingBoxHeightScale(ghast);
		
		if (scale != 1.0F)
		{
			final class_243 pos = entity.method_19538();
			
			entity.method_5814(pos.field_1352, pos.field_1351 - ((1.0D - scale) * 0.5D), pos.field_1350);
		}
		
		return entity;
	}
}
