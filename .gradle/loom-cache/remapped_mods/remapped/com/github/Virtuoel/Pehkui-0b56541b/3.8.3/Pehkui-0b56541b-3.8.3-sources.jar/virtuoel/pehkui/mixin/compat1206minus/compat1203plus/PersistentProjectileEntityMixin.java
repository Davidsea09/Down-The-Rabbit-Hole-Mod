package virtuoel.pehkui.mixin.compat1206minus.compat1203plus;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1665;
import net.minecraft.class_1676;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1665.class)
public abstract class PersistentProjectileEntityMixin
{
	@Dynamic
	@Inject(at = @At("RETURN"), method = MixinConstants.PERSISTENT_PROJECTILE_ENTITY_WITH_STACK_INIT)
	private void pehkui$construct(class_1299<? extends class_1676> type, class_1309 owner, class_1937 world, class_1799 stack, CallbackInfo info)
	{
		final float scale = ScaleUtils.getEyeHeightScale(owner);
		
		if (scale != 1.0F)
		{
			final class_1297 self = ((class_1297) (Object) this);
			
			final class_243 pos = self.method_19538();
			
			self.method_5814(pos.field_1352, pos.field_1351 + ((1.0F - scale) * 0.1D), pos.field_1350);
		}
	}
}
