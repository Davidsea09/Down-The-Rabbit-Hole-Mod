package virtuoel.pehkui.mixin.compat117;

import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_5568;
import net.minecraft.class_5573;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_5573.class)
public class SectionedEntityCacheMixin
{
	@Dynamic
	@WrapOperation(method = "method_31776", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/EntityLike;getBoundingBox()Lnet/minecraft/util/math/Box;"))
	private static class_238 pehkui$intersecting$getBoundingBox(class_5568 obj, Operation<class_238> original)
	{
		final class_238 bounds = original.call(obj);
		
		if (obj instanceof class_1297)
		{
			final class_1297 entity = (class_1297) obj;
			
			final float interactionWidth = ScaleUtils.getInteractionBoxWidthScale(entity);
			final float interactionHeight = ScaleUtils.getInteractionBoxHeightScale(entity);
			
			if (interactionWidth != 1.0F || interactionHeight != 1.0F)
			{
				final double scaledXLength = bounds.method_17939() * 0.5D * (interactionWidth - 1.0F);
				final double scaledYLength = bounds.method_17940() * 0.5D * (interactionHeight - 1.0F);
				final double scaledZLength = bounds.method_17941() * 0.5D * (interactionWidth - 1.0F);
				
				return bounds.method_1009(scaledXLength, scaledYLength, scaledZLength);
			}
		}
		
		return bounds;
	}
}
