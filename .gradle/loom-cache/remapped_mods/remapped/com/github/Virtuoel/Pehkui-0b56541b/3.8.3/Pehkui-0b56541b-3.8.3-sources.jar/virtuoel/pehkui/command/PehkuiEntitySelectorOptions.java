package virtuoel.pehkui.command;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.class_2096;
import net.minecraft.class_2303;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_2522;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import virtuoel.pehkui.Pehkui;
import virtuoel.pehkui.api.ScaleRegistries;
import virtuoel.pehkui.api.ScaleType;
import virtuoel.pehkui.api.ScaleTypes;
import virtuoel.pehkui.command.argument.ScaleTypeArgumentType;
import virtuoel.pehkui.mixin.EntitySelectorOptionsInvoker;
import virtuoel.pehkui.util.CommandUtils;
import virtuoel.pehkui.util.I18nUtils;
import virtuoel.pehkui.util.PehkuiEntityExtensions;
import virtuoel.pehkui.util.PehkuiEntitySelectorReaderExtensions;
import virtuoel.pehkui.util.ReflectionUtils;

public class PehkuiEntitySelectorOptions
{
	public static final class_2561 SCALE_RANGE_DESCRIPTION = I18nUtils.translate("argument.entity.options." + Pehkui.MOD_ID + ".scale_range.description", "Entities with scale value");
	public static final class_2561 SCALE_TYPE_DESCRIPTION = I18nUtils.translate("argument.entity.options." + Pehkui.MOD_ID + ".scale_type.description", "Entities with scale type");
	public static final class_2561 SCALE_NBT_DESCRIPTION = I18nUtils.translate("argument.entity.options." + Pehkui.MOD_ID + ".scale_nbt.description", "Entities with scale NBT");
	
	public static void register()
	{
		EntitySelectorOptionsInvoker.callPutOption(
			Pehkui.id("scale").toString().replace(':', '.'),
			r -> cast(r).pehkui_setScaleRange(class_2096.class_2099.method_9049(r.method_9835())),
			r -> ReflectionUtils.isDummy(cast(r).pehkui_getScaleRange()),
			SCALE_RANGE_DESCRIPTION
		);
		
		EntitySelectorOptionsInvoker.callPutOption(
			Pehkui.id("scale_type").toString().replace(':', '.'),
			r -> cast(r).pehkui_setScaleType(parseScaleType(r)),
			r -> cast(r).pehkui_getScaleType() == ScaleTypes.INVALID,
			SCALE_TYPE_DESCRIPTION
		);
		
		EntitySelectorOptionsInvoker.callPutOption(
			Pehkui.id("computed_scale").toString().replace(':', '.'),
			r -> cast(r).pehkui_setComputedScaleRange(class_2096.class_2099.method_9049(r.method_9835())),
			r -> ReflectionUtils.isDummy(cast(r).pehkui_getComputedScaleRange()),
			SCALE_RANGE_DESCRIPTION
		);
		
		EntitySelectorOptionsInvoker.callPutOption(
			Pehkui.id("computed_scale_type").toString().replace(':', '.'),
			r -> cast(r).pehkui_setComputedScaleType(parseScaleType(r)),
			r -> cast(r).pehkui_getComputedScaleType() == ScaleTypes.INVALID,
			SCALE_TYPE_DESCRIPTION
		);
		
		EntitySelectorOptionsInvoker.callPutOption(
			Pehkui.id("scale_nbt").toString().replace(':', '.'),
			r ->
			{
				final boolean negated = r.method_9892();
				final class_2487 parsed = (new class_2522(r.method_9835())).method_10727();
				r.method_9916(entity ->
				{
					final class_2487 nbt = ((PehkuiEntityExtensions) entity).pehkui_writeScaleNbt(new class_2487());
					
					return class_2512.method_10687(parsed, nbt, true) != negated;
				});
			},
			reader -> true,
			SCALE_NBT_DESCRIPTION
		);
	}
	
	private static PehkuiEntitySelectorReaderExtensions cast(class_2303 reader)
	{
		return ((PehkuiEntitySelectorReaderExtensions) reader);
	}
	
	private static ScaleType parseScaleType(class_2303 reader) throws CommandSyntaxException
	{
		reader.method_9875((builder, consumer) ->
		{
			CommandUtils.suggestIdentifiersIgnoringNamespace(
				Pehkui.MOD_ID,
				ScaleRegistries.SCALE_TYPES.keySet(),
				builder
			);
			
			return builder.buildFuture();
		});
		
		final int i = reader.method_9835().getCursor();
		
		final class_2960 id = class_2960.method_12835(reader.method_9835());
		final ScaleType scaleType = ScaleRegistries.getEntry(ScaleRegistries.SCALE_TYPES, id);
		
		final class_2960 defaultId = ScaleRegistries.getDefaultId(ScaleRegistries.SCALE_TYPES);
		final ScaleType defaultType = ScaleRegistries.getEntry(ScaleRegistries.SCALE_TYPES, defaultId);
		
		if (scaleType == null || (scaleType == defaultType && !id.equals(defaultId)))
		{
			reader.method_9835().setCursor(i);
			throw ScaleTypeArgumentType.INVALID_ENTRY_EXCEPTION.createWithContext(reader.method_9835(), id.toString());
		}
		
		return scaleType;
	}
}
