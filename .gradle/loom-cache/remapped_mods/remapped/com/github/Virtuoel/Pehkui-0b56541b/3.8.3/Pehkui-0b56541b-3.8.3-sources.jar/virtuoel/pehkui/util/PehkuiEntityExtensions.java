package virtuoel.pehkui.util;

import java.util.Map;
import net.minecraft.class_2487;
import virtuoel.pehkui.api.ScaleData;
import virtuoel.pehkui.api.ScaleType;

public interface PehkuiEntityExtensions
{
	ScaleData pehkui_constructScaleData(ScaleType type);
	
	ScaleData pehkui_getScaleData(ScaleType type);
	
	ScaleData[] pehkui_getScaleCache();
	
	void pehkui_setScaleCache(ScaleData[] scaleCache);
	
	Map<ScaleType, ScaleData> pehkui_getScales();
	
	boolean pehkui_shouldSyncScales();
	
	void pehkui_setShouldSyncScales(boolean sync);
	
	boolean pehkui_shouldIgnoreScaleNbt();
	
	void pehkui_setShouldIgnoreScaleNbt(boolean ignore);
	
	void pehkui_readScaleNbt(class_2487 nbt);
	
	class_2487 pehkui_writeScaleNbt(class_2487 nbt);
	
	boolean pehkui_isFirstUpdate();
	
	boolean pehkui_getOnGround();
	
	void pehkui_setOnGround(boolean onGround);
}
