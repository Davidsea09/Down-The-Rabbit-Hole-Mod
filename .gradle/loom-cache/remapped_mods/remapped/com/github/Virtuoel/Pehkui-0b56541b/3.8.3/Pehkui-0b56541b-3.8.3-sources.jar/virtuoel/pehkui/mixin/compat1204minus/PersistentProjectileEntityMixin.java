package virtuoel.pehkui.mixin.compat1204minus;

import net.minecraft.class_1297;
import net.minecraft.class_1665;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1665.class)
public abstract class PersistentProjectileEntityMixin
{
	@Dynamic
	@ModifyArg(method = "tick", index = 1, at = @At(value = "INVOKE", target = MixinConstants.PERSISTENT_PROJECTILE_ENTITY_SET_VELOCITY))
	private double pehkui$tick$gravity(double value)
	{
		final class_243 velocity = ((class_1297) (Object) this).method_18798();
		final float scale = ScaleUtils.getMotionScale((class_1297) (Object) this);
		
		return scale != 1.0F ? velocity.field_1351 + (scale * (value - velocity.field_1351)) : value;
	}
}
