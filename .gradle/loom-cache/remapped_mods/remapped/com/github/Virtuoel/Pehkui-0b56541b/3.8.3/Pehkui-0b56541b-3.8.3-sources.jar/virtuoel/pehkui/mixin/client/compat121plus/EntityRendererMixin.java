package virtuoel.pehkui.mixin.client.compat121plus;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1297;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_897;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_897.class)
public class EntityRendererMixin<T extends class_1297>
{
	@Inject(method = "renderLeash", at = @At(value = "HEAD"))
	private <E extends class_1297> void pehkui$renderLeash$head(T entity, float tickDelta, class_4587 matrices, class_4597 provider, E leashHolder, CallbackInfo info)
	{
		final float widthScale = ScaleUtils.getModelWidthScale(entity, tickDelta);
		final float heightScale = ScaleUtils.getModelHeightScale(entity, tickDelta);
		
		final float inverseWidthScale = 1.0F / widthScale;
		final float inverseHeightScale = 1.0F / heightScale;
		
		matrices.method_22903();
		matrices.method_22905(inverseWidthScale, inverseHeightScale, inverseWidthScale);
		matrices.method_22903();
	}
	
	@Inject(method = "renderLeash", at = @At(value = "RETURN"))
	private <E extends class_1297> void pehkui$renderLeash$return(T entity, float tickDelta, class_4587 matrices, class_4597 provider, E leashHolder, CallbackInfo info)
	{
		matrices.method_22909();
		matrices.method_22909();
	}
	
	@ModifyExpressionValue(method = "renderLabelIfPresent", at = @At(value = "CONSTANT", args = "doubleValue=0.5D"))
	private double pehkui$renderLabelIfPresent$offset(double value, @Local(argsOnly = true) T entity)
	{
		final float scale = ScaleUtils.getBoundingBoxHeightScale(entity);
		
		return scale != 1.0F ? value + (entity.method_17682() * ((1.0F / scale) - 1.0F)) : value;
	}
}
