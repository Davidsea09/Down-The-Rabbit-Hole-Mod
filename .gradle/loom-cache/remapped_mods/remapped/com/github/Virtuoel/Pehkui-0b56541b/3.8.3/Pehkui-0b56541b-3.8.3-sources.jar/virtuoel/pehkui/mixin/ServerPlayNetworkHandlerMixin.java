package virtuoel.pehkui.mixin;

import net.minecraft.class_1313;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_3244.class)
public class ServerPlayNetworkHandlerMixin
{
	@Shadow class_3222 player;
	
	@ModifyArg(method = "onVehicleMove", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/math/Box;contract(D)Lnet/minecraft/util/math/Box;"))
	private double pehkui$onVehicleMove$contract(double value)
	{
		final float scale = ScaleUtils.getMotionScale(player);
		return scale < 1.0F ? value * scale : value;
	}
	
	@ModifyArg(method = "onVehicleMove", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;move(Lnet/minecraft/entity/MovementType;Lnet/minecraft/util/math/Vec3d;)V"))
	private class_243 pehkui$onVehicleMove$move(class_1313 type, class_243 movement)
	{
		final float scale = ScaleUtils.getMotionScale(player.method_5668());
		return scale != 1.0F ? movement.method_1021(1.0F / scale) : movement;
	}
	
	@ModifyArg(method = "onPlayerMove", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayerEntity;move(Lnet/minecraft/entity/MovementType;Lnet/minecraft/util/math/Vec3d;)V"))
	private class_243 pehkui$onPlayerMove$move(class_1313 type, class_243 movement)
	{
		final float scale = ScaleUtils.getMotionScale(player);
		return scale != 1.0F ? movement.method_1021(1.0F / scale) : movement;
	}
}
