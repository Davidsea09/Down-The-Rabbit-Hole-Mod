package virtuoel.pehkui.mixin;

import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_3222.class)
public abstract class ServerPlayerEntityMixin
{
	@Inject(at = @At("HEAD"), method = "copyFrom")
	private void pehkui$copyFrom(class_3222 oldPlayer, boolean alive, CallbackInfo info)
	{
		ScaleUtils.loadScaleOnRespawn((class_3222) (Object) this, oldPlayer, alive);
	}
}
