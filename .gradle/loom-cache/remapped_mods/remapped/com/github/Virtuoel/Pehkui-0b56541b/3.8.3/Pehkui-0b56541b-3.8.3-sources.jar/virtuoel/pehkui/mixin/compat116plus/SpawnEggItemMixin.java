package virtuoel.pehkui.mixin.compat116plus;

import java.util.Optional;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1826;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(class_1826.class)
public class SpawnEggItemMixin
{
	@Inject(at = @At("RETURN"), method = "spawnBaby(Lnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/entity/mob/MobEntity;Lnet/minecraft/entity/EntityType;Lnet/minecraft/server/world/ServerWorld;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/item/ItemStack;)Ljava/util/Optional;")
	private void pehkui$spawnBaby(class_1657 user, class_1308 mobEntity, class_1299<? extends class_1308> entityType, class_3218 serverWorld, class_243 vec3d, class_1799 itemStack, CallbackInfoReturnable<Optional<class_1308>> info)
	{
		info.getReturnValue().ifPresent(e ->
		{
			ScaleUtils.loadScale(e, mobEntity);
		});
	}
}
