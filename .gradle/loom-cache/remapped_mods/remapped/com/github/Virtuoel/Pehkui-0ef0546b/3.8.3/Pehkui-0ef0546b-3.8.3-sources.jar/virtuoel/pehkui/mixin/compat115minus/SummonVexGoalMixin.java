package virtuoel.pehkui.mixin.compat115minus;

import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.VexEntity;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(targets = "net.minecraft.entity.mob.EvokerEntity$SummonVexGoal")
public class SummonVexGoalMixin
{
	@Dynamic
	@ModifyArg(method = MixinConstants.CAST_SPELL, at = @At(value = "INVOKE", target = MixinConstants.SPAWN_ENTITY))
	private Entity pehkui$castSpell$spawnEntity(Entity entity)
	{
		if (entity instanceof VexEntity)
		{
			ScaleUtils.loadScale(entity, ((VexEntity) entity).getOwner());
		}
		
		return entity;
	}
}
