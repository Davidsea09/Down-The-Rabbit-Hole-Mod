package virtuoel.pehkui.mixin.compat1206minus;

import net.minecraft.entity.decoration.AbstractDecorationEntity;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import virtuoel.pehkui.util.MixinConstants;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(ItemFrameEntity.class)
public abstract class ItemFrameEntityMixin
{
	@Dynamic
	@ModifyArg(method = MixinConstants.UPDATE_ATTACHMENT_POSITION, at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/decoration/ItemFrameEntity;setBoundingBox(Lnet/minecraft/util/math/Box;)V"))
	private Box pehkui$updateAttachment$box(Box box)
	{
		final AbstractDecorationEntity entity = (AbstractDecorationEntity) (Object) this;
		
		final Direction facing = entity.getHorizontalFacing();
		
		final double xLength = box.getLengthX() / -2.0D;
		final double yLength = box.getLengthY() / -2.0D;
		final double zLength = box.getLengthZ() / -2.0D;
		
		final float widthScale = ScaleUtils.getBoundingBoxWidthScale(entity);
		final float heightScale = ScaleUtils.getBoundingBoxHeightScale(entity);
		
		if (widthScale != 1.0F || heightScale != 1.0F)
		{
			final double dX = xLength * (1.0D - widthScale);
			final double dY = yLength * (1.0D - heightScale);
			final double dZ = zLength * (1.0D - widthScale);
			box = box.expand(dX, dY, dZ);
			box = box.offset(dX * facing.getOffsetX(), dY * facing.getOffsetY(), dZ * facing.getOffsetZ());
		}
		
		return box;
	}
}
