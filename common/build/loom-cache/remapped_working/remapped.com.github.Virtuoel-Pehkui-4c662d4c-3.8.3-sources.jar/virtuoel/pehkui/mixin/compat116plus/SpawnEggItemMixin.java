package virtuoel.pehkui.mixin.compat116plus;

import java.util.Optional;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import virtuoel.pehkui.util.ScaleUtils;

@Mixin(SpawnEggItem.class)
public class SpawnEggItemMixin
{
	@Inject(at = @At("RETURN"), method = "spawnBaby(Lnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/entity/mob/MobEntity;Lnet/minecraft/entity/EntityType;Lnet/minecraft/server/world/ServerWorld;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/item/ItemStack;)Ljava/util/Optional;")
	private void pehkui$spawnBaby(Player user, Mob mobEntity, EntityType<? extends Mob> entityType, ServerLevel serverWorld, Vec3 vec3d, ItemStack itemStack, CallbackInfoReturnable<Optional<Mob>> info)
	{
		info.getReturnValue().ifPresent(e ->
		{
			ScaleUtils.loadScale(e, mobEntity);
		});
	}
}
