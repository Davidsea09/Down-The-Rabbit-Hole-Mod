package virtuoel.pehkui.mixin.compat116plus;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import virtuoel.pehkui.util.PehkuiBlockStateExtensions;

@Mixin(BlockBehaviour.BlockStateBase.class)
public abstract class AbstractBlockStateMixin implements PehkuiBlockStateExtensions
{
	@Shadow
	abstract VoxelShape getOutlineShape(BlockGetter world, BlockPos pos);
	
	@Override
	public VoxelShape pehkui_getOutlineShape(BlockGetter world, BlockPos pos)
	{
		return getOutlineShape(world, pos);
	}
	
	@Shadow
	abstract Block getBlock();
	
	@Override
	public Block pehkui_getBlock()
	{
		return getBlock();
	}
}
