package dev.corgitaco.ohthetreesyoullgrow.world.level.chunk.storage;

import dev.corgitaco.ohthetreesyoullgrow.Constants;
import net.minecraft.nbt.NbtByte;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtType;
import net.minecraft.nbt.scanner.ExclusiveNbtCollector;
import net.minecraft.nbt.scanner.NbtScanQuery;

public class LegacyTagStrippingVisitor extends ExclusiveNbtCollector {

    public static final String LEGACY_SCHEDULED_RANDOM_TICKS = "scheduled_random_ticks";
    public static final String STRIPPED_MARKER = "legacy_scheduled_random_ticks_stripped";

    private boolean stripped;

    public LegacyTagStrippingVisitor() {
        super(new NbtScanQuery(Constants.MOD_ID, NbtList.TYPE, LEGACY_SCHEDULED_RANDOM_TICKS));
    }

    @Override
    public NestedResult startSubNbt(NbtType<?> type, String id) {
        NestedResult result = super.startSubNbt(type, id);
        if (result == NestedResult.SKIP) {
            stripped = true;
        }
        return result;
    }

    public NbtCompound getResultWithMarker() {
        if (!(getRoot() instanceof NbtCompound root)) {
            return null;
        }
        if (stripped && root.contains(Constants.MOD_ID, NbtElement.COMPOUND_TYPE)) {
            root.getCompound(Constants.MOD_ID).put(STRIPPED_MARKER, NbtByte.ONE);
        }
        return root;
    }
}
