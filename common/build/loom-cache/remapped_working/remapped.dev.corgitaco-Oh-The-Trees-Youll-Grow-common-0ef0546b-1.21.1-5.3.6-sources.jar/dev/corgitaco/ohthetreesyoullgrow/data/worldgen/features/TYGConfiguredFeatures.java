package dev.corgitaco.ohthetreesyoullgrow.data.worldgen.features;

import dev.corgitaco.ohthetreesyoullgrow.Constants;
import dev.corgitaco.ohthetreesyoullgrow.world.level.levelgen.feature.TYGFeatures;
import dev.corgitaco.ohthetreesyoullgrow.world.level.levelgen.feature.configurations.TreeFromStructureNBTConfig;
import dev.corgitaco.ohthetreesyoullgrow.world.level.levelgen.feature.configurations.TreeFromStructureNBTConfigV2;
import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.registry.Registerable;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.Identifier;
import net.minecraft.util.collection.DataPool;
import net.minecraft.util.math.intprovider.UniformIntProvider;
import net.minecraft.world.gen.blockpredicate.BlockPredicate;
import net.minecraft.world.gen.feature.ConfiguredFeature;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.FeatureConfig;
import net.minecraft.world.gen.stateprovider.BlockStateProvider;
import net.minecraft.world.gen.stateprovider.SimpleBlockStateProvider;
import net.minecraft.world.gen.stateprovider.WeightedBlockStateProvider;
import net.minecraft.world.gen.treedecorator.AlterGroundTreeDecorator;
import net.minecraft.world.gen.treedecorator.BeehiveTreeDecorator;
import net.minecraft.world.gen.treedecorator.LeavesVineTreeDecorator;

public class TYGConfiguredFeatures {
    public static final Map<RegistryKey<ConfiguredFeature<?, ?>>, ConfiguredFeatureFactory> CONFIGURED_FEATURES_FACTORIES = new Reference2ObjectOpenHashMap<>();

    public static final RegistryKey<ConfiguredFeature<?, ?>> V1_TEST_TREE1 = createConfiguredFeature("v1_test_tree_1", TYGFeatures.TREE_FROM_NBT_V1, ctx ->
            new TreeFromStructureNBTConfig.Builder()
                    .baseLocation(Constants.createLocation("features/trees/testv1/test_tree_trunk1"))
                    .canopyLocation(Constants.createLocation("features/trees/testv1/test_tree_canopy1"))
                    .height(UniformIntProvider.create(5, 10))
                    .logProvider(BlockStateProvider.of(Blocks.ACACIA_LOG))
                    .leavesProvider(BlockStateProvider.of(Blocks.ACACIA_LEAVES))
                    .logTarget(Set.of(Blocks.OAK_LOG))
                    .leavesTarget(Set.of(Blocks.OAK_LEAVES))
                    .growableOn(BlockPredicate.matchingBlockTag(BlockTags.DIRT))
                    .maxLogDepth(3)
                    .treeDecorators(List.of(new AlterGroundTreeDecorator(SimpleBlockStateProvider.of(Blocks.MOSS_BLOCK))))
                    .build()
    );

    public static final RegistryKey<ConfiguredFeature<?, ?>> V1_TEST_TREE2 = createConfiguredFeature("v1_test_tree_2", TYGFeatures.TREE_FROM_NBT_V1, ctx ->
            new TreeFromStructureNBTConfig.Builder()
                    .baseLocation(Constants.createLocation("features/trees/testv1/test_tree_trunk1"))
                    .canopyLocation(Constants.createLocation("features/trees/testv1/test_tree_canopy1"))
                    .height(UniformIntProvider.create(5, 10))
                    .logProvider(BlockStateProvider.of(Blocks.JUNGLE_LOG))
                    .leavesProvider(BlockStateProvider.of(Blocks.JUNGLE_LEAVES))
                    .logTarget(Set.of(Blocks.OAK_LOG))
                    .leavesTarget(Set.of(Blocks.OAK_LEAVES))
                    .growableOn(BlockPredicate.matchingBlockTag(BlockTags.DIRT))
                    .maxLogDepth(5)
                    .treeDecorators(List.of(new LeavesVineTreeDecorator(0.5F), new BeehiveTreeDecorator(0.2F)))
                    .build()
    );

    public static final RegistryKey<ConfiguredFeature<?, ?>> V1_TEST_TREE3 = createConfiguredFeature("v1_test_tree_3", TYGFeatures.TREE_FROM_NBT_V1, ctx ->
            new TreeFromStructureNBTConfig.Builder()
                    .baseLocation(Constants.createLocation("features/trees/testv1/test_tree_trunk1"))
                    .canopyLocation(Constants.createLocation("features/trees/testv1/test_tree_canopy1"))
                    .height(UniformIntProvider.create(20, 25))
                    .logProvider(BlockStateProvider.of(Blocks.DIAMOND_BLOCK))
                    .leavesProvider(BlockStateProvider.of(Blocks.EMERALD_BLOCK))
                    .logTarget(Set.of(Blocks.OAK_LOG))
                    .leavesTarget(Set.of(Blocks.OAK_LEAVES))
                    .growableOn(BlockPredicate.matchingBlockTag(BlockTags.DIRT))
                    .maxLogDepth(3)
                    .build()
    );

    public static final RegistryKey<ConfiguredFeature<?, ?>> V1_UPSIDE_DOWN_TEST_TREE1 = createConfiguredFeature("v1_upside_down_test_tree1", TYGFeatures.TREE_FROM_NBT_V1, ctx ->
            new TreeFromStructureNBTConfig.Builder()
                    .baseLocation(Constants.createLocation("features/trees/testv1/test_tree_trunk1"))
                    .canopyLocation(Constants.createLocation("features/trees/testv1/test_tree_canopy1"))
                    .height(UniformIntProvider.create(5, 10))
                    .logProvider(BlockStateProvider.of(Blocks.ACACIA_LOG))
                    .leavesProvider(BlockStateProvider.of(Blocks.ACACIA_LEAVES))
                    .logTarget(Set.of(Blocks.OAK_LOG))
                    .leavesTarget(Set.of(Blocks.OAK_LEAVES))
                    .growableOn(BlockPredicate.matchingBlockTag(BlockTags.DIRT))
                    .maxLogDepth(3)
                    .treeDecorators(List.of(new AlterGroundTreeDecorator(SimpleBlockStateProvider.of(Blocks.MOSS_BLOCK))))
                    .orientation(TreeFromStructureNBTConfig.Orientation.UPSIDE_DOWN)
                    .build()
    );

    public static final RegistryKey<ConfiguredFeature<?, ?>> V1_UPSIDE_DOWN_TEST_TREE2 = createConfiguredFeature("v1_upside_down_test_tree2", TYGFeatures.TREE_FROM_NBT_V1, ctx ->
            new TreeFromStructureNBTConfig.Builder()
                    .baseLocation(Constants.createLocation("features/trees/testv1/test_tree_trunk1"))
                    .canopyLocation(Constants.createLocation("features/trees/testv1/test_tree_canopy1"))
                    .height(UniformIntProvider.create(5, 10))
                    .logProvider(BlockStateProvider.of(Blocks.JUNGLE_LOG))
                    .leavesProvider(BlockStateProvider.of(Blocks.JUNGLE_LEAVES))
                    .logTarget(Set.of(Blocks.OAK_LOG))
                    .leavesTarget(Set.of(Blocks.OAK_LEAVES))
                    .growableOn(BlockPredicate.matchingBlockTag(BlockTags.DIRT))
                    .maxLogDepth(5)
                    .treeDecorators(List.of(new LeavesVineTreeDecorator(0.5F), new BeehiveTreeDecorator(0.2F)))
                    .orientation(TreeFromStructureNBTConfig.Orientation.UPSIDE_DOWN)
                    .build()
    );

    public static final RegistryKey<ConfiguredFeature<?, ?>> V1_UPSIDE_DOWN_TEST_TREE3 = createConfiguredFeature("v1_upside_down_test_tree3", TYGFeatures.TREE_FROM_NBT_V1, ctx ->
            new TreeFromStructureNBTConfig.Builder()
                    .baseLocation(Constants.createLocation("features/trees/testv1/test_tree_trunk1"))
                    .canopyLocation(Constants.createLocation("features/trees/testv1/test_tree_canopy1"))
                    .height(UniformIntProvider.create(20, 25))
                    .logProvider(BlockStateProvider.of(Blocks.DIAMOND_BLOCK))
                    .leavesProvider(BlockStateProvider.of(Blocks.EMERALD_BLOCK))
                    .logTarget(Set.of(Blocks.OAK_LOG))
                    .leavesTarget(Set.of(Blocks.OAK_LEAVES))
                    .growableOn(BlockPredicate.matchingBlockTag(BlockTags.DIRT))
                    .maxLogDepth(3)
                    .orientation(TreeFromStructureNBTConfig.Orientation.UPSIDE_DOWN)
                    .build()
    );

    public static final RegistryKey<ConfiguredFeature<?, ?>> V1_SIDEWAYS_TEST_TREE1 = createConfiguredFeature("v1_sideways_test_tree1", TYGFeatures.TREE_FROM_NBT_V1, ctx ->
            new TreeFromStructureNBTConfig.Builder()
                    .baseLocation(Constants.createLocation("features/trees/testv1/test_tree_trunk1"))
                    .canopyLocation(Constants.createLocation("features/trees/testv1/test_tree_canopy1"))
                    .height(UniformIntProvider.create(5, 10))
                    .logProvider(BlockStateProvider.of(Blocks.ACACIA_LOG))
                    .leavesProvider(BlockStateProvider.of(Blocks.ACACIA_LEAVES))
                    .logTarget(Set.of(Blocks.OAK_LOG))
                    .leavesTarget(Set.of(Blocks.OAK_LEAVES))
                    .growableOn(BlockPredicate.matchingBlockTag(BlockTags.DIRT))
                    .maxLogDepth(3)
                    .treeDecorators(List.of(new AlterGroundTreeDecorator(SimpleBlockStateProvider.of(Blocks.MOSS_BLOCK))))
                    .orientation(TreeFromStructureNBTConfig.Orientation.SIDEWAYS)
                    .build()
    );

    public static final RegistryKey<ConfiguredFeature<?, ?>> V1_SIDEWAYS_TEST_TREE2 = createConfiguredFeature("v1_sideways_test_tree2", TYGFeatures.TREE_FROM_NBT_V1, ctx ->
            new TreeFromStructureNBTConfig.Builder()
                    .baseLocation(Constants.createLocation("features/trees/testv1/test_tree_trunk1"))
                    .canopyLocation(Constants.createLocation("features/trees/testv1/test_tree_canopy1"))
                    .height(UniformIntProvider.create(5, 10))
                    .logProvider(BlockStateProvider.of(Blocks.JUNGLE_LOG))
                    .leavesProvider(BlockStateProvider.of(Blocks.JUNGLE_LEAVES))
                    .logTarget(Set.of(Blocks.OAK_LOG))
                    .leavesTarget(Set.of(Blocks.OAK_LEAVES))
                    .growableOn(BlockPredicate.matchingBlockTag(BlockTags.DIRT))
                    .maxLogDepth(5)
                    .treeDecorators(List.of(new LeavesVineTreeDecorator(0.5F), new BeehiveTreeDecorator(0.2F)))
                    .orientation(TreeFromStructureNBTConfig.Orientation.SIDEWAYS)
                    .build()
    );

    public static final RegistryKey<ConfiguredFeature<?, ?>> V1_SIDEWAYS_TEST_TREE3 = createConfiguredFeature("v1_sideways_test_tree3", TYGFeatures.TREE_FROM_NBT_V1, ctx ->
            new TreeFromStructureNBTConfig.Builder()
                    .baseLocation(Constants.createLocation("features/trees/testv1/test_tree_trunk1"))
                    .canopyLocation(Constants.createLocation("features/trees/testv1/test_tree_canopy1"))
                    .height(UniformIntProvider.create(20, 25))
                    .logProvider(BlockStateProvider.of(Blocks.DIAMOND_BLOCK))
                    .leavesProvider(BlockStateProvider.of(Blocks.EMERALD_BLOCK))
                    .logTarget(Set.of(Blocks.OAK_LOG))
                    .leavesTarget(Set.of(Blocks.OAK_LEAVES))
                    .growableOn(BlockPredicate.matchingBlockTag(BlockTags.DIRT))
                    .maxLogDepth(3)
                    .orientation(TreeFromStructureNBTConfig.Orientation.SIDEWAYS)
                    .build()
    );

    public static final RegistryKey<ConfiguredFeature<?, ?>> V1_TEST_MUSHROOM1 = createConfiguredFeature("v1_test_mushroom_1", TYGFeatures.TREE_FROM_NBT_V1, ctx ->
            new TreeFromStructureNBTConfig.Builder()
                    .baseLocation(Constants.createLocation("features/mushrooms/testv1/test_mushroom_trunk1"))
                    .canopyLocation(Constants.createLocation("features/mushrooms/testv1/test_mushroom_canopy1"))
                    .height(UniformIntProvider.create(5, 10))
                    .logProvider(BlockStateProvider.of(Blocks.MUSHROOM_STEM))
                    .leavesProvider(BlockStateProvider.of(Blocks.RED_MUSHROOM_BLOCK))
                    .logTarget(Set.of(Blocks.MUSHROOM_STEM))
                    .leavesTarget(Set.of(Blocks.RED_MUSHROOM_BLOCK))
                    .growableOn(BlockPredicate.matchingBlockTag(BlockTags.MUSHROOM_GROW_BLOCK))
                    .maxLogDepth(3)
                    .build()
    );

    public static final RegistryKey<ConfiguredFeature<?, ?>> V1_TEST_MUSHROOM2 = createConfiguredFeature("v1_test_mushroom_2", TYGFeatures.TREE_FROM_NBT_V1, ctx ->
            new TreeFromStructureNBTConfig.Builder()
                    .baseLocation(Constants.createLocation("features/mushrooms/testv1/test_mushroom_trunk1"))
                    .canopyLocation(Constants.createLocation("features/mushrooms/testv1/test_mushroom_canopy1"))
                    .height(UniformIntProvider.create(5, 10))
                    .logProvider(BlockStateProvider.of(Blocks.MUSHROOM_STEM))
                    .leavesProvider(BlockStateProvider.of(Blocks.BROWN_MUSHROOM_BLOCK))
                    .logTarget(Set.of(Blocks.MUSHROOM_STEM))
                    .leavesTarget(Set.of(Blocks.RED_MUSHROOM_BLOCK))
                    .growableOn(BlockPredicate.matchingBlockTag(BlockTags.MUSHROOM_GROW_BLOCK))
                    .maxLogDepth(3)
                    .build()
    );

    public static final RegistryKey<ConfiguredFeature<?, ?>> V2_TEST_TREE1 = createConfiguredFeature("v2_test_tree_1", TYGFeatures.TREE_FROM_NBT_V2, ctx ->
            new TreeFromStructureNBTConfigV2.Builder()
                    .baseLocation(Constants.createLocation("features/trees/testv2/test_tree_trunk1"))
                    .canopyLocation(Constants.createLocation("features/trees/testv2/test_tree_canopy1"))
                    .height(UniformIntProvider.create(5, 10))
                    .logProvider(BlockStateProvider.of(Blocks.ACACIA_LOG))
                    .leavesProvider(List.of(BlockStateProvider.of(Blocks.OAK_LEAVES), BlockStateProvider.of(Blocks.OAK_LEAVES)))
                    .logTarget(Set.of(Blocks.OAK_LOG))
                    .leavesTarget(List.of(Blocks.OAK_LEAVES, Blocks.SPRUCE_LEAVES))
                    .growableOn(BlockPredicate.matchingBlockTag(BlockTags.DIRT))
                    .maxLogDepth(3)
                    .replaceFromNBT(Map.of(Blocks.SHROOMLIGHT, new WeightedBlockStateProvider(DataPool.<BlockState>builder().add(Blocks.GLOWSTONE.getDefaultState(), 3).add(Blocks.GLASS.getDefaultState(), 1).build())))
                    .treeDecorators(List.of(new AlterGroundTreeDecorator(SimpleBlockStateProvider.of(Blocks.MOSS_BLOCK))))
                    .build()
    );


    private static <FC extends FeatureConfig, F extends Feature<FC>> RegistryKey<ConfiguredFeature<?, ?>> createConfiguredFeature(String id, Supplier<? extends F> feature, Function<Registerable<ConfiguredFeature<?, ?>>, ? extends FC> config) {
        Identifier tygID = Constants.createLocation(id);

        RegistryKey<ConfiguredFeature<?, ?>> configuredFeatureResourceKey = RegistryKey.of(RegistryKeys.CONFIGURED_FEATURE, tygID);

        CONFIGURED_FEATURES_FACTORIES.put(configuredFeatureResourceKey, configuredFeatureHolderGetter -> new ConfiguredFeature<>(feature.get(), config.apply(configuredFeatureHolderGetter)));

        return configuredFeatureResourceKey;
    }

    public static void register() {
    }

    @FunctionalInterface
    public interface ConfiguredFeatureFactory {
        ConfiguredFeature<?, ?> generate(Registerable<ConfiguredFeature<?, ?>> configuredFeatureHolderGetter);
    }
}
