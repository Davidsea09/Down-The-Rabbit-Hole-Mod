package dev.corgitaco.ohthetreesyoullgrow.world.level.levelgen.feature;

import com.mojang.serialization.Codec;
import dev.corgitaco.ohthetreesyoullgrow.world.level.chunk.RandomTickScheduler;
import dev.corgitaco.ohthetreesyoullgrow.world.level.levelgen.feature.configurations.TreeFromStructureNBTConfig;
import dev.corgitaco.ohthetreesyoullgrow.world.level.levelgen.feature.configurations.TreeLogFilterBehavior;
import it.unimi.dsi.fastutil.longs.LongSet;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.LeavesBlock;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.state.property.Properties;
import net.minecraft.state.property.Property;
import net.minecraft.structure.StructurePiece;
import net.minecraft.structure.StructurePlacementData;
import net.minecraft.structure.StructureStart;
import net.minecraft.structure.StructureTemplate;
import net.minecraft.structure.StructureTemplateManager;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.ChunkRegion;
import net.minecraft.world.StructureWorldAccess;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.gen.blockpredicate.BlockPredicate;
import net.minecraft.world.gen.chunk.ChunkGenerator;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.util.FeatureContext;
import net.minecraft.world.gen.stateprovider.BlockStateProvider;
import net.minecraft.world.gen.structure.Structure;
import net.minecraft.world.gen.treedecorator.TreeDecorator;

public class TreeFromStructureNBTFeature extends Feature<TreeFromStructureNBTConfig> {

    private static final boolean DEBUG = false;

    public TreeFromStructureNBTFeature(Codec<TreeFromStructureNBTConfig> $$0) {
        super($$0);
    }

    @Override
    public boolean generate(FeatureContext<TreeFromStructureNBTConfig> featurePlaceContext) {
        TreeFromStructureNBTConfig config = featurePlaceContext.getConfig();

        BlockStateProvider logProvider = config.logProvider();
        BlockStateProvider leavesProvider = config.leavesProvider();

        StructureWorldAccess level = featurePlaceContext.getWorld();
        StructureTemplateManager templateManager = level.toServerWorld().getStructureTemplateManager();
        Identifier baseLocation = config.baseLocation();
        Optional<StructureTemplate> baseTemplateOptional = templateManager.getTemplate(baseLocation);
        Identifier canopyLocation = config.canopyLocation();
        Optional<StructureTemplate> canopyTemplateOptional = templateManager.getTemplate(canopyLocation);

        if (baseTemplateOptional.isEmpty()) {
            throw noTreePartPresent(baseLocation);
        }
        if (canopyTemplateOptional.isEmpty()) {
            throw noTreePartPresent(canopyLocation);
        }
        StructureTemplate baseTemplate = baseTemplateOptional.get();
        StructureTemplate canopyTemplate = canopyTemplateOptional.get();
        List<StructureTemplate.PalettedBlockInfoList> basePalettes = baseTemplate.blockInfoLists;
        List<StructureTemplate.PalettedBlockInfoList> canopyPalettes = canopyTemplate.blockInfoLists;
        BlockPos origin = featurePlaceContext.getOrigin();
        if (DEBUG) {
            level.setBlockState(origin, Blocks.DIAMOND_BLOCK.getDefaultState(), 2);
            BlockPos blockPos = origin.up(10);
            level.setBlockState(rotateInDirectionAroundOrigin(blockPos, origin, Direction.WEST), Blocks.REDSTONE_BLOCK.getDefaultState(), 2);
            level.setBlockState(rotateInDirectionAroundOrigin(blockPos, origin, Direction.EAST), Blocks.EMERALD_BLOCK.getDefaultState(), 2);
            level.setBlockState(rotateInDirectionAroundOrigin(blockPos, origin, Direction.NORTH), Blocks.DIAMOND_BLOCK.getDefaultState(), 2);
            level.setBlockState(rotateInDirectionAroundOrigin(blockPos, origin, Direction.SOUTH), Blocks.COPPER_BLOCK.getDefaultState(), 2);
        }


        Random random = featurePlaceContext.getRandom();
        BlockRotation rotation = config.randomRotation() ? BlockRotation.random(random) : BlockRotation.NONE;
        StructurePlacementData placeSettings = new StructurePlacementData().setRotation(rotation);
        StructureTemplate.PalettedBlockInfoList trunkBasePalette = placeSettings.getRandomBlockInfos(basePalettes, origin);
        StructureTemplate.PalettedBlockInfoList randomCanopyPalette = placeSettings.getRandomBlockInfos(canopyPalettes, origin);

        List<StructureTemplate.StructureBlockInfo> center = trunkBasePalette.getAllOf(Blocks.WHITE_WOOL);

        if (center.isEmpty()) {
            throw new IllegalArgumentException("No trunk central position was specified for structure NBT palette %s. Trunk central position is specified with white wool.".formatted(config.baseLocation()));
        }
        if (center.size() > 1) {
            throw new IllegalArgumentException("There cannot be more than one trunk central position for structure NBT palette %s. Trunk central position is specified with white wool.".formatted(config.baseLocation()));
        }

        BlockPos centerOffset = center.getFirst().pos();
        centerOffset = new BlockPos(-centerOffset.getX(), 0, -centerOffset.getZ());


        List<StructureTemplate.StructureBlockInfo> logs = getStructureInfosInStructurePalletteFromBlockList(config.logTarget(), trunkBasePalette);
        List<StructureTemplate.StructureBlockInfo> logBuilders = trunkBasePalette.getAllOf(Blocks.RED_WOOL);
        if (logBuilders.isEmpty()) {
            throw new UnsupportedOperationException(String.format("\"%s\" is missing log builders.", baseLocation));
        }

        int trunkLength = config.height().get(random);
        final int maxTrunkBuildingDepth = config.maxLogDepth();

        Direction direction = findDirectionOfGrowthFromOrientation(config.orientation(), config, logBuilders, placeSettings, centerOffset, level, origin, random);
        if (direction == null) {
            return false;
        }

        Map<BlockPos, BlockState> leavePositions = new HashMap<>();
        Map<BlockPos, BlockState> logPositions = new HashMap<>();
        Map<BlockPos, BlockState> additionalPositions = new HashMap<>();

        fillTrunkPositions(logProvider, leavesProvider, config, level, random, origin, placeSettings, trunkBasePalette, centerOffset, logs, logBuilders, leavePositions, logPositions, additionalPositions, maxTrunkBuildingDepth, direction);

        if (generationTests(config, level, random, origin, trunkBasePalette, placeSettings, centerOffset, randomCanopyPalette, leavePositions, logPositions, additionalPositions, trunkLength, direction)) {
            return false;
        }

        placeKnownBlockPositions(logPositions, level);
        placeKnownLeavePositions(leavePositions, level);
        placeKnownBlockPositions(additionalPositions, level);

        Set<BlockPos> decorationPositions = new HashSet<>();
        placeTreeDecorations(config.treeDecorators(), level, random, leavePositions.keySet(), logPositions.keySet(), decorationPositions);

        return true;
    }

    // Return true if generation of the tree should be blocked.
    private static boolean generationTests(TreeFromStructureNBTConfig config, StructureWorldAccess level, Random random, BlockPos origin, StructureTemplate.PalettedBlockInfoList trunkBasePalette, StructurePlacementData placeSettings, BlockPos centerOffset, StructureTemplate.PalettedBlockInfoList randomCanopyPalette, Map<BlockPos, BlockState> leavePositions, Map<BlockPos, BlockState> logPositions, Map<BlockPos, BlockState> additionalPositions, int trunkLength, Direction direction) {
        if (!fillCanopyPositions(trunkBasePalette.getAllOf(Blocks.YELLOW_WOOL), config, level, random, placeSettings, centerOffset, origin, randomCanopyPalette, leavePositions, logPositions, additionalPositions, trunkLength, direction)) {
            return true;
        }

        if (validateLogPositions(logPositions, config, level)) {
            return true;
        }

        if (insideStructure(logPositions, level, config)) {
            return true;
        }

        return testHeightLimit(config, level, logPositions, leavePositions, additionalPositions);
    }

    // Return true if generation of the tree should be blocked.
    private static boolean testHeightLimit(TreeFromStructureNBTConfig config, StructureWorldAccess level, Map<BlockPos, BlockState> logPositions, Map<BlockPos, BlockState> leavePositions, Map<BlockPos, BlockState> additionalPositions) {
        ChunkGenerator generator = level.toServerWorld().getChunkManager().getChunkGenerator();
        int chunkGeneratorMaxY = generator.getWorldHeight() + generator.getMinimumY();
        int maxY = level.getTopY();

        switch (config.heightLimitBehavior()) {
            case DEFAULT -> {
                if (testY(logPositions, maxY) || testY(leavePositions, maxY) || testY(additionalPositions, maxY)) {
                    return true;
                }
            }
            case CHUNK_GENERATOR_HEIGHT_BLOCK -> {
                if (testY(logPositions, chunkGeneratorMaxY) || testY(leavePositions, chunkGeneratorMaxY) || testY(additionalPositions, chunkGeneratorMaxY))
                    return true;
            }
            case WORLD_HEIGHT_PASS_REMOVE_BLOCKS -> {
                removeBlocksAboveY(logPositions, leavePositions, additionalPositions, maxY);
            }
            case CHUNK_GENERATOR_HEIGHT_PASS_REMOVE_BLOCKS -> {
                removeBlocksAboveY(logPositions, leavePositions, additionalPositions, chunkGeneratorMaxY);
            }
        }
        return false;
    }

    private static void removeBlocksAboveY(Map<BlockPos, BlockState> logPositions, Map<BlockPos, BlockState> leavePositions, Map<BlockPos, BlockState> additionalPositions, int yLimit) {
        logPositions.entrySet().removeIf(entry -> entry.getKey().getY() >= yLimit);
        leavePositions.entrySet().removeIf(entry -> entry.getKey().getY() >= yLimit);
        additionalPositions.entrySet().removeIf(entry -> entry.getKey().getY() >= yLimit);
    }

    private static boolean testY(Map<BlockPos, BlockState> positions, int yLimit) {
        for (BlockPos blockPos : positions.keySet()) {
            if (blockPos.getY() >= yLimit) {
                return true;
            }
        }
        return false;
    }

    private static boolean doAllPositionsTouchGround(List<StructureTemplate.StructureBlockInfo> logBuilders, StructurePlacementData placeSettings, BlockPos centerOffset, BlockPos origin, TreeFromStructureNBTConfig config, StructureWorldAccess level, Direction direction) {
        for (StructureTemplate.StructureBlockInfo logBuilder : logBuilders) {
            BlockPos pos = getModifiedPos(placeSettings, logBuilder, centerOffset, origin);
            pos = rotateInDirectionAroundOrigin(pos, origin, direction);
            if (!isOnGround(config.maxLogDepth(), level, pos, config.growableOn(), direction)) {
                return false;
            }
        }
        return true;
    }

    @Nullable
    private static Direction findDirectionOfGrowthFromOrientation(TreeFromStructureNBTConfig.Orientation orientation, TreeFromStructureNBTConfig config, List<StructureTemplate.StructureBlockInfo> logBuilders, StructurePlacementData placeSettings, BlockPos centerOffset, StructureWorldAccess level, BlockPos origin, Random random) {
        switch (orientation) {
            case STANDARD: {
                if (doAllPositionsTouchGround(logBuilders, placeSettings, centerOffset, origin, config, level, Direction.UP)) {
                    return Direction.UP;
                } else {
                    return null; // Unknown
                }
            }
            case UPSIDE_DOWN: {
                if (doAllPositionsTouchGround(logBuilders, placeSettings, centerOffset, origin, config, level, Direction.DOWN)) {
                    return Direction.DOWN;
                } else {
                    return null; // Unknown
                }
            }
            case SIDEWAYS: {
                List<Direction> horizontalDirections = Direction.Type.HORIZONTAL.getShuffled(random);
                List<Direction> validDirections = new ArrayList<>(horizontalDirections.size());

                for (Direction direction : horizontalDirections) {
                    if (doAllPositionsTouchGround(logBuilders, placeSettings, centerOffset, origin, config, level, direction)) {
                        validDirections.add(direction);
                    }
                }
                if (!validDirections.isEmpty()) {
                    return validDirections.getFirst();
                }

                return null; // Unknown
            }
            default:
                throw new IllegalArgumentException("Unreachable statement, orientation %s is not supported.".formatted(orientation));
        }
    }

    private static boolean fillCanopyPositions(List<StructureTemplate.StructureBlockInfo> canopyAnchor, TreeFromStructureNBTConfig config, StructureWorldAccess level, Random randomSource, StructurePlacementData placeSettings, BlockPos centerOffset, BlockPos origin, StructureTemplate.PalettedBlockInfoList randomCanopyPalette, Map<BlockPos, BlockState> leavePositions, Map<BlockPos, BlockState> logPositions, Map<BlockPos, BlockState> additionalPositions, int trunkLength, Direction treeGrowthDirection) {
        if (!canopyAnchor.isEmpty()) {
            if (canopyAnchor.size() > 1) {
                throw new IllegalArgumentException("There cannot be more than one central canopy position. Canopy central position is specified with yellow wool on the trunk palette.");
            }
            return fillCanopyPositions(config.logProvider(), config.leavesProvider(), config, level, randomSource, getModifiedPos(placeSettings, canopyAnchor.getFirst(), centerOffset, origin), placeSettings, randomCanopyPalette, leavePositions, logPositions, additionalPositions, trunkLength, treeGrowthDirection);
        } else {
            return fillCanopyPositions(config.logProvider(), config.leavesProvider(), config, level, randomSource, origin, placeSettings, randomCanopyPalette, leavePositions, logPositions, additionalPositions, trunkLength, treeGrowthDirection);
        }
    }


    private static boolean insideStructure(Map<BlockPos, BlockState> logPositions, StructureWorldAccess level, TreeFromStructureNBTConfig config) {
        if (level instanceof ChunkRegion region) {
            for (BlockPos trunkPosition : logPositions.keySet()) {
                Chunk chunk = level.getChunk(trunkPosition);
                for (StructureStart value : chunk.getStructureStarts().values()) {
                    for (StructurePiece piece : value.getChildren()) {
                        if (piece.getBoundingBox().contains(trunkPosition) && !config.logsPlacementFilter().test(level, trunkPosition)) {
                            return true;
                        }
                    }
                }

                for (Map.Entry<Structure, LongSet> entry : chunk.getStructureReferences().entrySet()) {
                    Structure structure = entry.getKey();
                    LongSet references = entry.getValue();
                    for (long reference : references) {
                        int chunkX = ChunkPos.getPackedX(reference);
                        int chunkZ = ChunkPos.getPackedZ(reference);
                        if (!region.isChunkLoaded(chunkX, chunkZ)) {
                            continue;
                        }
                        Chunk referenceChunk = region.getChunk(chunkX, chunkZ, ChunkStatus.STRUCTURE_STARTS, true);

                        StructureStart startForStructure = referenceChunk.getStructureStart(structure);
                        if (startForStructure != null) {
                            for (StructurePiece piece : startForStructure.getChildren()) {
                                if (piece.getBoundingBox().contains(trunkPosition) && !config.logsPlacementFilter().test(level, trunkPosition)) {
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    private static boolean validateLogPositions(Map<BlockPos, BlockState> logPositions, TreeFromStructureNBTConfig config, StructureWorldAccess level) {
        List<Runnable> post = new ArrayList<>();
        for (BlockPos trunkPosition : logPositions.keySet()) {
            if (!config.logsPlacementFilter().test(level, trunkPosition)) {
                switch (config.treeLogFilterBehavior()) {
                    case PIERCE:
                        continue;
                    case PASSTHROUGH:
                        post.add(() -> logPositions.remove(trunkPosition));
                        continue;
                    case BLOCK:
                        return true;
                }
            }
        }

        post.forEach(Runnable::run);
        return false;
    }

    private static void placeKnownBlockPositions(Map<BlockPos, BlockState> trunkPositions, StructureWorldAccess level) {
        for (Map.Entry<BlockPos, BlockState> entry : trunkPositions.entrySet()) {
            BlockPos trunkPosition = entry.getKey();
            BlockState state = entry.getValue();
            level.setBlockState(trunkPosition, state, 2);
        }
    }

    private static void placeKnownLeavePositions(Map<BlockPos, BlockState> leavePositions, StructureWorldAccess level) {
        List<Runnable> leavesPostApply = new ArrayList<>(leavePositions.size());

        for (Map.Entry<BlockPos, BlockState> entry : leavePositions.entrySet()) {
            BlockPos leavePosition = entry.getKey();
            BlockState state = entry.getValue();
            level.setBlockState(leavePosition, state, 2);
            if (state.contains(LeavesBlock.DISTANCE)) {
                Runnable postProcess = () -> {
                    BlockState blockState = LeavesBlock.updateDistanceFromLogs(state, level, leavePosition);
                    if (blockState.get(LeavesBlock.DISTANCE) < LeavesBlock.MAX_DISTANCE) {
                        if (blockState.contains(LeavesBlock.PERSISTENT)) {
                            blockState = blockState.with(LeavesBlock.PERSISTENT, false);
                        }
                        level.setBlockState(leavePosition, blockState, 2);
                        level.scheduleBlockTick(leavePosition, blockState.getBlock(), 0);
                    } else {
                        level.removeBlock(leavePosition, false);
                        leavePositions.remove(leavePosition.toImmutable());
                    }
                };
                leavesPostApply.add(postProcess);
            }
        }

        leavesPostApply.forEach(Runnable::run);
    }

    public static void fillTrunkPositions(BlockStateProvider logProvider, BlockStateProvider leavesProvider, TreeFromStructureNBTConfig config, StructureWorldAccess level, Random randomSource, BlockPos origin, StructurePlacementData placeSettings, StructureTemplate.PalettedBlockInfoList trunkBasePalette, BlockPos centerOffset, List<StructureTemplate.StructureBlockInfo> logs, List<StructureTemplate.StructureBlockInfo> logBuilders, Map<BlockPos, BlockState> leavePositions, Map<BlockPos, BlockState> trunkPositions, Map<BlockPos, BlockState> additionalBlocks, int maxTrunkBuildingDepth, Direction treeGrowthDirection) {
        fillLogsUnder(logProvider, level, randomSource, origin, placeSettings, centerOffset, logBuilders, maxTrunkBuildingDepth, config.growableOn(), trunkPositions, treeGrowthDirection);
        placeLogsWithRotation(logProvider, level, randomSource, origin, placeSettings, centerOffset, logs, trunkPositions, treeGrowthDirection);
        placeLeavesWithCalculatedDistanceAndRotation(leavesProvider, level, origin, randomSource, placeSettings, getStructureInfosInStructurePalletteFromBlockList(config.leavesTarget(), trunkBasePalette), leavePositions, centerOffset, config.leavesPlacementFilter(), treeGrowthDirection);
        List<StructureTemplate.StructureBlockInfo> additionalBlocksInfo = getStructureInfosInStructurePalletteFromBlockList(config.placeFromNBT(), trunkBasePalette);
        for (StructureTemplate.StructureBlockInfo additionalBlock : additionalBlocksInfo) {
            BlockPos pos = getModifiedPos(placeSettings, additionalBlock, centerOffset, origin);
            pos = rotateInDirectionAroundOrigin(pos, origin, treeGrowthDirection);
            additionalBlocks.put(pos.toImmutable(), additionalBlock.state());
            ((RandomTickScheduler) level.getChunk(pos)).ohthetreesyoullgrow$scheduleRandomTick(pos.toImmutable());
        }
    }

    public static boolean fillCanopyPositions(BlockStateProvider logProvider, BlockStateProvider leavesProvider, TreeFromStructureNBTConfig config, StructureWorldAccess level, Random randomSource, BlockPos origin, StructurePlacementData placeSettings, StructureTemplate.PalettedBlockInfoList randomCanopyPalette, Map<BlockPos, BlockState> leavePositions, Map<BlockPos, BlockState> trunkPositions, Map<BlockPos, BlockState> additionalBlocks, int trunkLength, Direction treeGrowthDirection) {
        List<StructureTemplate.StructureBlockInfo> leaves = getStructureInfosInStructurePalletteFromBlockList(config.leavesTarget(), randomCanopyPalette);
        List<StructureTemplate.StructureBlockInfo> canopyLogs = getStructureInfosInStructurePalletteFromBlockList(config.logTarget(), randomCanopyPalette);
        List<StructureTemplate.StructureBlockInfo> canopyAnchor = randomCanopyPalette.getAllOf(Blocks.WHITE_WOOL);

        if (canopyAnchor.isEmpty()) {
            throw new IllegalArgumentException("No canopy anchor was specified for structure NBT palette %s. Canopy anchor is specified with white wool.".formatted(config.canopyLocation()));
        }
        if (canopyAnchor.size() > 1) {
            throw new IllegalArgumentException("There cannot be more than one canopy anchor for structure NBT palette %s. Canopy anchor is specified with white wool.".formatted(config.canopyLocation()));
        }

        StructureTemplate.StructureBlockInfo structureBlockInfo = canopyAnchor.getFirst();
        BlockPos canopyCenterOffset = structureBlockInfo.pos();
        canopyCenterOffset = new BlockPos(-canopyCenterOffset.getX(), trunkLength, -canopyCenterOffset.getZ());

        List<StructureTemplate.StructureBlockInfo> trunkFillers = new ArrayList<>(randomCanopyPalette.getAllOf(Blocks.RED_WOOL));

        if (!intersectTrunk(logProvider, level, randomSource, origin, placeSettings, canopyCenterOffset, trunkFillers, trunkLength + 1, trunkPositions, treeGrowthDirection)) {
            return false;
        }

        placeLogsWithRotation(logProvider, level, randomSource, origin, placeSettings, canopyCenterOffset, canopyLogs, trunkPositions, treeGrowthDirection);
        placeLeavesWithCalculatedDistanceAndRotation(leavesProvider, level, origin, randomSource, placeSettings, leaves, leavePositions, canopyCenterOffset, config.leavesPlacementFilter(), treeGrowthDirection);
        List<StructureTemplate.StructureBlockInfo> additionalBlocksInfo = getStructureInfosInStructurePalletteFromBlockList(config.placeFromNBT(), randomCanopyPalette);
        for (StructureTemplate.StructureBlockInfo additionalBlock : additionalBlocksInfo) {
            BlockPos pos = getModifiedPos(placeSettings, additionalBlock, canopyCenterOffset, origin);
            pos = rotateInDirectionAroundOrigin(pos, origin, treeGrowthDirection);
            additionalBlocks.put(pos.toImmutable(), additionalBlock.state());
            ((RandomTickScheduler) level.getChunk(pos)).ohthetreesyoullgrow$scheduleRandomTick(pos.toImmutable());
        }
        return true;
    }

    public static void placeLogsWithRotation(BlockStateProvider logProvider, StructureWorldAccess level, Random random, BlockPos origin, StructurePlacementData placeSettings, BlockPos centerOffset, List<StructureTemplate.StructureBlockInfo> logs, Map<BlockPos, BlockState> trunkPositions, Direction treeGrowthDirection) {
        for (StructureTemplate.StructureBlockInfo trunk : logs) {
            BlockPos pos = getModifiedPos(placeSettings, trunk, centerOffset, origin);
            pos = rotateInDirectionAroundOrigin(pos, origin, treeGrowthDirection);
            trunkPositions.put(pos.toImmutable(), getTransformedState(pos, logProvider.get(random, pos), trunk.state(), placeSettings.getRotation(), level, treeGrowthDirection));
        }
    }

    public static void placeTreeDecorations(Iterable<TreeDecorator> treeDecorators, StructureWorldAccess level, Random random, Set<BlockPos> leavePositions, Set<BlockPos> trunkPositions, Set<BlockPos> decorationPositions) {
        for (TreeDecorator treeDecorator : treeDecorators) {
            treeDecorator.generate(new TreeDecorator.Generator(level, (pos, state) -> {
                level.setBlockState(pos, state, 2);
                decorationPositions.add(pos.toImmutable());
            }, random, trunkPositions, leavePositions, trunkPositions));
        }
    }

    public static void placeLeavesWithCalculatedDistanceAndRotation(BlockStateProvider leavesProvider, StructureWorldAccess level, BlockPos origin, Random random, StructurePlacementData placeSettings, List<StructureTemplate.StructureBlockInfo> leaves, Map<BlockPos, BlockState> leavePositions, BlockPos canopyCenterOffset, BlockPredicate leavesPlacementFilter, Direction treeGrowthDirection) {
        for (StructureTemplate.StructureBlockInfo leaf : leaves) {
            BlockPos modifiedPos = getModifiedPos(placeSettings, leaf, canopyCenterOffset, origin);
            modifiedPos = rotateInDirectionAroundOrigin(modifiedPos, origin, treeGrowthDirection);

            if (leavesPlacementFilter.test(level, modifiedPos)) {
                leavePositions.put(modifiedPos.toImmutable(), getTransformedState(modifiedPos, leavesProvider.get(random, modifiedPos), leaf.state(), placeSettings.getRotation(), level, treeGrowthDirection));
            }
        }
    }

    public static void fillLogsUnder(BlockStateProvider logProvider, StructureWorldAccess level, Random random, BlockPos origin, StructurePlacementData placeSettings, BlockPos centerOffset, List<StructureTemplate.StructureBlockInfo> logBuilders, int maxTrunkBuildingDepth, BlockPredicate groundFilter, Map<BlockPos, BlockState> trunkPositions, Direction treeGrowthDirection) {
        for (StructureTemplate.StructureBlockInfo logBuilder : logBuilders) {
            BlockPos pos = getModifiedPos(placeSettings, logBuilder, centerOffset, origin);
            pos = rotateInDirectionAroundOrigin(pos, origin, treeGrowthDirection);
            BlockPos.Mutable mutableBlockPos = new BlockPos.Mutable().set(pos);

            for (int i = 0; i < maxTrunkBuildingDepth; i++) {
                if (!groundFilter.test(level, mutableBlockPos) && !level.getBlockState(mutableBlockPos).isOf(Blocks.BEDROCK)) {
                    trunkPositions.put(mutableBlockPos.toImmutable(), getTransformedState(mutableBlockPos, logProvider.get(random, mutableBlockPos), logBuilder.state(), placeSettings.getRotation(), level, treeGrowthDirection));
                    mutableBlockPos.move(treeGrowthDirection.getOpposite());
                } else {
                    ((RandomTickScheduler) level.getChunk(mutableBlockPos)).ohthetreesyoullgrow$scheduleRandomTick(mutableBlockPos.toImmutable());
                    break;
                }
            }
        }
    }

    public static boolean intersectTrunk(BlockStateProvider logProvider, StructureWorldAccess level, Random random, BlockPos origin, StructurePlacementData placeSettings, BlockPos centerOffset, List<StructureTemplate.StructureBlockInfo> logBuilders, int maxTrunkBuildingDepth, Map<BlockPos, BlockState> trunkPositions, Direction treeGrowthDirection) {
        for (StructureTemplate.StructureBlockInfo logBuilder : logBuilders) {
            BlockPos pos = getModifiedPos(placeSettings, logBuilder, centerOffset, origin);
            pos = rotateInDirectionAroundOrigin(pos, origin, treeGrowthDirection);
            BlockPos.Mutable mutableBlockPos = new BlockPos.Mutable().set(pos);

            for (int i = 0; i <= maxTrunkBuildingDepth; i++) {
                if (!trunkPositions.containsKey(mutableBlockPos)) {
                    trunkPositions.put(mutableBlockPos.toImmutable(), getTransformedState(mutableBlockPos, logProvider.get(random, mutableBlockPos), logBuilder.state(), placeSettings.getRotation(), level, treeGrowthDirection));
                    mutableBlockPos.move(treeGrowthDirection.getOpposite());
                } else {
                    break;
                }

                if (i == maxTrunkBuildingDepth) {
                    return false;
                }
            }
        }

        return true;
    }


    @NotNull
    public static BlockState getTransformedState(BlockPos modifiedPos, BlockState state, BlockState nbtState, BlockRotation rotation, StructureWorldAccess level, Direction directionOfGrowth) {
        for (BlockStateModifier modifier : BLOCK_STATE_MODIFIERS) {
            state = modifier.apply(modifiedPos, state, nbtState, rotation, level, directionOfGrowth);
        }
        return state;
    }

    public static boolean isOnGround(int maxLogDepth, StructureWorldAccess level, BlockPos pos, BlockPredicate growableOn, Direction treeGrowthDirection) {
        BlockPos.Mutable mutableBlockPos = new BlockPos.Mutable().set(pos);
        for (int logDepth = 0; logDepth < maxLogDepth; logDepth++) {
            mutableBlockPos.move(treeGrowthDirection.getOpposite());
            if (growableOn.test(level, mutableBlockPos)) {
                return true;
            }
        }

        return false;
    }

    public static BlockPos getModifiedPos(StructurePlacementData settings, StructureTemplate.StructureBlockInfo placing, BlockPos partCenter, BlockPos featureOrigin) {
        return StructureTemplate.transform(settings, placing.pos()).add(featureOrigin).add(StructureTemplate.transform(settings, partCenter));
    }


    public static BlockPos rotateInDirectionAroundOrigin(BlockPos pos, BlockPos origin, Direction direction) {
        BlockPos offset = pos.subtract(origin);
        return switch (direction) {
            case UP -> pos;
            case DOWN ->
                    new BlockPos(origin.getX() + offset.getX(), origin.getY() - offset.getY(), origin.getZ() + offset.getZ());
            case EAST ->
                    new BlockPos(origin.getX() + offset.getY(), origin.getY() - offset.getX(), origin.getZ() + offset.getZ());
            case WEST ->
                    new BlockPos(origin.getX() - offset.getY(), origin.getY() + offset.getX(), origin.getZ() + offset.getZ());
            case NORTH ->
                    new BlockPos(origin.getX() + offset.getX(), origin.getY() - offset.getZ(), origin.getZ() - offset.getY());
            case SOUTH ->
                    new BlockPos(origin.getX() + offset.getX(), origin.getY() + offset.getZ(), origin.getZ() + offset.getY());
        };
    }

    public static IllegalArgumentException noTreePartPresent(Identifier location) {
        return new IllegalArgumentException(String.format("\"%s\" is not a valid tree part.", location));
    }

    public static List<StructureTemplate.StructureBlockInfo> getStructureInfosInStructurePalletteFromBlockList(Iterable<Block> blocks, StructureTemplate.PalettedBlockInfoList palette) {
        List<StructureTemplate.StructureBlockInfo> result = new ArrayList<>();
        for (Block block : blocks) {
            result.addAll(palette.getAllOf(block));
        }
        return result;
    }

    public static final List<BlockStateModifier> BLOCK_STATE_MODIFIERS = Util.make(new ArrayList<>(), list -> {
        list.add((modifiedPos, state, nbtState, rotation, level, directionOfGrowth) -> {
            for (Property property : state.getProperties()) {
                if (nbtState.contains(property)) {
                    Comparable value = nbtState.get(property);
                    state = state.with(property, value);
                }
            }

            return state;
        });
        list.add((modifiedPos, lastState, nbtState, rotation, level, directionOfGrowth) -> {
            if (lastState.contains(Properties.WATERLOGGED)) {
                FluidState fluidState = level.getFluidState(modifiedPos);
                if (fluidState.isOf(Fluids.WATER) && fluidState.getLevel() >= 7) {
                    lastState = lastState.with(Properties.WATERLOGGED, true);
                } else {
                    lastState = lastState.with(Properties.WATERLOGGED, false);
                }
            }
            return lastState;
        });
        list.add((modifiedPos, lastState, nbtState, rotation, level, directionOfGrowth) -> lastState.rotate(rotation));
        list.add((modifiedPos, lastState, nbtState, rotation, level, directionOfGrowth) -> {
            if (lastState.contains(Properties.AXIS)) {
                Direction.Axis axis = lastState.get(Properties.AXIS);
                Direction.Axis directionOfGrowthAxis = directionOfGrowth.getAxis();
                switch (directionOfGrowthAxis) {
                    case Y -> {
                        // No change needed
                    }
                    case X -> {
                        if (axis == Direction.Axis.Y) {
                            lastState = lastState.with(Properties.AXIS, Direction.Axis.X);
                        } else if (axis == Direction.Axis.X) {
                            lastState = lastState.with(Properties.AXIS, Direction.Axis.Y);
                        }
                    }
                    case Z -> {
                        if (axis == Direction.Axis.Y) {
                            lastState = lastState.with(Properties.AXIS, Direction.Axis.Z);
                        } else if (axis == Direction.Axis.Z) {
                            lastState = lastState.with(Properties.AXIS, Direction.Axis.Y);
                        }
                    }
                }
            }
            return lastState;
        });
    });

    @FunctionalInterface
    public interface BlockStateModifier {
        BlockState apply(BlockPos modifiedPos, BlockState lastState, BlockState nbtState, BlockRotation rotation, StructureWorldAccess level, Direction directionOfGrowth);
    }
}
