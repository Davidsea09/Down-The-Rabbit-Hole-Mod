package dev.corgitaco.ohthetreesyoullgrow.world.level.levelgen.feature.configurations.treedecorators;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import org.jetbrains.annotations.NotNull;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.block.BlockState;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Util;
import net.minecraft.util.dynamic.Codecs;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.gen.stateprovider.BlockStateProvider;
import net.minecraft.world.gen.treedecorator.TreeDecorator;
import net.minecraft.world.gen.treedecorator.TreeDecoratorType;

public class AttachedToLogsDecorator extends TreeDecorator {
    public static final MapCodec<AttachedToLogsDecorator> CODEC = RecordCodecBuilder.mapCodec(builder ->
            builder.group(
                    Codec.floatRange(0.0F, 1.0F).fieldOf("probability").forGetter(attachedToLogsDecorator -> attachedToLogsDecorator.probability),
                    Codec.intRange(0, 16).fieldOf("exclusion_radius_xz").forGetter(attachedToLogsDecorator -> attachedToLogsDecorator.exclusionRadiusXZ),
                    Codec.intRange(0, 16).fieldOf("exclusion_radius_y").forGetter(attachedToLogsDecorator -> attachedToLogsDecorator.exclusionRadiusY),
                    BlockStateProvider.TYPE_CODEC.fieldOf("block_provider").forGetter(attachedToLogsDecorator -> attachedToLogsDecorator.blockProvider),
                    Codec.intRange(1, 16).fieldOf("required_empty_blocks").forGetter(attachedToLogsDecorator -> attachedToLogsDecorator.requiredEmptyBlocks),
                    Codecs.nonEmptyList(Direction.CODEC.listOf()).fieldOf("directions").forGetter(attachedToLogsDecorator -> attachedToLogsDecorator.directions)
            ).apply(builder, AttachedToLogsDecorator::new)
    );

    protected final float probability;
    protected final int exclusionRadiusXZ;
    protected final int exclusionRadiusY;
    protected final BlockStateProvider blockProvider;
    protected final int requiredEmptyBlocks;
    protected final List<Direction> directions;

    public AttachedToLogsDecorator(float probability, int exclusionRadiusXZ, int exclusionRadiusY, BlockStateProvider blockProvider, int requiredEmptyBlocks, List<Direction> directions) {
        this.probability = probability;
        this.exclusionRadiusXZ = exclusionRadiusXZ;
        this.exclusionRadiusY = exclusionRadiusY;
        this.blockProvider = blockProvider;
        this.requiredEmptyBlocks = requiredEmptyBlocks;
        this.directions = directions;
    }

    public void generate(TreeDecorator.Generator pContext) {
        Set<BlockPos> set = new HashSet<>();
        Random randomsource = pContext.getRandom();

        for (BlockPos blockpos : Util.copyShuffled(pContext.getLogPositions(), randomsource)) {
            Direction direction = Util.getRandom(this.directions, randomsource);
            BlockPos relative = blockpos.offset(direction);
            if (!set.contains(relative) && randomsource.nextFloat() < this.probability && this.hasRequiredEmptyBlocks(pContext, blockpos, direction)) {
                BlockPos offsetMin = relative.add(-this.exclusionRadiusXZ, -this.exclusionRadiusY, -this.exclusionRadiusXZ);
                BlockPos offsetMax = relative.add(this.exclusionRadiusXZ, this.exclusionRadiusY, this.exclusionRadiusXZ);

                for (BlockPos blockpos4 : BlockPos.iterate(offsetMin, offsetMax)) {
                    set.add(blockpos4.toImmutable());
                }

                BlockState state = this.blockProvider.get(randomsource, relative);

                if (state.contains(Properties.HORIZONTAL_FACING)) {
                    state = state.with(Properties.HORIZONTAL_FACING, direction);
                } else if (state.contains(Properties.FACING)) {
                    state = state.with(Properties.FACING, direction);
                }
                pContext.replace(relative, state);
            }
        }

    }

    private boolean hasRequiredEmptyBlocks(TreeDecorator.Generator pContext, BlockPos pPos, Direction pDirection) {
        for (int i = 1; i <= this.requiredEmptyBlocks; ++i) {
            BlockPos blockpos = pPos.offset(pDirection, i);
            if (!pContext.isAir(blockpos)) {
                return false;
            }
        }

        return true;
    }

    protected @NotNull TreeDecoratorType<?> getType() {
        return TYGTreeDecoratorTypes.ATTACHED_TO_LOGS.get();
    }
}