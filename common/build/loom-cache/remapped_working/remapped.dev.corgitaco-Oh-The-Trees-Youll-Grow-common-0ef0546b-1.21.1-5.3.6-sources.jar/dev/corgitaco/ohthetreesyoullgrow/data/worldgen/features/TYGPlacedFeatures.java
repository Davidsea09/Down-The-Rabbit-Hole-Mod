package dev.corgitaco.ohthetreesyoullgrow.data.worldgen.features;

import dev.corgitaco.ohthetreesyoullgrow.Constants;
import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.registry.RegistryEntryLookup;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.world.gen.feature.ConfiguredFeature;
import net.minecraft.world.gen.feature.PlacedFeature;
import net.minecraft.world.gen.placementmodifier.CountPlacementModifier;
import net.minecraft.world.gen.placementmodifier.PlacementModifier;

public class TYGPlacedFeatures {
    public static final Map<RegistryKey<PlacedFeature>, PlacedFeatureFactory> PLACED_FEATURE_FACTORIES = new Reference2ObjectOpenHashMap<>();

    public static final RegistryKey<PlacedFeature> V1_TEST_TREE1 = createPlacedFeature("v1_test_tree1", TYGConfiguredFeatures.V1_TEST_TREE1, () -> CountPlacementModifier.of(1));
    public static final RegistryKey<PlacedFeature> V1_TEST_TREE2 = createPlacedFeature("v1_test_tree2", TYGConfiguredFeatures.V1_TEST_TREE2, () -> CountPlacementModifier.of(1));
    public static final RegistryKey<PlacedFeature> V1_TEST_TREE3 = createPlacedFeature("v1_test_tree3", TYGConfiguredFeatures.V1_TEST_TREE3, () -> CountPlacementModifier.of(1));

    public static final RegistryKey<PlacedFeature> V1_TEST_MUSHROOM1 = createPlacedFeature("v1_test_mushroom1", TYGConfiguredFeatures.V1_TEST_MUSHROOM1, () -> CountPlacementModifier.of(1));
    public static final RegistryKey<PlacedFeature> V1_TEST_MUSHROOM2 = createPlacedFeature("v1_test_mushroom2", TYGConfiguredFeatures.V1_TEST_MUSHROOM2, () -> CountPlacementModifier.of(1));

    @SafeVarargs
    private static RegistryKey<PlacedFeature> createPlacedFeature(String id, RegistryKey<ConfiguredFeature<?, ?>> feature, Supplier<PlacementModifier>... placementModifiers) {
        return createPlacedFeature(id, feature, () -> Arrays.stream(placementModifiers).map(Supplier::get).toList());
    }

    private static RegistryKey<PlacedFeature> createPlacedFeature(String id, RegistryKey<ConfiguredFeature<?, ?>> feature, Supplier<List<PlacementModifier>> placementModifiers) {
        Identifier location = Constants.createLocation(id);

        RegistryKey<PlacedFeature> placedFeatureKey = RegistryKey.of(RegistryKeys.PLACED_FEATURE, location);

        PLACED_FEATURE_FACTORIES.put(placedFeatureKey, configuredFeatureHolderGetter -> new PlacedFeature(configuredFeatureHolderGetter.getOrThrow(feature), placementModifiers.get()));

        return placedFeatureKey;
    }

    public static void register() {
    }

    @FunctionalInterface
    public interface PlacedFeatureFactory {
        PlacedFeature generate(RegistryEntryLookup<ConfiguredFeature<?, ?>> configuredFeatureHolderGetter);
    }
}
