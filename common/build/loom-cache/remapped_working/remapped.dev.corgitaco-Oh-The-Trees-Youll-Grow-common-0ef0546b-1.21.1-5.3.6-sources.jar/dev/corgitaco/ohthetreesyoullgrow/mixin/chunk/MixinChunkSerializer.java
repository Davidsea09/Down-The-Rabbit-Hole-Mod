package dev.corgitaco.ohthetreesyoullgrow.mixin.chunk;

import dev.corgitaco.ohthetreesyoullgrow.Constants;
import dev.corgitaco.ohthetreesyoullgrow.world.level.chunk.RandomTickScheduler;
import dev.corgitaco.ohthetreesyoullgrow.world.level.chunk.storage.LegacyTagStrippingVisitor;
import net.minecraft.nbt.*;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.ChunkSerializer;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ProtoChunk;
import net.minecraft.world.chunk.WrapperProtoChunk;
import net.minecraft.world.poi.PointOfInterestStorage;
import net.minecraft.world.storage.StorageKey;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.List;

@Mixin(ChunkSerializer.class)
public class MixinChunkSerializer {


    @Inject(method = "write", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/chunk/ChunkAccess;getBlendingData()Lnet/minecraft/world/level/levelgen/blending/BlendingData;"), locals = LocalCapture.CAPTURE_FAILHARD)
    private static void writeScheduledRandomTicks(ServerWorld serverLevel, Chunk chunkAccess, CallbackInfoReturnable<NbtCompound> cir, ChunkPos chunkPos, NbtCompound tag) {
        List<BlockPos> scheduledRandomTicks = ((RandomTickScheduler) chunkAccess).ohthetreesyoullgrow$getScheduledRandomTicks();

        if (!scheduledRandomTicks.isEmpty()) {
            NbtCompound corgiLibTag = new NbtCompound();

            NbtList listTag = new NbtList();
            for (BlockPos scheduledRandomTick : scheduledRandomTicks) {
                listTag.add(NbtHelper.fromBlockPos(scheduledRandomTick));
            }
            corgiLibTag.put("scheduled_random_ticks_v2", listTag);

            tag.put(Constants.MOD_ID, corgiLibTag);
        }
    }


    @Inject(method = "read", at = @At("RETURN"))
    private static void readScheduledRandomTicks(ServerWorld level, PointOfInterestStorage poiManager, StorageKey regionStorageInfo, ChunkPos pos, NbtCompound tag, CallbackInfoReturnable<ProtoChunk> cir) {
        if (tag.contains(Constants.MOD_ID, NbtElement.COMPOUND_TYPE)) {
            NbtCompound corgiLibTag = tag.getCompound(Constants.MOD_ID);
            if (corgiLibTag.contains(LegacyTagStrippingVisitor.STRIPPED_MARKER)) {
                corgiLibTag.remove(LegacyTagStrippingVisitor.STRIPPED_MARKER);
                ProtoChunk chunk = cir.getReturnValue();
                Chunk target = chunk instanceof WrapperProtoChunk imposter ? imposter.getWrappedChunk() : chunk;
                target.setNeedsSaving(true);
            }
            if (corgiLibTag.contains("scheduled_random_ticks_v2", NbtElement.LIST_TYPE)) {
                for (NbtElement scheduledTick : corgiLibTag.getList("scheduled_random_ticks_v2", NbtElement.INT_ARRAY_TYPE)) {
                    int[] intArrayTag = ((NbtIntArray) scheduledTick).getIntArray();
                    ((RandomTickScheduler) cir.getReturnValue()).ohthetreesyoullgrow$getScheduledRandomTicks().add(new BlockPos(intArrayTag[0], intArrayTag[1], intArrayTag[2]));
                }
            }
        }
    }
}
