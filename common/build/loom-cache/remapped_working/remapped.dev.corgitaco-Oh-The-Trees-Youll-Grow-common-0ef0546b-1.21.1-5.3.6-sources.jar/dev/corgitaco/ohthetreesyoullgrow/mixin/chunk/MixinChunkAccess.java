package dev.corgitaco.ohthetreesyoullgrow.mixin.chunk;


import dev.corgitaco.ohthetreesyoullgrow.world.level.chunk.RandomTickScheduler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.Chunk;

@Mixin(Chunk.class)
public class MixinChunkAccess implements RandomTickScheduler {

    @Unique
    private final List<BlockPos> scheduledRandomTick = new ArrayList<>();


    @Override
    public void ohthetreesyoullgrow$scheduleRandomTick(BlockPos pos) {
        scheduledRandomTick.add(pos.toImmutable());
    }

    @Override
    public List<BlockPos> ohthetreesyoullgrow$getScheduledRandomTicks() {
        return scheduledRandomTick;
    }
}
