package dev.corgitaco.ohthetreesyoullgrow.world.level.levelgen.feature.configurations.treedecorators;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import org.jetbrains.annotations.NotNull;

import java.util.function.Function;
import net.minecraft.block.Block;
import net.minecraft.block.VineBlock;
import net.minecraft.registry.Registries;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.gen.treedecorator.TreeDecorator;
import net.minecraft.world.gen.treedecorator.TreeDecoratorType;

public class TYGLeavesVineDecorator extends TreeDecorator {

    public static final MapCodec<TYGLeavesVineDecorator> CODEC = RecordCodecBuilder.mapCodec(builder ->
            builder.group(
                    Registries.BLOCK.getCodec().flatXmap(mustExtendVineBlock(), mustExtendVineBlock()).fieldOf("vine_block").forGetter(TYGLeavesVineDecorator -> TYGLeavesVineDecorator.vineBlock),
                    Codec.FLOAT.fieldOf("probability").forGetter(TYGLeavesVineDecorator -> TYGLeavesVineDecorator.probability)
            ).apply(builder, ((vineBlock, probability) -> new TYGLeavesVineDecorator((VineBlock) vineBlock, probability)))
    );


    static Function<Block, DataResult<Block>> mustExtendVineBlock() {
        return block -> block instanceof VineBlock ? DataResult.success(block) : DataResult.error(() -> String.format("\"%s\" is not an instance of `VineBlock`.", Registries.BLOCK.getId(block)));
    }

    private final VineBlock vineBlock;
    private final float probability; // Vanilla is 0.66 chance.

    public TYGLeavesVineDecorator(VineBlock vineBlock, float probability) {
        this.vineBlock = vineBlock;
        this.probability = probability;
    }

    protected @NotNull TreeDecoratorType<?> getType() {
        return TYGTreeDecoratorTypes.LEAVE_VINE.get();
    }

    public void generate(Generator context) {
        Random randomSource = context.getRandom();
        context.getLeavesPositions().forEach((pos) -> {
            BlockPos pos1;
            if (randomSource.nextFloat() <= this.probability) {
                pos1 = pos.west();
                if (context.isAir(pos1)) {
                    addHangingVine(pos1, VineBlock.EAST, context);
                }
            }

            if (randomSource.nextFloat() <= this.probability) {
                pos1 = pos.east();
                if (context.isAir(pos1)) {
                    addHangingVine(pos1, VineBlock.WEST, context);
                }
            }

            if (randomSource.nextFloat() <= this.probability) {
                pos1 = pos.north();
                if (context.isAir(pos1)) {
                    addHangingVine(pos1, VineBlock.SOUTH, context);
                }
            }

            if (randomSource.nextFloat() <= this.probability) {
                pos1 = pos.south();
                if (context.isAir(pos1)) {
                    addHangingVine(pos1, VineBlock.NORTH, context);
                }
            }
        });
    }

    private void addHangingVine(BlockPos pos, BooleanProperty booleanProperty, TreeDecorator.Generator context) {
        placeVine(context, pos, booleanProperty);
        int count = 4;

        for (pos = pos.down(); context.isAir(pos) && count > 0; --count) {
            placeVine(context, pos, booleanProperty);
            pos = pos.down();
        }
    }

    public void placeVine(Generator context, BlockPos blockPos, BooleanProperty booleanProperty) {
        context.replace(blockPos, this.vineBlock.getDefaultState().with(booleanProperty, true));
    }
}