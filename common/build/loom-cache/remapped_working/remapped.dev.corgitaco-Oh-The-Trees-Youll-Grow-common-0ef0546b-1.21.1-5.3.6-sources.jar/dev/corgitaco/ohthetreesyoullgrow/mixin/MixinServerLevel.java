package dev.corgitaco.ohthetreesyoullgrow.mixin;

import dev.corgitaco.ohthetreesyoullgrow.world.level.chunk.RandomTickScheduler;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.profiler.Profiler;
import net.minecraft.world.MutableWorldProperties;
import net.minecraft.world.World;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.world.dimension.DimensionType;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import java.util.function.Supplier;

@Mixin(ServerWorld.class)
public abstract class MixinServerLevel extends World {


    @Shadow
    @NotNull
    public abstract MinecraftServer getServer();

    protected MixinServerLevel(MutableWorldProperties levelData, RegistryKey<World> dimension, DynamicRegistryManager registryAccess, RegistryEntry<DimensionType> dimensionTypeRegistration, Supplier<Profiler> profiler, boolean isClientSide, boolean isDebug, long biomeZoomSeed, int maxChainedNeighborUpdates) {
        super(levelData, dimension, registryAccess, dimensionTypeRegistration, profiler, isClientSide, isDebug, biomeZoomSeed, maxChainedNeighborUpdates);
    }

    @Inject(method = "tickChunk", at = @At("HEAD"))
    private void tickScheduledRandomTicks(WorldChunk chunk, int randomTickSpeed, CallbackInfo ci) {
        var original = ((RandomTickScheduler) chunk).ohthetreesyoullgrow$getScheduledRandomTicks();
        if (original.isEmpty()) return;

        var tmp = List.copyOf(original);
        original.clear();

        tmp.forEach(scheduledPos -> chunk.getBlockState(scheduledPos).randomTick((ServerWorld) (Object) this, scheduledPos, this.random));
    }
}
