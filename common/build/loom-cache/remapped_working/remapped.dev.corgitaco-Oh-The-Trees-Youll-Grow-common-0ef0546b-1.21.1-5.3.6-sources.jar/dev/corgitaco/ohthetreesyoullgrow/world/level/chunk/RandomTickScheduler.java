package dev.corgitaco.ohthetreesyoullgrow.world.level.chunk;


import java.util.List;
import net.minecraft.util.math.BlockPos;

public interface RandomTickScheduler {

    void ohthetreesyoullgrow$scheduleRandomTick(BlockPos pos);


    List<BlockPos> ohthetreesyoullgrow$getScheduledRandomTicks();
}
