package dev.corgitaco.ohthetreesyoullgrow.world.level.levelgen.feature.configurations.treedecorators;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.block.Block;
import net.minecraft.registry.Registries;
import net.minecraft.util.Util;
import net.minecraft.util.dynamic.Codecs;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.gen.stateprovider.BlockStateProvider;
import net.minecraft.world.gen.treedecorator.AttachedToLeavesTreeDecorator;
import net.minecraft.world.gen.treedecorator.TreeDecorator;
import net.minecraft.world.gen.treedecorator.TreeDecoratorType;

public class AttachedToFruitLeavesDecorator extends AttachedToLeavesTreeDecorator {

    public static final MapCodec<AttachedToFruitLeavesDecorator> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            Codec.floatRange(0.0F, 1.0F).fieldOf("probability").forGetter(decorator -> decorator.probability),
            Codec.intRange(0, 16).fieldOf("exclusion_radius_xz").forGetter(decorator -> decorator.exclusionRadiusXZ),
            Codec.intRange(0, 16).fieldOf("exclusion_radius_y").forGetter(decorator -> decorator.exclusionRadiusY),
            Registries.BLOCK.getCodec().fieldOf("leaves_block").forGetter(decorator -> decorator.leavesBlock),
            BlockStateProvider.TYPE_CODEC.fieldOf("block_provider").forGetter(decorator -> decorator.blockProvider),
            Codec.intRange(1, 16).fieldOf("required_empty_blocks").forGetter(decorator -> decorator.requiredEmptyBlocks),
            Codecs.nonEmptyList(Direction.CODEC.listOf()).fieldOf("directions").forGetter(decorator -> decorator.directions)
    ).apply(instance, AttachedToFruitLeavesDecorator::new));


    private final Block leavesBlock;

    public AttachedToFruitLeavesDecorator(float probability, int exclusionRadiusXZ, int exclusionRadiusY, Block leavesBlock, BlockStateProvider blockProvider, int requiredEmptyBlocks, List<Direction> directions) {
        super(probability, exclusionRadiusXZ, exclusionRadiusY, blockProvider, requiredEmptyBlocks, directions);
        this.leavesBlock = leavesBlock;
    }

    @Override
    protected @NotNull TreeDecoratorType<?> getType() {
        return TYGTreeDecoratorTypes.ATTACHED_TO_FRUIT_LEAVES.get();
    }

    @Override
    public void generate(@NotNull Generator context) {
        Set<BlockPos> positions = new HashSet<>();
        Random random = context.getRandom();
        List<BlockPos> leavesPositions = new ArrayList<>();

        for (BlockPos pos : context.getLeavesPositions()) {
            if (context.getWorld().testBlockState(pos, state -> state.isOf(this.leavesBlock))) {
                leavesPositions.add(pos);
            }
        }

        List<BlockPos> shuffledLeaves = Util.copyShuffled(leavesPositions.toArray(new BlockPos[0]), random);

        for (BlockPos pos : shuffledLeaves) {
            Direction direction = Util.getRandom(this.directions, random);
            BlockPos relativePos = pos.offset(direction);

            if (positions.contains(relativePos)) {
                continue;
            }

            if (!(random.nextFloat() < this.probability)) {
                continue;
            }

            if (!this.meetsRequiredEmptyBlocks(context, pos, direction)) {
                continue;
            }

            BlockPos minXZ = relativePos.add(-this.exclusionRadiusXZ, -this.exclusionRadiusY, -this.exclusionRadiusXZ);
            BlockPos maxXZ = relativePos.add(this.exclusionRadiusXZ, this.exclusionRadiusY, this.exclusionRadiusXZ);

            for (BlockPos blockPos : BlockPos.iterate(minXZ, maxXZ)) {
                positions.add(blockPos.toImmutable());
            }

            context.replace(relativePos, this.blockProvider.get(random, relativePos));
        }
    }


    private boolean meetsRequiredEmptyBlocks(TreeDecorator.Generator context, BlockPos pos, Direction direction) {
        for (int i = 1; i <= this.requiredEmptyBlocks; i++) {
            BlockPos relativePos = pos.offset(direction, i);

            if (!context.isAir(relativePos)) {
                return false;
            }
        }

        return true;
    }
}