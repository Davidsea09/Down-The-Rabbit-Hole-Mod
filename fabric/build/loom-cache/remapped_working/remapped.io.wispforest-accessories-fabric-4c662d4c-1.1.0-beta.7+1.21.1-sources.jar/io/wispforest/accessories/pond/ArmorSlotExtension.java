package io.wispforest.accessories.pond;

import class_9692;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;

public interface ArmorSlotExtension {

    default class_9692 setAtlasLocation(ResourceLocation atlasLocation) {
        throw new IllegalStateException("Extension method not implemented!");
    }

    @Nullable
    default ResourceLocation getAtlasLocation(){
        throw new IllegalStateException("Extension method not implemented!");
    }
}
