package io.wispforest.accessories.menu;

import io.wispforest.endec.Endec;
import io.wispforest.endec.impl.StructEndecBuilder;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.world.entity.LivingEntity;

public record AccessoriesMenuData(Optional<Integer> targetEntityId) {
    public static final Endec<AccessoriesMenuData> ENDEC = StructEndecBuilder.of(
            Endec.VAR_INT.optionalOf().fieldOf("targetEntityId", AccessoriesMenuData::targetEntityId),
            AccessoriesMenuData::new
    );

    public static AccessoriesMenuData of(@Nullable LivingEntity livingEntity) {
        return new AccessoriesMenuData(Optional.ofNullable(livingEntity != null ? livingEntity.getId() : null));
    }
}
